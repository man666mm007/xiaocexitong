# 数据库设计

SQLite 正式数据目录默认为 instance/；演示数据单独放在 instance_demo/。正式库和演示库分别保存账号、记录与登录计数。

| 表 | 用途 | 关键字段/关系 |
| --- | --- | --- |
| users | 教师/学生全局账号 | username 唯一、password_hash、role、must_change_password、全局归档状态；旧 class_name 仅为兼容字段 |
| teaching_classes | 稳定教学班实体 | id、学年、学期、课程、班序号、显示名、归档和 30 天清理状态；身份由学年/学期/课程/班序号组成 |
| student_classes | 学生选班关系 | student_id、class_id 唯一组合、active/removed 状态；删除教学班只级联本班关系 |
| quizzes | 小测 | class_id 外键、日期生成的名称、total_score 保存自动识别的 N；新建扣分制草稿在首次确认导入前为 NULL |
| scores | 每名学生每次小测的成绩 | quiz_id、student_id 唯一组合；成绩允许真实负数 |
| answer_details | 逐题作答判定 | 题号、correct/wrong/blank 状态 |
| attendance_sessions | 签到场次 | class_id、时间、动态码状态；归档不删除学生账号 |
| attendance_records | 学生考勤 | 场次、学生、时间、状态；每人每场唯一 |
| quiz_images | 成绩图片 | 图片元信息，文件放在 instance/uploads/ |
| record_trash | 单个小测/签到回收站 | 记录引用、教学班 ID、30 天保留期限 |
| class_trash | 教学班回收站 | 批次 ID、教学班 ID、显示名和保留期限；不以名称作为唯一键 |
| import_batches | 确认前导入预览 | 教师、类型、JSON 预览、暂存目录 |
| login_attempts | 登录失败限速 | 失败次数、封锁时间 |
| login_daily_counts | 成功登录日计数 | 上海自然日主键、原子递增次数 |
| schema_migrations | 迁移版本记录 | 版本主键和应用时间 |

## 关键约束

- 学生账号全局唯一；同一账号可关联多个教学班。名单确认只新增需要的账号和选班关系，不覆盖已有密码。
- 教学班只由有效名单确认流程创建；小测与签到必须引用已有有效教学班。
- 新建小测初始为未发布草稿，total_score 暂为空；首次导入确认时从 1..N 连续题号列识别 N，并与成绩、逐题记录在同一事务内保存。逐题 1=correct、-1=wrong、0=blank，总分须等于 correct 数减 wrong 数，且为 [-N,N] 中的有限整数。旧小测保留原 total_score 和历史成绩。
- total_score 仅在扣分制未发布草稿中允许为空；空题数的小测不能发布。既有题数在首次确认后固定，后续更正文件须匹配。
- 每名学生每次小测、每场签到至多一条记录；班级筛选和权限均按 class_id 与 active 选班关系执行。
- 班级永久删除会先清理该班小测、成绩、签到和图片，再删除教学班；不会删除共享学生账号或其他班历史。
- 整班归档仅归档本班关系/小测/签到，不通过 users.archived_at 禁用全班账号。全局删除学生仍单独走账号回收站。
- 登录计数仅在密码验证成功并建立会话时原子递增；页面读取只读，不根据旧账号数补造历史。
- schema_migrations 分别记录版本2、3、4；版本3不会重新执行版本2的班级回填。旧小测表按原约束检测后重建，保留记录及外键关系，并恢复自增序列；迁移使用 BEGIN IMMEDIATE，失败回滚，重复启动不重复改表。
- 迁移保留成绩、考勤、发布状态和密码哈希；旧班名能按规则解析时提取学年/学期/课程/班序号，无法解析时仅保留名称，不猜测元信息。

## 版本3：课堂关联、交卷与预约

| 表 | 责任与约束 |
| --- | --- |
| classroom_sessions | UNIQUE(class_id,class_date)，完整ISO日期；quiz_id、attendance_session_id分别唯一可空、子记录物理删除时SET NULL；ready/conflict/cancelled、待核查说明和版本 |
| quiz_submissions | UNIQUE(quiz_id,student_id)，submitted/unsubmitted、来源、确认时间和批次；无行不代表未交 |
| quiz_submission_events | 导入确认前后JSON，保存交卷、有效成绩、逐题及图片元信息快照；不永久保存图片实体 |
| attendance_adjustments | UNIQUE(session_id,student_id)，教师normal/late/absent覆盖、版本、真实时间、原因 |
| attendance_adjustment_events | 每次覆盖追加前后状态、版本、操作者名称和原因；原始扫码不修改 |
| attendance_schedule_rules | 教学班、有限日期范围、第一周周一、星期时段、明确周次与跳过日期JSON、启用和修订版本 |

事件的业务父记录删除时级联清理；操作者外键删除时SET NULL，名称快照保留。quizzes新增results_confirmed_at，区分未导入与确认后全员未交。attendance_sessions新增attendance_date、schedule_rule_id、schedule_revision、is_exception、cancelled_at、closed_at、late_enabled；另保存schedule_origin_date，防止改期后的原规则日期被再次生成。import_batches增加attendance_schedule种类；确认消费信息保存在payload中，同一预览重复确认复用原规则。

应用在BEGIN IMMEDIATE内创建或复用课堂，校验同班同日并关联子记录。回收站、取消均不释放日期，物理清除子记录才可在原课堂补建。班级删除级联课堂与规则。

迁移仅按标题月日与上海实际开始日一致的签到回填日期，不可靠日期保留NULL。唯一可靠候选自动关联，重复候选标记conflict，待教师选定；原ID、原成绩、密码哈希、发布及回收站字段保留。历史完整有效逐题结果回填已交；历史被旧版跳过的全零无法从缺失成绩反推未交。历史只含零总分且无完整逐题信息仍待核查。

开放使用统一服务端时钟和[starts_at,ends_at)，迟到界限起算迟到。提前结束单独写closed_at，不篡改原窗口；归档、取消、未启用、待核查均停止扫码。预约无后台定时线程，普通Waitress和WSGI入口使用同一判定。单独改期、取消保留身份及规则来源，未来规则修订不重建例外或取消日期。

## 版本4：历史仅总分修复

仅对已有scores、无answer_details、缺少quiz_submissions且分数为有效非零总分的历史记录回填submitted，source为migration_total_only。零总分保留待核查，完整逐题相抵零分沿用既有已交状态，不覆盖已有交卷决定。修复不改分数、ID、密码哈希、发布状态；同一事务检查外键并写版本4，已完成版本3的实例也会执行，重复启动不新增记录。
