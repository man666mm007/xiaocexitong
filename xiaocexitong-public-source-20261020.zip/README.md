# 小测查询系统

一个基于 Flask、SQLite 和 Jinja 的课堂小测与签到应用，提供教学班管理、成绩导入与统计、预约签到、记录更正、回收站和教师端系统更新入口。

## 一键更新

更新功能由教师端页面、独立本机更新助手和签名 Release 协议组成。更新助手只监听回环地址；程序包采用白名单构建，更新清单经 RSA-PSS 签名校验，并在切换失败时恢复旧程序版本。首次安装和 Release 发布流程见 docs/UPDATE_ADMIN.md 与 docs/UPDATE_RELEASE.md。

公开仓库目前提供源码。在线更新只有在管理员生成并发布签名 Release、配置公钥并在服务器安装更新助手后才可用。

## 本地运行

需要 Python 3.11 或 3.12。创建虚拟环境并安装 requirements.txt 中的依赖，然后配置本地密钥：

    py -3.12 -m venv .venv
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    $env:QUIZ_SECRET_KEY = (& python -c "import secrets; print(secrets.token_hex(32))")

初始化第一个教师账号。程序会交互式询问密码，不提供默认账号或默认密码：

    .venv\Scripts\python.exe scripts\init_project.py --teacher-id "teacher-login-id" --teacher-name "Teacher Name"

然后启动本地服务：

    .venv\Scripts\python.exe scripts\start_server.py

Linux 或 macOS 用户可使用相应平台的 Python、虚拟环境和环境变量写法。Windows 启动脚本会在本地生成并忽略 secret_key.txt；不要将该文件加入版本控制。

## 测试

    .venv\Scripts\python.exe -m unittest discover -s tests -v

## 发布范围

公开源码不包含数据库、上传内容、备份、签名私钥、服务器配置、演示数据库、演示样表或固定演示登录凭据。Git 忽略规则覆盖这些本地数据和构建产物。不要把本地交付目录中的实例数据或演示文件加入公开仓库。
