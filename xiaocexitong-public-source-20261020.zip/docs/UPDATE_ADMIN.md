# 更新助手管理员操作

这份手册用于管理员在正式服务环境首次接入更新助手。公开仓库已经建立，但尚未发布签名 Release，因此在线更新仍未启用。不要在本地演示目录运行管理员安装。

## 安装前条件

- Windows 10/11 或 Windows Server，Python 3.11/3.12 虚拟环境可正常启动。
- 已确认项目目录、实际数据目录、`secret_key.txt`、虚拟环境 Python、`/quiz` 前缀、5000 端口及原访问地址。
- 数据目录必须是系统正在使用的 `QUIZ_INSTANCE_DIR`，并包含 `quiz.sqlite3`、`uploads/` 和 `pending/`。演示目录 `instance_demo` 不应作为生产更新目标。
- 网站已停止，5000 端口没有监听进程。
- 公开 GitHub 仓库已建立，`owner/name` 精确无误；服务器可访问 GitHub Release。
- 管理员持有与发布清单匹配的 RSA 公钥和 zipapp 更新助手。私钥不得放到老师服务器。
- 已准备与项目、数据目录和 `%ProgramData%` 更新助手目录隔离的备份盘/目录。

在正式服务环境和签名 Release 准备完成前，只能预览安装计划并在隔离合成数据上演练。真实首装须由管理员按本手册完成。

## 首次安装流程

1. 通知教师停用系统并关闭网站进程。确认 `http://127.0.0.1:5000/quiz/` 暂不可访问。
2. 在另一块受保护磁盘上备份整个项目目录和实际数据目录。安装器会再生成一份程序 ZIP 和逐文件哈希校验的数据副本，但不能替代学校的独立备份策略。
3. 确认正式数据路径。若启动时设置了 `QUIZ_INSTANCE_DIR`，必须使用其解析后的绝对路径；未设置时，`start_windows.bat` 默认使用项目内 `instance`。
4. 将发布公钥保存到管理员可读路径；将 `quiz-updater.pyz` 保存到项目外的管理员可读路径。确认二者来源可信。
5. 在管理员 PowerShell 中先执行 dry-run。示例路径须按服务器实际情况替换：

   ```powershell
   $project = 'D:\QuizSystem'
   $data = 'D:\QuizSystem\instance'
   $python = 'D:\QuizSystem\.venv\Scripts\python.exe'
   $publicKey = 'D:\QuizAdmin\release-public.pem'
   $helper = 'D:\QuizAdmin\quiz-updater.pyz'
   $backup = 'E:\QuizBackups\UpdaterFirstInstall'

   .\scripts\install_updater.ps1 `
     -ProjectRoot $project -DataRoot $data `
     -Repository 'man666mm007/xiaocexitong' `
     -PublicKey $publicKey -HelperPackage $helper `
     -PythonPath $python -BackupRoot $backup -WhatIf
   ```

   输出为 JSON 计划，不创建 ProgramData 文件、ACL 或计划任务。先检查项目、数据、公钥、Python 和备份路径全部正确。

6. 确认固定仓库已公开，并将上一步的 `-WhatIf` 去掉，以管理员身份再次运行。安装器会先检查真实 Release 仓库可访问、端口空闲、数据库 `quick_check` 和备份哈希，再配置 `%ProgramData%\ProbabilityQuizUpdater`、随机令牌 ACL、Network Service 开机任务及版本槽 `1.0.0`。
7. 安装成功后运行只读检查：

   ```powershell
   .\scripts\verify_updater_install.ps1
   ```

   确认任务存在、站点 HTTP 响应正常、助手显示版本 `1.0.0`。然后以原地址登录教师账号，确认账号、成绩和图片可见；之后才把教师页面的更新入口交给教师使用。

## 失败处理

- 安装器拒绝已有 `%ProgramData%\ProbabilityQuizUpdater` 目录，不覆盖现有配置或令牌。先检查任务状态、备份和目录内容，再由管理员制定恢复步骤。
- 首次安装失败时保留独立 `BackupRoot`。停止计划任务后，使用程序 ZIP 恢复项目文件，并从 `data/` 副本逐项恢复整个数据目录；不要只恢复数据库而漏掉 `uploads/` 或 `pending/`。
- 若失败时助手目录已创建，`start_windows.bat` 可能转入助手管理模式。修复前不要重复双击启动；先由管理员检查/停止 `ProbabilityQuizUpdater` 任务和本机端口。
- 助手健康检查失败后，保留所有备份及日志/状态目录，联系负责发布签名密钥的管理员。不要把演示数据复制到正式数据目录。

## 更新助手安全边界

- 助手只监听 `127.0.0.1`，由随机 bearer token 保护。任务使用 `NT AUTHORITY\NETWORK SERVICE`；令牌和公钥放在受保护的 ProgramData 目录。
- 程序版本放在 `versions/`，状态和活动指针放在 `work/`，数据备份放在 `backups/`。这些目录均与网页更新包暂存路径隔离。
- 更新包只允许应用源代码和固定启动文件，`requirements.txt` 摘要变化会阻止自动安装。升级依赖需单独由管理员维护。
- `start_windows.bat` 在助手安装后只向助手请求打开固定站点；`instance_demo` 仍使用隔离直启流程，不接入助手。
- 当前助手交付为标准库 zipapp `quiz-updater.pyz`，由已配置项目虚拟环境中的 Python 以 `-I -S` 执行。助手代码不导入网站依赖，但它仍需要该 Python 解释器；尚未打包成自包含 EXE。
