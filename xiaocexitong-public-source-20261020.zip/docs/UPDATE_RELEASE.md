# 更新 Release 发布步骤

本仓库公开发布的是源码；当前尚无签名 Release。正式发布前必须在受保护的开发设备完成本地构建和验签，不要将私钥、学生数据或服务器配置上传。

## 1. 固定公开仓库地址

公开仓库固定为 `man666mm007/xiaocexitong`。服务器安装器和发布命令都使用该固定地址，不要把更新清单指向可变 URL、个人网盘或临时文件服务。

## 2. 准备签名密钥

- RSA-3072 或更强密钥，`key_id` 使用固定、唯一的标识，例如 `release-2026`。
- 私钥只保存在开发者侧受保护目录；使用 Windows NTFS ACL 限制为发布人员和 SYSTEM 可读，并做离线受保护备份。
- 不要把私钥放进项目目录、GitHub、服务器、更新 ZIP、截图、终端输出或协作消息。
- 服务器只安装公钥。更换密钥需要管理员更新服务器公钥和 `key_id`。

若开发环境已安装 OpenSSL，可在项目目录之外生成密钥对：

```powershell
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out 'D:\ReleaseKeys\release-private.pem'
openssl pkey -in 'D:\ReleaseKeys\release-private.pem' -pubout -out 'D:\ReleaseKeys\release-public.pem'
```

生成后检查私钥 ACL、离线备份和公钥内容。签名工具只接受未加密 PEM；依靠受限的开发者账户/磁盘 ACL 保护私钥文件。

## 3. 安装隔离的构建依赖并更新版本

仅发布构建需要 `cryptography`。以下 hash 锁适用于 Windows x86-64、CPython 3.12；应用网站的 `requirements.txt` 不变。

```powershell
py -3.12 -m venv .release-venv
.\.release-venv\Scripts\python.exe -m pip install --require-hashes -r updater\requirements-build.txt
```

确认变更已通过测试后，将项目根目录 `VERSION` 递增为新的稳定语义版本，如 `1.0.1`。版本号与 Release tag 必须严格对应为 `v1.0.1`。

## 4. 本地生成签名资产

准备 UTF-8 更新说明文件。`--min-version` 与 `--max-version` 表示该发布允许升级的旧版范围；`--schema-version` 必须与新程序数据库迁移版本一致。

```powershell
\.release-venv\Scripts\python.exe scripts\build_update_release.py `
  --repository 'man666mm007/xiaocexitong' --tag 'v1.0.1' --notes-file 'D:\Release\notes.txt' `
  --min-version '1.0.0' --max-version '1.0.0' --schema-version 5 `
  --key-id 'release-2026' --private-key 'D:\ReleaseKeys\release-private.pem' `
  --output-dir 'D:\Release\v1.0.1'
```

生成三项文件：

- `quiz-program-v1.0.1.zip`
- `update-manifest.json`
- `update-manifest.json.sig`

ZIP 白名单仅包含 `app/`、固定启动入口、`requirements.txt` 和 `VERSION`。发布工具会拒绝项目树中的私钥，并不打包 `instance`、SQLite、`uploads`、`pending`、`secret_key.txt`、虚拟环境、日志、备份和本机配置。

助手使用 RSA-PSS、MGF1-SHA-256、32 字节盐对清单原始字节签名。清单记录版本、兼容范围、说明、固定仓库和下载地址、包大小、SHA-256、依赖摘要和数据库 schema 版本。

## 5. 上传并核验 GitHub Release

1. 在 `owner/name` 创建稳定 Release，标签使用 `v1.0.1`。
2. 只上传上述三项发布资产。不要把私钥、公钥安装配置、数据库、学生文件或备份上传到 Release。
3. 从 Release 页面重新下载三项文件到空的本地核验目录。检查清单仓库/标签/版本、签名、包大小、包 SHA-256、依赖摘要及 ZIP 成员白名单。
4. 发布后由管理员在测试数据副本上执行只读“检查更新”，再完成成功和失败回滚演练。通过后才通知老师使用更新页面。

当前尚无签名 Release，因此还不能完成线上 Release 下载或服务器首次安装。

## 更新助手的交付形式

运行时助手是只含 `updater/` 必要模块的标准库 zipapp。构建命令：

```powershell
pwsh -File scripts\build_update_agent.ps1 `
  -PythonPath 'D:\QuizSystem\.venv\Scripts\python.exe'
```

默认输出 `dist/quiz-updater.pyz`，构建后会运行 `--help` 启动检查并打印 SHA-256。助手使用 `-I -S` 运行，不加载网站依赖；当前运行方式仍需指定 Python 解释器。本交付没有自包含 EXE；如后续要求完全不依赖 Python，应另行配置可靠的 Windows 构建机和 PyInstaller 构建/签名流水线。
