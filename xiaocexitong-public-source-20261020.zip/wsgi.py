import os

from app import create_app

if not os.environ.get("QUIZ_SECRET_KEY"):
    raise RuntimeError("正式运行前必须设置 QUIZ_SECRET_KEY 环境变量。")

app = create_app()
