import hashlib
import stat
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from updater.archive import ArchiveValidationError, DependencyChangeError, verify_and_extract


class UpdateArchiveTests(unittest.TestCase):
    requirements = b"flask==3.1.0\n"

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.root = Path(self.temp.name)
        self.archive = self.root / "update.zip"
        self.staging = self.root / "staging"
        self.requirements_hash = hashlib.sha256(self.requirements).hexdigest()
        self.candidate = SimpleNamespace(
            manifest=SimpleNamespace(requirements_sha256=self.requirements_hash)
        )

    def tearDown(self):
        self.temp.cleanup()

    def write_zip(self, entries, modes=None):
        modes = modes or {}
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with zipfile.ZipFile(self.archive, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, value in entries:
                    info = zipfile.ZipInfo(name)
                    info.compress_type = zipfile.ZIP_DEFLATED
                    info.external_attr = modes.get(name, (stat.S_IFREG | 0o644) << 16)
                    archive.writestr(info, value)

    def required_entries(self):
        return [
            ("app/__init__.py", b""),
            ("run.py", b""),
            ("wsgi.py", b""),
            ("scripts/start_server.py", b""),
            ("requirements.txt", self.requirements),
            ("VERSION", b"1.0.1\n"),
        ]

    def test_valid_archive_extracts_only_program_files(self):
        self.write_zip(self.required_entries())
        extracted = verify_and_extract(self.candidate, self.archive, self.staging, self.requirements_hash)
        self.assertEqual(extracted, self.staging)
        self.assertEqual((self.staging / "VERSION").read_bytes(), b"1.0.1\n")
        self.assertTrue((self.staging / "app" / "__init__.py").is_file())

    def test_rejects_traversal_absolute_duplicate_and_casefold_duplicate(self):
        malicious = [
            [("../outside.txt", b"bad")],
            [("/outside.txt", b"bad")],
            [("app/same.py", b"one"), ("app/same.py", b"two")],
            [("app/Same.py", b"one"), ("app/same.py", b"two")],
        ]
        for extra in malicious:
            with self.subTest(extra=extra):
                self.write_zip(self.required_entries() + extra)
                with self.assertRaises(ArchiveValidationError):
                    verify_and_extract(self.candidate, self.archive, self.staging, self.requirements_hash)
                self.assertFalse(self.staging.exists())

    def test_rejects_link_data_path_and_size_bomb(self):
        entries = self.required_entries() + [("app/link", b"target"), ("instance/quiz.sqlite3", b"private")]
        modes = {"app/link": (stat.S_IFLNK | 0o777) << 16}
        self.write_zip(entries, modes)
        with self.assertRaises(ArchiveValidationError):
            verify_and_extract(self.candidate, self.archive, self.staging, self.requirements_hash)
        self.assertFalse(self.staging.exists())

        self.write_zip(self.required_entries() + [("app/large.py", b"x" * 20)])
        with mock.patch("updater.archive.MAX_FILE_BYTES", 10):
            with self.assertRaises(ArchiveValidationError):
                verify_and_extract(self.candidate, self.archive, self.staging, self.requirements_hash)
        self.assertFalse(self.staging.exists())

    def test_rejects_requirements_change_before_extracting(self):
        self.write_zip(self.required_entries())
        with self.assertRaises(DependencyChangeError):
            verify_and_extract(self.candidate, self.archive, self.staging, "0" * 64)
        self.assertFalse(self.staging.exists())

    def test_refuses_existing_staging_directory(self):
        self.staging.mkdir()
        self.write_zip(self.required_entries())
        with self.assertRaises(ArchiveValidationError):
            verify_and_extract(self.candidate, self.archive, self.staging, self.requirements_hash)
        self.assertTrue(self.staging.is_dir())


if __name__ == "__main__":
    unittest.main()
