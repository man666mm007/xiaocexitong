import base64
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from updater.manifest import UpdateManifest
from updater.release_client import DownloadError, ReleaseClient, ReleaseClientError, UpdateCandidate


class FakeResponse:
    def __init__(self, body=b"", status=200, headers=None, url=None, fail_after_first=False):
        self.status = status
        self.headers = headers or {"Content-Length": str(len(body))}
        self.url = url or "https://github.com/school/probability-quiz/releases/latest/download/update-manifest.json"
        self.body = body
        self.position = 0
        self.fail_after_first = fail_after_first
        self.closed = False

    def read(self, size=-1):
        if self.fail_after_first and self.position:
            raise OSError("synthetic interrupted read")
        if self.position >= len(self.body):
            return b""
        take = min(size if size >= 0 else len(self.body), len(self.body) - self.position)
        if self.fail_after_first:
            take = min(take, max(1, len(self.body) // 2))
        value = self.body[self.position : self.position + take]
        self.position += take
        return value

    def close(self):
        self.closed = True


class FakeTransport:
    def __init__(self, replies):
        self.replies = {url: list(items) for url, items in replies.items()}
        self.calls = []

    def open(self, url, timeout):
        self.calls.append((url, timeout))
        queue = self.replies.get(url, [])
        if not queue:
            raise AssertionError(f"unexpected URL: {url}")
        item = queue.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item


class ReleaseClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.private = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        cls.public_pem = cls.private.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def setUp(self):
        self.package = b"synthetic program package bytes"
        self.requirements_hash = hashlib.sha256(b"flask==3.1.0\n").hexdigest()
        self.raw_manifest = self.manifest_bytes()
        self.signature = self.private.sign(
            self.raw_manifest,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        self.manifest_url = "https://github.com/school/probability-quiz/releases/latest/download/update-manifest.json"
        self.signature_url = self.manifest_url + ".sig"
        self.package_url = "https://github.com/school/probability-quiz/releases/download/v1.1.0/quiz-program-v1.1.0.zip"
        self.sleep_calls = []

    def manifest_bytes(self, minimum="1.0.0", maximum="1.1.9", version="1.1.0"):
        package = getattr(self, "package", b"synthetic program package bytes")
        payload = {
            "version": version,
            "compatible_min": minimum,
            "compatible_max": maximum,
            "notes": "synthetic update",
            "tag": f"v{version}",
            "repository": "school/probability-quiz",
            "package_url": f"https://github.com/school/probability-quiz/releases/download/v{version}/quiz-program-v{version}.zip",
            "package_size": len(package),
            "package_sha256": hashlib.sha256(package).hexdigest(),
            "requirements_sha256": self.requirements_hash,
            "required_schema_version": 5,
            "key_id": "release-2026",
        }
        return (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode()

    def client(self, transport):
        return ReleaseClient(
            "school/probability-quiz",
            "release-2026",
            self.public_pem,
            transport=transport,
            sleep=self.sleep_calls.append,
        )

    def latest_replies(self, manifest=None, signature=None):
        manifest = self.raw_manifest if manifest is None else manifest
        signature = self.signature if signature is None else signature
        return {
            self.manifest_url: [FakeResponse(manifest, url=self.manifest_url)],
            self.signature_url: [FakeResponse(base64.b64encode(signature) + b"\n", url=self.signature_url)],
        }

    def test_404_latest_release_reports_no_update(self):
        transport = FakeTransport({self.manifest_url: [FakeResponse(status=404, url=self.manifest_url)]})
        self.assertIsNone(self.client(transport).latest("1.0.0"))
        self.assertEqual(len(transport.calls), 1)

    def test_valid_signed_manifest_returns_candidate_and_downloads(self):
        replies = self.latest_replies()
        transport = FakeTransport(replies)
        client = self.client(transport)
        candidate = client.latest("1.0.0")
        self.assertIsNotNone(candidate)
        self.assertEqual(candidate.manifest.version, "1.1.0")
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as folder:
            destination = Path(folder) / "package.zip"
            package_response = FakeResponse(self.package, url=self.package_url)
            transport.replies[self.package_url] = [package_response]
            self.assertEqual(client.download(candidate, destination), destination)
            self.assertEqual(destination.read_bytes(), self.package)

    def test_retries_transient_http_and_truncated_reads(self):
        replies = self.latest_replies()
        replies[self.manifest_url] = [FakeResponse(status=503, url=self.manifest_url), FakeResponse(self.raw_manifest, url=self.manifest_url)]
        transport = FakeTransport(replies)
        candidate = self.client(transport).latest("1.0.0")
        self.assertEqual(candidate.manifest.version, "1.1.0")
        self.assertEqual([call[0] for call in transport.calls].count(self.manifest_url), 2)

        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as folder:
            destination = Path(folder) / "package.zip"
            transport.replies[self.package_url] = [
                FakeResponse(self.package, url=self.package_url, fail_after_first=True),
                FakeResponse(self.package, url=self.package_url),
            ]
            self.client(transport).download(candidate, destination)
            self.assertEqual(destination.read_bytes(), self.package)

    def test_read_timeout_is_bounded_to_three_attempts(self):
        transport = FakeTransport({self.manifest_url: [TimeoutError("slow")] * 3})
        with self.assertRaises(ReleaseClientError):
            self.client(transport).latest("1.0.0")
        self.assertEqual(len(transport.calls), 3)

    def test_rejects_bad_signature_incompatible_version_and_untrusted_redirect(self):
        transport = FakeTransport(self.latest_replies(signature=b"bad"))
        with self.assertRaises(ReleaseClientError):
            self.client(transport).latest("1.0.0")

        incompatible = self.manifest_bytes(minimum="1.2.0", maximum="2.0.0")
        incompatible_sig = self.private.sign(
            incompatible,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        transport = FakeTransport(self.latest_replies(incompatible, incompatible_sig))
        with self.assertRaises(ReleaseClientError):
            self.client(transport).latest("1.0.0")

        candidate = UpdateCandidate(UpdateManifest.from_bytes(self.raw_manifest, "school/probability-quiz", "v1.1.0"))
        transport = FakeTransport({self.package_url: [FakeResponse(self.package, url="https://evil.example/package.zip")]})
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as folder:
            with self.assertRaises(DownloadError):
                self.client(transport).download(candidate, Path(folder) / "package.zip")

    def test_rejects_declared_length_and_package_digest_mismatch(self):
        candidate = UpdateCandidate(UpdateManifest.from_bytes(self.raw_manifest, "school/probability-quiz", "v1.1.0"))
        transport = FakeTransport({
            self.package_url: [
                FakeResponse(self.package, headers={"Content-Length": "1"}, url=self.package_url)
                for _ in range(3)
            ]
        })
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as folder:
            destination = Path(folder) / "package.zip"
            with self.assertRaises(DownloadError):
                self.client(transport).download(candidate, destination)
            self.assertFalse(destination.exists())


if __name__ == "__main__":
    unittest.main()
