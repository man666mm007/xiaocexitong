import json
import tempfile
import unittest
from pathlib import Path

from updater.config import UpdaterConfig


class UpdaterConfigTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.project = self.root / "project"
        self.data = self.project / "instance"
        self.assistant = self.root / "ProgramData" / "ProbabilityQuizUpdater"
        self.versions = self.assistant / "versions"
        self.work = self.assistant / "work"
        self.project.mkdir()
        self.data.mkdir()
        self.versions.mkdir(parents=True)
        self.work.mkdir()
        self.python = self.project / ".venv" / "Scripts" / "python.exe"
        self.python.parent.mkdir(parents=True)
        self.python.write_bytes(b"python")
        self.secret = self.project / "secret_key.txt"
        self.secret.write_text("synthetic-secret", encoding="utf-8")
        self.public_key = self.assistant / "public.pem"
        self.public_key.write_text("synthetic-public-key", encoding="utf-8")
        self.token = self.assistant / "agent.token"
        self.token.write_text("synthetic-token", encoding="utf-8")
        self.config_path = self.assistant / "config.json"
        self.config = {
            "program_root": str(self.project),
            "data_root": str(self.data),
            "versions_root": str(self.versions),
            "work_root": str(self.work),
            "python_executable": str(self.python),
            "repository": "school/probability-quiz",
            "public_key_path": str(self.public_key),
            "key_id": "release-2026",
            "secret_key_path": str(self.secret),
            "website_environment": {"QUIZ_URL_PREFIX": "/quiz", "QUIZ_SESSION_DAYS": "7"},
            "site_url": "http://127.0.0.1:5000/quiz/",
            "health_url": "http://127.0.0.1:5000/quiz/__updater_health",
            "agent_port": 58121,
            "agent_token_path": str(self.token),
            "backup_retention": 5,
        }
        self.write_config()

    def tearDown(self):
        self.temp.cleanup()

    def write_config(self):
        self.config_path.write_text(json.dumps(self.config), encoding="utf-8")

    def test_loads_valid_absolute_paths(self):
        config = UpdaterConfig.load(self.config_path)
        self.assertEqual(config.repository, "school/probability-quiz")
        self.assertEqual(config.data_root, self.data.resolve())
        self.assertEqual(config.agent_port, 58121)
        self.assertEqual(config.website_environment["QUIZ_URL_PREFIX"], "/quiz")

    def test_rejects_relative_paths(self):
        self.config["data_root"] = "instance"
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)

    def test_rejects_same_program_and_data_root(self):
        self.config["data_root"] = self.config["program_root"]
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)

    def test_rejects_non_github_repository(self):
        self.config["repository"] = "https://example.com/org/repo"
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)

    def test_rejects_privileged_agent_port(self):
        self.config["agent_port"] = 80
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)

    def test_requires_public_key_secret_and_token_files(self):
        for field in ("public_key_path", "secret_key_path", "agent_token_path"):
            with self.subTest(field=field):
                old = self.config[field]
                self.config[field] = str(self.root / "missing")
                self.write_config()
                with self.assertRaises(ValueError):
                    UpdaterConfig.load(self.config_path)
                self.config[field] = old

    def test_rejects_wrong_local_urls_and_url_prefix(self):
        self.config["site_url"] = "https://example.com/quiz/"
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)
        self.config["site_url"] = "http://127.0.0.1:5000/quiz/"
        self.config["website_environment"]["QUIZ_URL_PREFIX"] = "/other"
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)

    def test_rejects_invalid_retention_and_environment_keys(self):
        self.config["backup_retention"] = 21
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)
        self.config["backup_retention"] = 5
        self.config["website_environment"]["QUIZ_SECRET_KEY"] = "should-never-be-configured-here"
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)

    def test_rejects_assistant_paths_inside_source_or_data(self):
        self.config["versions_root"] = str(self.project / "versions")
        self.config["work_root"] = str(self.project / "work")
        self.write_config()
        with self.assertRaises(ValueError):
            UpdaterConfig.load(self.config_path)


if __name__ == "__main__":
    unittest.main()
