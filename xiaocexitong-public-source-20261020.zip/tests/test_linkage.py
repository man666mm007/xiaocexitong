import datetime
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from werkzeug.security import generate_password_hash
from app import create_app
from app.db import get_db, migrate_db


class LinkageTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.app = create_app(dict(TESTING=True, SECRET_KEY='test', DATABASE=str(root/'db.sqlite'),
                                   UPLOAD_ROOT=str(root/'uploads'), PENDING_ROOT=str(root/'pending')))
        self.client = self.app.test_client()
        with self.app.app_context():
            db = get_db()
            self.teacher = db.execute("INSERT INTO users(username,name,password_hash,role,must_change_password) VALUES('T','Teacher',?,'teacher',0)", (generate_password_hash('test-only-teacher-password'),)).lastrowid
            self.class_id = db.execute("INSERT INTO teaching_classes(display_name) VALUES('Test class')").lastrowid
            self.students = []
            for i in range(4):
                sid = db.execute("INSERT INTO users(username,name,password_hash,role,must_change_password) VALUES(?,?,?,'student',0)", (f'S{i}',f'Student {i}',generate_password_hash('Student123!'))).lastrowid
                db.execute("INSERT INTO student_classes(student_id,class_id) VALUES(?,?)", (sid,self.class_id))
                self.students.append(sid)
            db.commit()

    def tearDown(self):
        self.temp.cleanup()

    def test_unique_link_and_migration_idempotence(self):
        from app.classroom import create_classroom_item
        with self.app.app_context():
            db = get_db()
            db.execute('BEGIN IMMEDIATE')
            args = dict(class_id=self.class_id,class_date='2026-10-18',actor_id=self.teacher)
            first = create_classroom_item(db,kind='quiz',**args)
            again = create_classroom_item(db,kind='quiz',**args)
            self.assertEqual(first['item_id'],again['item_id'])
            self.assertFalse(again['created'])
            att = create_classroom_item(db,kind='attendance',attendance_options=dict(starts_at=1792281600,ends_at=1792282200,late_after=1792281900),**args)
            self.assertEqual(first['classroom_id'],att['classroom_id'])
            db.commit()
            before = list(db.iterdump())
            migrate_db()
            migrate_db()
            self.assertEqual(before,list(db.iterdump()))
            self.assertEqual([],db.execute('PRAGMA foreign_key_check').fetchall())

    def test_legacy_attendance_date_requires_matching_title(self):
        from app.classroom import legacy_attendance_date
        from app.timezone import SHANGHAI_TIMEZONE
        ts = int(datetime.datetime(2026,10,18,9,tzinfo=SHANGHAI_TIMEZONE).timestamp())
        self.assertEqual('2026-10-18',legacy_attendance_date('10月18日签到',ts))
        self.assertIsNone(legacy_attendance_date('10月19日签到',ts))

    def test_submission_and_effective_state(self):
        from app.submissions import submission_from_answers
        from app.attendance_state import effective_attendance, attendance_window_state
        self.assertEqual('unsubmitted',submission_from_answers({1:'blank',2:'blank'},2))
        self.assertEqual('submitted',submission_from_answers({1:'correct',2:'wrong'},2))
        with self.assertRaises(ValueError): submission_from_answers({1:'blank'},2)
        self.assertEqual('absent',effective_attendance('normal','absent'))
        self.assertEqual(['scheduled','open_normal','open_late','ended'],[attendance_window_state(now=n,starts_at=100,late_after=130,ends_at=200) for n in (99,100,130,200)])

    def auth(self, user=None, client=None):
        client=client or self.client
        with client.session_transaction() as sess:
            sess['user_id']=self.teacher if user is None else user
            sess['session_version']=0; sess['csrf_token']='csrf-test'
        return client

    def post(self,url,data=None,client=None):
        return (client or self.client).post(url,data=dict(csrf_token='csrf-test',**(data or {})))

    def room(self, day='2027-01-04', kind='both'):
        from app.classroom import create_classroom_item
        from app.attendance_schedule import single_occurrence
        db=get_db(); db.execute('BEGIN IMMEDIATE')
        args=dict(class_id=self.class_id,class_date=day,actor_id=self.teacher)
        result=create_classroom_item(db,kind='quiz' if kind=='quiz' else 'attendance',attendance_options=single_occurrence(day,'09:00','10:00',5),**args)
        if kind=='both': create_classroom_item(db,kind='quiz',**args)
        db.commit()
        return dict(db.execute('SELECT * FROM classroom_sessions WHERE id=?',(result['classroom_id'],)).fetchone())

    def upload(self,qid,values,action='keep',confirm=True):
        import io
        content='student_id,score,1,2\n'+'\n'.join(','.join(str(v) for v in r) for r in values)
        r=self.client.post(f'/teacher/quizzes/{qid}/import',data={'csrf_token':'csrf-test','score_file':(io.BytesIO(content.encode()),'test.csv')},content_type='multipart/form-data')
        self.assertEqual(302,r.status_code)
        bid=r.location.split('/')[-2]
        preview=self.client.get(r.location)
        self.assertEqual(200,preview.status_code)
        if confirm:
            result=self.post(f'/teacher/quizzes/{qid}/import/{bid}/confirm',dict(old_scores_action=action))
            self.assertEqual(302,result.status_code)
        return bid,preview.get_data(as_text=True)

    def test_all_zero_import_publish_and_student_without_score(self):
        self.auth()
        with self.app.app_context(): room=self.room(kind='quiz'); qid=room['quiz_id']
        bid,preview=self.upload(qid,[('S0',0,0,0)],confirm=False)
        with self.app.app_context():
            db=get_db()
            self.assertEqual(0,db.execute('SELECT COUNT(*) FROM quiz_submissions').fetchone()[0])
            self.assertIsNone(db.execute('SELECT total_score FROM quizzes WHERE id=?',(qid,)).fetchone()[0])
        self.post(f'/teacher/quizzes/{qid}/import/{bid}/confirm')
        self.post(f'/teacher/quizzes/{qid}/publish')
        with self.app.app_context():
            db=get_db()
            self.assertEqual('unsubmitted',db.execute('SELECT status FROM quiz_submissions').fetchone()[0])
            self.assertEqual(0,db.execute('SELECT COUNT(*) FROM scores').fetchone()[0])
            self.assertEqual(1,db.execute('SELECT published FROM quizzes WHERE id=?',(qid,)).fetchone()[0])
        self.auth(self.students[0])
        page=self.client.get(f'/student/quizzes/{qid}')
        self.assertEqual(200,page.status_code); self.assertIn('未交',page.get_data(as_text=True))
        self.assertIn('未交',self.client.get('/student/quizzes').get_data(as_text=True))

    def test_reimport_snapshots_zero_negative_keep_remove_and_preview_staleness(self):
        self.auth()
        with self.app.app_context(): room=self.room(); qid=room['quiz_id']
        self.upload(qid,[('S0',0,1,-1),('S1',-1,-1,0)])
        with self.app.app_context():
            self.assertEqual([-1,0],sorted(r[0] for r in get_db().execute('SELECT score FROM scores')))
        self.upload(qid,[('S0',0,0,0)],action='keep')
        with self.app.app_context():
            db=get_db()
            self.assertEqual([-1],[r[0] for r in db.execute('SELECT score FROM scores')])
            event=db.execute('SELECT * FROM quiz_submission_events WHERE student_id=? ORDER BY id DESC',(self.students[0],)).fetchone()
            self.assertEqual(0,json.loads(event['before_json'])['score']['score'])
            self.assertIsNone(json.loads(event['after_json'])['score'])
            self.assertEqual({'1':'blank','2':'blank'},json.loads(event['after_json'])['imported_answers'])
        self.upload(qid,[('S0',2,1,1)],action='remove')
        with self.app.app_context():
            db=get_db()
            self.assertIsNone(db.execute('SELECT 1 FROM quiz_submissions WHERE student_id=?',(self.students[1],)).fetchone())
        bid,_=self.upload(qid,[('S0',-2,-1,-1)],confirm=False)
        with self.app.app_context():
            db=get_db(); db.execute('UPDATE scores SET score=1'); db.commit()
        self.post(f'/teacher/quizzes/{qid}/import/{bid}/confirm')
        with self.app.app_context():
            self.assertEqual(1,get_db().execute('SELECT score FROM scores').fetchone()[0])

    def test_invalid_import_does_not_partially_confirm(self):
        self.auth()
        with self.app.app_context(): room=self.room(kind='quiz'); qid=room['quiz_id']
        _,preview=self.upload(qid,[('S0',1,0,0),('S1',2,1,1)])
        self.assertIn('不一致',preview)
        with self.app.app_context():
            self.assertEqual(0,get_db().execute('SELECT COUNT(*) FROM scores').fetchone()[0])
            self.assertEqual(0,get_db().execute('SELECT COUNT(*) FROM quiz_submissions').fetchone()[0])

    def test_four_combinations_filters_exports_and_hidden_results(self):
        from app.attendance_state import adjust_attendance
        from app.classroom import classroom_rows
        self.auth()
        with self.app.app_context(): room=self.room(); qid=room['quiz_id']; aid=room['attendance_session_id']
        from app.attendance_schedule import single_occurrence
        self.app.config['ATTENDANCE_CLOCK']=lambda:single_occurrence('2027-01-04','09:00','10:00',5)['ends_at']
        self.upload(qid,[('S0',2,1,1),('S1',0,0,0),('S2',-2,-1,-1),('S3',0,0,0)])
        with self.app.app_context():
            db=get_db(); db.execute('BEGIN IMMEDIATE')
            for sid in self.students[:2]: adjust_attendance(db,session_id=aid,student_id=sid,status='normal',reason='漏签',expected_version=0,actor_id=self.teacher,now=1792281600)
            db.commit()
            rows=classroom_rows(db,classroom_id=room['id'])
            self.assertEqual({('参加','已交'),('参加','未交'),('未参加','已交'),('未参加','未交')},{(r['participation_label'],r['submission_label']) for r in rows})
            own=classroom_rows(db,classroom_id=room['id'],student_id=self.students[0])[0]
            self.assertNotIn('score',own); self.assertNotIn('reason',own)
        self.assertIn('S1',self.client.get(f"/teacher/classrooms/{room['id']}?filter=present_unsubmitted").get_data(as_text=True))
        body=self.client.get(f"/teacher/classrooms/{room['id']}/export").get_data(as_text=True)
        self.assertIn('2027-01-04',body); self.assertIn('漏签',body); self.assertIn('-2',body)
        self.auth(self.students[0])
        body=self.client.get(f'/student/quizzes/{qid}').get_data(as_text=True)
        self.assertIn('已交',body); self.assertIn('成绩未发布',body)
        self.assertNotIn('漏签',body); self.assertNotIn('Student 1',body); self.assertNotIn('我的逐题作答',body)

    def test_adjust_after_end_version_permissions_and_raw_preservation(self):
        self.auth()
        with self.app.app_context():
            room=self.room(); aid=room['attendance_session_id']; db=get_db()
            db.execute("INSERT INTO attendance_records(session_id,student_id,signed_at,status) VALUES(?,?,1,'normal')",(aid,self.students[0])); db.execute('UPDATE attendance_sessions SET active=0,closed_at=2 WHERE id=?',(aid,)); db.commit()
        url=f'/teacher/attendance/{aid}/students/{self.students[0]}/adjust'
        self.assertEqual(302,self.post(url,dict(status='absent',reason='误签到',version=0)).status_code)
        self.assertEqual(409,self.post(url,dict(status='normal',reason='冲突',version=0)).status_code)
        self.assertEqual(409,self.post(url,dict(status='normal',reason='',version=1)).status_code)
        with self.app.app_context():
            db=get_db()
            self.assertEqual('normal',db.execute('SELECT status FROM attendance_records').fetchone()[0])
            self.assertEqual(1,db.execute('SELECT COUNT(*) FROM attendance_adjustment_events').fetchone()[0])
        self.auth(self.students[0]); self.post(url,dict(status='normal',reason='越权',version=1))
        with self.app.app_context(): self.assertEqual('absent',get_db().execute('SELECT status FROM attendance_adjustments').fetchone()[0])

    def schedule_rule(self):
        return dict(start_date='2027-01-04',end_date='2027-01-18',week1_monday='2027-01-04',slots=[dict(weekday=0,start='09:00',end='10:00',late_minutes=5)],weeks=None,skip_dates=[])

    def schedule_preview(self):
        self.auth()
        r=self.post('/teacher/attendance/schedules/create',dict(class_id=self.class_id,rule_json=json.dumps(self.schedule_rule())))
        self.assertEqual(302,r.status_code)
        self.assertEqual(200,self.client.get(r.location).status_code)
        return r.location.rsplit('/',1)[1]

    def test_schedule_preview_confirm_conflict_atomic_and_repeat_confirmation(self):
        bid=self.schedule_preview()
        with self.app.app_context():
            self.assertEqual(0,get_db().execute('SELECT COUNT(*) FROM classroom_sessions').fetchone()[0])
            self.room(day='2027-01-11',kind='quiz')
        r=self.post('/teacher/attendance/schedules/confirm/'+bid)
        self.assertEqual(409,r.status_code)
        with self.app.app_context():
            self.assertEqual(0,get_db().execute('SELECT COUNT(*) FROM attendance_schedule_rules').fetchone()[0])
            self.assertEqual(1,get_db().execute('SELECT COUNT(*) FROM classroom_sessions').fetchone()[0])
            get_db().execute('DELETE FROM quizzes');get_db().execute('DELETE FROM classroom_sessions');get_db().commit()
        self.assertEqual(302,self.post('/teacher/attendance/schedules/confirm/'+bid).status_code)
        self.assertEqual(302,self.post('/teacher/attendance/schedules/confirm/'+bid).status_code)
        with self.app.app_context():
            self.assertEqual(3,get_db().execute('SELECT COUNT(*) FROM classroom_sessions').fetchone()[0])
            self.assertEqual(1,get_db().execute('SELECT COUNT(*) FROM attendance_schedule_rules').fetchone()[0])

    def test_cancel_reschedule_revision_and_disable(self):
        from app.attendance_schedule import edit_occurrence,revise_schedule,disable_schedule
        bid=self.schedule_preview(); self.post('/teacher/attendance/schedules/confirm/'+bid)
        with self.app.app_context():
            db=get_db(); rooms=db.execute('SELECT * FROM classroom_sessions ORDER BY class_date').fetchall(); rid=db.execute('SELECT id FROM attendance_schedule_rules').fetchone()[0]
            db.execute('BEGIN IMMEDIATE')
            edit_occurrence(db,classroom_id=rooms[0]['id'],changes={'cancel':True},actor_id=self.teacher,now=1792281600,expected_version=0)
            db.commit()
            db.execute('BEGIN IMMEDIATE')
            with self.assertRaises(ValueError): edit_occurrence(db,classroom_id=rooms[1]['id'],changes=dict(class_date='2027-01-18',start='09:00',end='10:00',late_minutes=5),actor_id=self.teacher,now=1792281600,expected_version=0)
            db.rollback()
            db.execute('BEGIN IMMEDIATE')
            revise_schedule(db,rule_id=rid,effective_date='2027-01-04',changes={},actor_id=self.teacher,now=1792281600,expected_revision=1)
            db.commit()
            self.assertEqual('cancelled',db.execute('SELECT state FROM classroom_sessions WHERE id=?',(rooms[0]['id'],)).fetchone()[0])
            self.assertEqual(3,db.execute('SELECT COUNT(*) FROM classroom_sessions').fetchone()[0])
            db.execute('BEGIN IMMEDIATE'); disable_schedule(db,rule_id=rid,expected_revision=2,now=1792281600);db.commit()
            self.assertEqual(0,db.execute("SELECT COUNT(*) FROM classroom_sessions WHERE state='ready'").fetchone()[0])

    def test_window_qr_scan_override_restart_and_class_archive(self):
        from app.attendance_qr import make_token
        self.auth()
        with self.app.app_context():
            room=self.room(); db=get_db(); att=dict(db.execute('SELECT * FROM attendance_sessions').fetchone()); start=att['starts_at']
        aid=att['id']; endpoint=f'/teacher/attendance/{aid}/qr'
        self.app.config['ATTENDANCE_CLOCK']=lambda:start-1
        qr=self.client.get(endpoint).get_json(); self.assertEqual('scheduled',qr['state']); self.assertIsNone(qr['url'])
        self.app.config['ATTENDANCE_CLOCK']=lambda:start
        qr=self.client.get(endpoint).get_json(); self.assertTrue(qr['open'])
        self.auth(self.students[0]); self.client.get(qr['url'])
        with self.app.app_context(): self.assertEqual('normal',get_db().execute('SELECT status FROM attendance_records').fetchone()[0])
        self.auth(); self.post(f'/teacher/attendance/{aid}/students/{self.students[1]}/adjust',dict(status='absent',reason='误签到',version=0))
        self.auth(self.students[1]); self.client.get(qr['url'])
        with self.app.app_context(): self.assertEqual(1,get_db().execute('SELECT COUNT(*) FROM attendance_records').fetchone()[0])
        self.app.config['ATTENDANCE_CLOCK']=lambda:att['ends_at']; self.auth()
        self.assertIsNone(self.client.get(endpoint).get_json()['url'])
        self.auth(self.students[2]); self.client.get(qr['url'])
        with self.app.app_context(): self.assertEqual(1,get_db().execute('SELECT COUNT(*) FROM attendance_records').fetchone()[0])
        restarted=create_app(dict(self.app.config))
        with restarted.app_context():
            from app.attendance_state import session_state
            db=get_db(); self.assertEqual('ended',session_state(db,att))
            db.execute('UPDATE teaching_classes SET archived_at=1');db.commit()
            self.assertEqual('disabled',session_state(db,att,start))

    def test_concurrent_creation_and_cross_class_identity(self):
        from concurrent.futures import ThreadPoolExecutor
        from threading import Barrier
        from app.classroom import create_classroom_item
        barrier=Barrier(2)
        def create(_):
            with self.app.app_context():
                db=get_db(); barrier.wait(); db.execute('BEGIN IMMEDIATE')
                result=create_classroom_item(db,class_id=self.class_id,class_date='2027-01-04',kind='quiz',actor_id=self.teacher)
                db.commit(); return result['item_id']
        with ThreadPoolExecutor(max_workers=2) as pool: ids=list(pool.map(create,range(2)))
        self.assertEqual(ids[0],ids[1])
        with self.app.app_context():
            db=get_db(); other=db.execute("INSERT INTO teaching_classes(display_name) VALUES('Other')").lastrowid;db.commit()
            db.execute('BEGIN IMMEDIATE'); r=create_classroom_item(db,class_id=other,class_date='2027-01-04',kind='quiz',actor_id=self.teacher);db.commit()
            self.assertNotEqual(ids[0],r['item_id'])

    def test_legacy_migration_conflicts_unknown_dates_and_rollback(self):
        from unittest.mock import patch
        from app.timezone import SHANGHAI_TIMEZONE
        ts=int(datetime.datetime(2026,10,18,9,tzinfo=SHANGHAI_TIMEZONE).timestamp())
        with self.app.app_context():
            db=get_db(); db.execute('DELETE FROM schema_migrations WHERE version=3')
            for _ in range(2): db.execute("INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,created_by) VALUES('Old','2026-10-18','Test class',?,10,?)",(self.class_id,self.teacher))
            db.execute("INSERT INTO attendance_sessions(title,class_name,class_id,code,starts_at,late_after,ends_at,created_by) VALUES('10月19日签到','Test class',?,'',?,?,?,?)",(self.class_id,ts,ts+60,ts+600,self.teacher));db.commit()
            before=list(db.iterdump())
            with patch('app.classroom.backfill_classrooms',side_effect=RuntimeError('fault')):
                with self.assertRaises(RuntimeError): migrate_db()
            self.assertEqual(before,list(db.iterdump()))
            migrate_db()
            self.assertEqual('conflict',db.execute('SELECT state FROM classroom_sessions').fetchone()[0])
            self.assertIsNone(db.execute('SELECT attendance_date FROM attendance_sessions').fetchone()[0])
            migrated=list(db.iterdump());migrate_db(); self.assertEqual(migrated,list(db.iterdump()))
        self.auth();self.assertEqual(200,self.client.get('/teacher/classrooms/conflicts').status_code)

    def test_single_reschedule_preserves_ids_and_origin_exception(self):
        from app.attendance_schedule import edit_occurrence,revise_schedule,preview_revision
        bid=self.schedule_preview(); self.post('/teacher/attendance/schedules/confirm/'+bid)
        with self.app.app_context():
            db=get_db(); room=dict(db.execute('SELECT * FROM classroom_sessions ORDER BY class_date').fetchone()); rule_id=db.execute('SELECT id FROM attendance_schedule_rules').fetchone()[0]
            db.execute('BEGIN IMMEDIATE')
            edit_occurrence(db,classroom_id=room['id'],changes=dict(class_date='2027-01-05',start='11:00',end='11:20',late_minutes=None),actor_id=self.teacher,now=1792281600,expected_version=0)
            db.commit()
            self.assertEqual('2027-01-05',db.execute('SELECT quiz_date FROM quizzes WHERE id=?',(room['quiz_id'],)).fetchone()[0])
            preview=preview_revision(db,rule_id=rule_id,effective_date='2027-01-04',changes={},actor_id=self.teacher,now=1792281600,expected_revision=1)
            self.assertNotIn('2027-01-04',[r['class_date'] for r in preview['occurrences']])
            db.execute('BEGIN IMMEDIATE'); revise_schedule(db,rule_id=rule_id,effective_date='2027-01-04',changes={},actor_id=self.teacher,now=1792281600,expected_revision=1);db.commit()
            self.assertEqual(3,db.execute('SELECT COUNT(*) FROM classroom_sessions').fetchone()[0])
            self.assertEqual(room['attendance_session_id'],db.execute('SELECT attendance_session_id FROM classroom_sessions WHERE id=?',(room['id'],)).fetchone()[0])
        self.auth(); self.assertEqual(200,self.client.get(f"/teacher/classrooms/{room['id']}/reschedule").status_code)

    def test_revision_conflict_rolls_back_and_revision_preview_routes(self):
        bid=self.schedule_preview(); self.post('/teacher/attendance/schedules/confirm/'+bid)
        with self.app.app_context():
            room=self.room(day='2027-01-05',kind='quiz');db=get_db();rule_id=db.execute('SELECT id FROM attendance_schedule_rules').fetchone()[0]
        rule=self.schedule_rule();rule['slots'][0]['weekday']=1
        r=self.post(f'/teacher/attendance/schedules/{rule_id}/revise',dict(rule_json=json.dumps(rule),effective_date='2027-01-04',revision=1))
        self.assertEqual(302,r.status_code); page=self.client.get(r.location)
        self.assertIn('该日已有课堂',page.get_data(as_text=True))
        batch=r.location.rsplit('/',1)[1]
        with self.app.app_context(): before=list(get_db().iterdump())
        self.assertEqual(409,self.post('/teacher/attendance/schedules/confirm/'+batch).status_code)
        with self.app.app_context(): self.assertEqual(before,list(get_db().iterdump()))
        self.assertEqual(200,self.client.get(f'/teacher/attendance/schedules/{rule_id}/revise').status_code)
        self.assertEqual(200,self.client.get(f'/teacher/attendance/schedules/{rule_id}/disable').status_code)

    def test_archive_restore_keeps_rule_disabled_and_recycle_link(self):
        bid=self.schedule_preview();self.post('/teacher/attendance/schedules/confirm/'+bid)
        self.post(f'/teacher/classes/{self.class_id}/archive',dict(confirm_name='Test class'))
        with self.app.app_context():
            db=get_db(); self.assertEqual(0,db.execute('SELECT enabled FROM attendance_schedule_rules').fetchone()[0]); batch=db.execute('SELECT id FROM class_trash').fetchone()[0]
        self.post('/teacher/trash/classes/'+batch+'/restore')
        with self.app.app_context():
            db=get_db(); self.assertEqual(0,db.execute('SELECT enabled FROM attendance_schedule_rules').fetchone()[0]);self.assertEqual(0,db.execute('SELECT MAX(active) FROM attendance_sessions').fetchone()[0])
            room=dict(db.execute('SELECT * FROM classroom_sessions ORDER BY id').fetchone())
        self.post(f"/teacher/attendance/{room['attendance_session_id']}/delete")
        with self.app.app_context():
            db=get_db();batch=db.execute("SELECT id FROM record_trash WHERE kind='attendance'").fetchone()[0]
            self.assertEqual(room['attendance_session_id'],db.execute('SELECT attendance_session_id FROM classroom_sessions WHERE id=?',(room['id'],)).fetchone()[0])
        self.post('/teacher/trash/records/'+batch+'/purge')
        with self.app.app_context(): self.assertIsNone(get_db().execute('SELECT attendance_session_id FROM classroom_sessions WHERE id=?',(room['id'],)).fetchone()[0])

    def test_student_forbidden_csrf_cross_class_and_used_cancellation(self):
        self.auth()
        with self.app.app_context():
            room=self.room();db=get_db();other=db.execute("INSERT INTO users(username,name,password_hash,role,must_change_password) VALUES('OTHER','Other','unused','student',0)").lastrowid;db.commit()
        aid=room['attendance_session_id']; url=f'/teacher/attendance/{aid}/students/{self.students[0]}/adjust'
        self.auth(self.students[0]);self.assertEqual(403,self.post(url,dict(status='normal',reason='forbidden',version=0)).status_code)
        self.auth();self.assertEqual(400,self.client.post(url,data=dict(status='normal',reason='csrf missing',version=0)).status_code)
        self.assertEqual(409,self.post(f'/teacher/attendance/{aid}/students/{other}/adjust',dict(status='normal',reason='other class',version=0)).status_code)
        self.post(url,dict(status='normal',reason='漏签',version=0))
        self.assertEqual(409,self.post(f"/teacher/classrooms/{room['id']}/cancel",dict(version=0)).status_code)

    def test_score_statistics_exclude_only_unsubmitted(self):
        from app.stats import question_statistics
        self.auth()
        with self.app.app_context(): room=self.room(kind='quiz')
        qid=room['quiz_id']; self.upload(qid,[('S0',0,1,-1),('S1',-2,-1,-1),('S2',2,1,1),('S3',0,0,0)])
        self.post(f'/teacher/quizzes/{qid}/publish')
        with self.app.app_context():
            db=get_db();stat=db.execute('SELECT COUNT(*),AVG(score),MIN(score),MAX(score) FROM scores').fetchone()
            self.assertEqual((3,0,-2,2),tuple(stat))
            self.assertEqual([3,3],[r['total'] for r in question_statistics(db,qid)])

    def test_late_boundary_late_disabled_end_and_review_flags(self):
        self.auth()
        with self.app.app_context(): room=self.room(); att=dict(get_db().execute('SELECT * FROM attendance_sessions').fetchone())
        aid=att['id']; endpoint=f'/teacher/attendance/{aid}/qr'
        self.app.config['ATTENDANCE_CLOCK']=lambda:att['late_after']
        qr=self.client.get(endpoint).get_json();self.assertEqual('open_late',qr['state'])
        self.auth(self.students[0]);self.client.get(qr['url'])
        with self.app.app_context():
            db=get_db();self.assertEqual('late',db.execute('SELECT status FROM attendance_records').fetchone()[0]);db.execute('UPDATE attendance_sessions SET late_enabled=0');db.commit()
        self.auth();qr=self.client.get(endpoint).get_json();self.assertEqual('open_normal',qr['state'])
        self.auth(self.students[1]);self.client.get(qr['url'])
        with self.app.app_context(): self.assertEqual('normal',get_db().execute('SELECT status FROM attendance_records WHERE student_id=?',(self.students[1],)).fetchone()[0])
        self.auth();self.post(f"/teacher/classrooms/{room['id']}/review",dict(note='服务中断待核查',version=0,needs_review=1))
        self.assertEqual('disabled',self.client.get(endpoint).get_json()['state'])

    def test_both_creation_orders_and_year_identity(self):
        from app.classroom import create_classroom_item
        from app.attendance_schedule import single_occurrence
        with self.app.app_context():
            db=get_db(); first=self.room(day='2027-01-04',kind='quiz')
            db.execute('BEGIN IMMEDIATE')
            att=create_classroom_item(db,class_id=self.class_id,class_date='2027-01-04',kind='attendance',actor_id=self.teacher,attendance_options=single_occurrence('2027-01-04','09:00','10:00',5));db.commit()
            self.assertEqual(first['id'],att['classroom_id'])
            future=self.room(day='2028-01-04',kind='attendance'); db.execute('BEGIN IMMEDIATE')
            quiz=create_classroom_item(db,class_id=self.class_id,class_date='2028-01-04',kind='quiz',actor_id=self.teacher);db.commit()
            self.assertEqual(future['id'],quiz['classroom_id']); self.assertNotEqual(first['id'],future['id'])

    def test_purged_cancelled_child_can_be_rebuilt_without_automatic_enable(self):
        from app.classroom import create_classroom_item
        from app.attendance_schedule import edit_occurrence,single_occurrence
        with self.app.app_context():
            room=self.room(); db=get_db();db.execute('BEGIN IMMEDIATE')
            edit_occurrence(db,classroom_id=room['id'],changes={'cancel':True},actor_id=self.teacher,now=1792281600,expected_version=0)
            db.execute('DELETE FROM attendance_sessions WHERE id=?',(room['attendance_session_id'],));db.commit()
            db.execute('BEGIN IMMEDIATE')
            item=create_classroom_item(db,class_id=self.class_id,class_date='2027-01-04',kind='attendance',actor_id=self.teacher,attendance_options=single_occurrence('2027-01-04','09:00','10:00',5));db.commit()
            self.assertEqual(room['id'],item['classroom_id']); self.assertNotEqual(room['attendance_session_id'],item['item_id'])
            self.assertEqual(0,db.execute('SELECT active FROM attendance_sessions').fetchone()[0])
            self.assertEqual('cancelled',db.execute('SELECT state FROM classroom_sessions').fetchone()[0])

    def test_version4_repairs_total_only_history_already_migrated_to_v3(self):
        from app.classroom import classroom_rows
        with self.app.app_context():
            room=self.room(kind='quiz');db=get_db();qid=room['quiz_id']
            db.execute("UPDATE quizzes SET scoring_mode='legacy',total_score=100,published=1,results_confirmed_at=1 WHERE id=?",(qid,))
            for i,value in enumerate((88,-2,0,0)):
                sid=db.execute('INSERT INTO scores(quiz_id,student_id,score) VALUES(?,?,?)',(qid,self.students[i],value)).lastrowid
                if i==3:
                    db.execute("INSERT INTO answer_details(score_id,number,is_correct,answer_status) VALUES(?,1,1,'correct'),(?,2,0,'wrong')",(sid,sid))
                    db.execute("INSERT INTO quiz_submissions(quiz_id,student_id,status,source,confirmed_at) VALUES(?,?,'submitted','import',1)",(qid,self.students[i]))
            db.execute('DELETE FROM schema_migrations WHERE version=4');db.commit()
            scores=[tuple(r) for r in db.execute('SELECT * FROM scores ORDER BY id')]
            users=[tuple(r) for r in db.execute('SELECT * FROM users ORDER BY id')]
            migrate_db()
            rows=classroom_rows(db,classroom_id=room['id'])
            self.assertEqual(['已交','已交','待核查','已交'],[r['submission_label'] for r in rows])
            self.assertEqual(scores,[tuple(r) for r in db.execute('SELECT * FROM scores ORDER BY id')])
            self.assertEqual(users,[tuple(r) for r in db.execute('SELECT * FROM users ORDER BY id')])
            self.assertEqual('import',db.execute('SELECT source FROM quiz_submissions WHERE student_id=?',(self.students[3],)).fetchone()[0])
            self.assertEqual(1,db.execute('SELECT published FROM quizzes WHERE id=?',(qid,)).fetchone()[0])
            first=list(db.iterdump());migrate_db();self.assertEqual(first,list(db.iterdump()))
        self.auth(self.students[0]);body=self.client.get(f'/student/quizzes/{qid}').get_data(as_text=True)
        self.assertIn('已交',body);self.assertNotIn('无成绩记录',body)

    def test_quiz_detail_labels_grade_count_and_empty_statistics(self):
        import re
        self.auth()
        with self.app.app_context(): room=self.room();qid=room['quiz_id']
        self.upload(qid,[('S0',2,1,1),('S1',0,0,0),('S2',0,0,0),('S3',0,0,0)])
        body=self.client.get(f'/teacher/quizzes/{qid}').get_data(as_text=True)
        self.assertNotIn('参考人数',body)
        self.assertRegex(body,r'有效成绩人数</span><strong>1</strong>')
        self.upload(qid,[('S0',0,0,0),('S1',0,0,0),('S2',0,0,0),('S3',0,0,0)])
        body=self.client.get(f'/teacher/quizzes/{qid}').get_data(as_text=True)
        self.assertRegex(body,r'有效成绩人数</span><strong>0</strong>')
        self.assertRegex(body,r'平均分</span><strong>—</strong>')
