import importlib.util
import os
import sys
import types
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
START_SERVER = ROOT / "scripts" / "start_server.py"


class FakeServer:
    def run(self):
        return None

    def close(self):
        return None


class StartServerManagedModeTests(unittest.TestCase):
    def load_module(self):
        fake_waitress = types.ModuleType("waitress")
        fake_waitress.create_server = mock.Mock(return_value=FakeServer())
        fake_wsgi = types.ModuleType("wsgi")
        fake_wsgi.app = object()
        with mock.patch.dict(sys.modules, {"waitress": fake_waitress, "wsgi": fake_wsgi}):
            name = f"start_server_test_{id(self)}"
            spec = importlib.util.spec_from_file_location(name, START_SERVER)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
        return module

    def test_managed_service_skips_browser_thread(self):
        module = self.load_module()
        with mock.patch.dict(os.environ, {"QUIZ_MANAGED_SERVICE": "1"}), mock.patch.object(
            module.threading, "Thread"
        ) as thread_type:
            self.assertEqual(module.main(), 0)
        thread_type.assert_not_called()

    def test_desktop_mode_keeps_browser_ready_thread(self):
        module = self.load_module()
        with mock.patch.dict(os.environ, {}, clear=True), mock.patch.object(module.threading, "Thread") as thread_type:
            self.assertEqual(module.main(), 0)
        thread_type.assert_called_once()
        self.assertIs(thread_type.call_args.kwargs["target"], module._open_browser_when_ready)


if __name__ == "__main__":
    unittest.main()
