import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from updater.process_manager import SiteProcessManager


class SiteProcessManagerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.root = Path(self.temp.name)
        self.version = self.root / "versions" / "1.0.0"
        (self.version / "scripts").mkdir(parents=True)
        (self.version / "scripts" / "start_server.py").write_text("pass", encoding="utf-8")
        self.secret = self.root / "secret_key.txt"
        self.secret.write_text("synthetic-site-key\n", encoding="utf-8")
        self.config = SimpleNamespace(
            python_executable=Path(sys.executable),
            secret_key_path=self.secret,
            website_environment={"QUIZ_URL_PREFIX": "/quiz", "QUIZ_SESSION_DAYS": "7"},
            data_root=self.root / "instance",
            agent_port=58121,
            agent_token_path=self.root / "agent.token",
        )
        self.config.data_root.mkdir()
        self.config.agent_token_path.write_text("synthetic-agent-token", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def test_starts_and_stops_an_independent_child_process(self):
        manager = SiteProcessManager(
            self.config,
            command_factory=lambda _version: [sys.executable, "-c", "import time; time.sleep(60)"],
        )
        manager.start(self.version)
        pid = manager.pid
        self.assertIsInstance(pid, int)
        manager.stop(timeout_seconds=1)
        self.assertIsNone(manager.pid)
        manager.stop(timeout_seconds=1)

    def test_child_environment_uses_configured_data_and_strips_external_secrets(self):
        manager = SiteProcessManager(self.config)
        manager.health_token = "per-process-health-token"
        with mock.patch.dict(
            os.environ,
            {
                "QUIZ_INSTANCE_DIR": "attacker-instance",
                "QUIZ_SECRET_KEY": "attacker-secret",
                "QUIZ_UPDATE_HEALTH_TOKEN": "attacker-health-token",
                "PYTHONPATH": "attacker-python-path",
                "PATH": os.environ.get("PATH", ""),
            },
            clear=True,
        ):
            env = manager._child_environment()
        self.assertEqual(env["QUIZ_INSTANCE_DIR"], str(self.config.data_root))
        self.assertEqual(env["QUIZ_SECRET_KEY"], "synthetic-site-key")
        self.assertEqual(env["QUIZ_UPDATE_HEALTH_TOKEN"], "per-process-health-token")
        self.assertEqual(env["QUIZ_UPDATER_AGENT_TOKEN_FILE"], str(self.config.agent_token_path))
        self.assertEqual(env["QUIZ_MANAGED_SERVICE"], "1")
        self.assertNotIn("PYTHONPATH", env)

    def test_rejects_missing_entry_point_before_launch(self):
        manager = SiteProcessManager(self.config)
        with self.assertRaises(Exception):
            manager.start(self.root / "missing")
        self.assertIsNone(manager.pid)


if __name__ == "__main__":
    unittest.main()
