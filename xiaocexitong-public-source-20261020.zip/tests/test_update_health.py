import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from app import create_app


class UpdaterHealthEndpointTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.root = Path(self.temp.name)
        self.app = create_app(
            {
                "TESTING": True,
                "SECRET_KEY": "synthetic-health-test-key",
                "DATABASE": str(self.root / "instance" / "quiz.sqlite3"),
                "UPLOAD_ROOT": str(self.root / "instance" / "uploads"),
                "PENDING_ROOT": str(self.root / "instance" / "pending"),
                "URL_PREFIX": "/quiz",
                "APP_VERSION": "1.0.0",
            }
        )
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp.cleanup()

    def test_requires_token_and_returns_database_version_only_to_loopback(self):
        with mock.patch.dict(os.environ, {"QUIZ_UPDATE_HEALTH_TOKEN": "synthetic-health-token"}):
            self.assertEqual(self.client.get("/quiz/__updater_health").status_code, 404)
            response = self.client.get(
                "/quiz/__updater_health",
                headers={"X-Quiz-Updater-Token": "synthetic-health-token"},
                environ_base={"REMOTE_ADDR": "127.0.0.1"},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), {"version": "1.0.0", "database_ok": True, "schema_version": 5})

    def test_forwarded_loopback_header_cannot_spoof_remote_peer(self):
        with mock.patch.dict(os.environ, {"QUIZ_UPDATE_HEALTH_TOKEN": "synthetic-health-token"}):
            response = self.client.get(
                "/quiz/__updater_health",
                headers={
                    "X-Quiz-Updater-Token": "synthetic-health-token",
                    "X-Forwarded-For": "127.0.0.1",
                },
                environ_base={"REMOTE_ADDR": "198.51.100.24"},
            )
        self.assertEqual(response.status_code, 404)

    def test_reports_database_not_ready_without_paths_or_details(self):
        self.app.config["DATABASE"] = str(self.root / "missing" / "database.sqlite3")
        with mock.patch.dict(os.environ, {"QUIZ_UPDATE_HEALTH_TOKEN": "synthetic-health-token"}):
            response = self.client.get(
                "/quiz/__updater_health",
                headers={"X-Quiz-Updater-Token": "synthetic-health-token"},
                environ_base={"REMOTE_ADDR": "127.0.0.1"},
            )
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.get_json(), {"version": "1.0.0", "database_ok": False, "schema_version": 0})
        self.assertNotIn(str(self.root), response.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
