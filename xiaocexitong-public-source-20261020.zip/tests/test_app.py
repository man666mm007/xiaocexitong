import io
import json
import os
import re
import sqlite3
import shutil
import tempfile
import time
import unittest
import urllib.parse
import uuid
import zipfile
from pathlib import Path

from openpyxl import Workbook
from PIL import Image
from werkzeug.security import generate_password_hash

from app import create_app
from app.db import get_db, init_db, migrate_db


def make_machine_export_xlsx(rows, sheet_name="prob20260916"):
    """造一个和机改系统导出表一样的 xlsx。

    刻意保留真实文件里的两个毛病：
      1) <dimension ref="A1"/> 与实际范围不符；
      2) 引用不存在的 drawing / vmlDrawing 文件。
    """
    shared, index = [], {}

    def shared_id(text):
        if text not in index:
            index[text] = len(shared)
            shared.append(text)
        return index[text]

    def column_name(number):
        name = ""
        while number:
            number, remainder = divmod(number - 1, 26)
            name = chr(65 + remainder) + name
        return name

    sheet_rows = []
    for row_number, row in enumerate(rows, 1):
        cells = []
        for column_number, value in enumerate(row, 1):
            if value is None or value == "":
                continue
            reference = f"{column_name(column_number)}{row_number}"
            if isinstance(value, (int, float)):
                cells.append(f'<c r="{reference}"><v>{value}</v></c>')
            else:
                cells.append(f'<c r="{reference}" t="s"><v>{shared_id(str(value))}</v></c>')
        sheet_rows.append(f'<row r="{row_number}">' + "".join(cells) + "</row>")

    sheet_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<dimension ref="A1"/>'
        "<sheetData>" + "".join(sheet_rows) + "</sheetData></worksheet>"
    )
    shared_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="{len(shared)}" uniqueCount="{len(shared)}">'
        + "".join(f"<si><t>{text}</t></si>" for text in shared)
        + "</sst>"
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
        "</Types>"
    )
    root_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        "</Relationships>"
    )
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheets><sheet name="{sheet_name}" sheetId="1" r:id="rId1"/></sheets></workbook>'
    )
    workbook_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
        "</Relationships>"
    )
    sheet_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>'
        "</Relationships>"
    )
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", root_rels)
        archive.writestr("xl/workbook.xml", workbook)
        archive.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        archive.writestr("xl/worksheets/sheet1.xml", sheet_xml)
        archive.writestr("xl/worksheets/_rels/sheet1.xml.rels", sheet_rels)  # 引用了不存在的 drawing1.xml
        archive.writestr("xl/sharedStrings.xml", shared_xml)
    buffer.seek(0)
    buffer.name = "考试成绩表.xlsx"
    return buffer


def make_class_roster_xlsx(rows, sheet_name="课程点名册（秋）5"):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = sheet_name
    sheet["A1"] = "课程说明"
    sheet["A3"] = "任课教师：示例"
    headers = {1: "序号", 2: "行政班级", 3: "学号", 4: "姓名", 5: "性别"}
    for column, value in headers.items():
        sheet.cell(6, column, value)
        sheet.merge_cells(start_row=6, start_column=column, end_row=7, end_column=column)
    sheet["F6"] = "修读"
    sheet["F7"] = "性质"
    sheet["G6"] = "辅修"
    sheet["G7"] = "标记"
    sheet["H6"] = "日期周次"
    sheet.merge_cells("H6:Y6")
    sheet["Z6"] = "备注"
    sheet.merge_cells("Z6:Z7")

    for row_number, row in enumerate(rows, 8):
        if row is None:
            continue
        sheet.cell(row_number, 1, row_number - 7)
        for column, key in ((2, "administrative_class"), (3, "student_id"), (4, "name"),
                            (5, "gender"), (6, "study_type"), (7, "minor_mark"), (26, "roster_notes")):
            value = row.get(key)
            cell = sheet.cell(row_number, column, value)
            if key == "student_id" and row.get("student_id_format"):
                cell.number_format = row["student_id_format"]
    sheet.cell(9 + len(rows), 8, "签到测试标记")
    stream = io.BytesIO()
    workbook.save(stream)
    stream.seek(0)
    return stream


def _replace_quiz_table_with_legacy_constraint(database):
    row = database.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='quizzes'"
    ).fetchone()
    old_ddl, replaced = re.subn(
        r"total_score\s+REAL\s+CHECK\s*\(\s*\(total_score\s+IS\s+NOT\s+NULL\s+AND\s+total_score\s*>\s*0\)\s+OR\s*"
        r"\(total_score\s+IS\s+NULL\s+AND\s+scoring_mode='negative_marking'\s+AND\s+published=0\)\s*\)",
        "total_score REAL NOT NULL CHECK (total_score > 0)",
        row["sql"],
        count=1,
        flags=re.I,
    )
    if replaced != 1:
        raise AssertionError("Could not recreate the legacy quiz score constraint")
    old_ddl = old_ddl.replace("CREATE TABLE quizzes", "CREATE TABLE quizzes_legacy", 1)
    database.execute("PRAGMA foreign_keys=OFF")
    database.execute("BEGIN IMMEDIATE")
    database.execute(old_ddl)
    columns = [item["name"] for item in database.execute("PRAGMA table_info(quizzes)").fetchall()]
    quoted = ",".join('"' + name.replace('"', '""') + '"' for name in columns)
    database.execute(f"INSERT INTO quizzes_legacy ({quoted}) SELECT {quoted} FROM quizzes")
    database.execute("DROP TABLE quizzes")
    database.execute("ALTER TABLE quizzes_legacy RENAME TO quizzes")
    database.execute("DELETE FROM sqlite_sequence WHERE name='quizzes'")
    database.execute("INSERT INTO sqlite_sequence(name,seq) VALUES('quizzes',999)")
    database.commit()
    database.execute("PRAGMA foreign_keys=ON")


class QuizSystemTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.mkdtemp()
        root = Path(self.temp)
        self.app = create_app({
            "TESTING": True,
            "SECRET_KEY": "test-secret",
            "DATABASE": str(root / "test.sqlite3"),
            "UPLOAD_ROOT": str(root / "uploads"),
            "PENDING_ROOT": str(root / "pending"),
            "SESSION_COOKIE_SECURE": False,
        })
        with self.app.app_context():
            init_db()
            database = get_db()
            teacher = database.execute(
                "INSERT INTO users(username,name,password_hash,role,must_change_password) VALUES(?,?,?,?,0)",
                ("teacher_test", "教师", generate_password_hash("test-only-teacher-password"), "teacher"),
            ).lastrowid
            self.teacher = teacher
            self.class_id = database.execute(
                "INSERT INTO teaching_classes(school_year,term,course_name,section_no,display_name) VALUES(?,?,?,?,?)",
                ("26-27", "秋", "概率论", 1, "概率论1班"),
            ).lastrowid
            self.class2_id = database.execute(
                "INSERT INTO teaching_classes(school_year,term,course_name,section_no,display_name) VALUES(?,?,?,?,?)",
                ("26-27", "秋", "概率论", 2, "概率论2班"),
            ).lastrowid
            self.s1 = database.execute(
                "INSERT INTO users(username,name,password_hash,role,class_name,must_change_password) VALUES(?,?,?,?,?,0)",
                ("student_test_01", "学生一", generate_password_hash("Student123!"), "student", "概率论1班"),
            ).lastrowid
            self.s2 = database.execute(
                "INSERT INTO users(username,name,password_hash,role,class_name,must_change_password) VALUES(?,?,?,?,?,0)",
                ("student_test_02", "学生二", generate_password_hash("Student123!"), "student", "概率论1班"),
            ).lastrowid
            database.executemany(
                "INSERT INTO student_classes(student_id,class_id,status) VALUES(?,?,'active')",
                [(self.s1, self.class_id), (self.s2, self.class_id)],
            )
            self.quiz = database.execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,published,created_by) VALUES(?,?,?,?,?,1,?)",
                ("已发布小测", "2026-09-18", "概率论1班", self.class_id, 100, teacher),
            ).lastrowid
            score1 = database.execute("INSERT INTO scores(quiz_id,student_id,score) VALUES(?,?,?)", (self.quiz, self.s1, 88)).lastrowid
            score2 = database.execute("INSERT INTO scores(quiz_id,student_id,score) VALUES(?,?,?)", (self.quiz, self.s2, 66)).lastrowid
            upload = root / "uploads" / "quiz_1"
            upload.mkdir(parents=True)
            Image.new("RGB", (20, 20), "white").save(upload / "one.png")
            Image.new("RGB", (20, 20), "white").save(upload / "two.png")
            self.i1 = database.execute("INSERT INTO quiz_images(score_id,original_name,storage_name,mime_type) VALUES(?,?,?,?)", (score1, "one.png", "quiz_1/one.png", "image/png")).lastrowid
            self.i2 = database.execute("INSERT INTO quiz_images(score_id,original_name,storage_name,mime_type) VALUES(?,?,?,?)", (score2, "two.png", "quiz_1/two.png", "image/png")).lastrowid
            database.commit()
        self.client = self.app.test_client()

    def tearDown(self):
        shutil.rmtree(self.temp)

    def csrf(self, client=None):
        client = client or self.client
        client.get("/login")
        with client.session_transaction() as session:
            return session["csrf_token"]

    def login(self, username, password, client=None):
        client = client or self.client
        return client.post("/login", data={"csrf_token": self.csrf(client), "username": username, "password": password})

    def current_csrf(self, client=None):
        client = client or self.client
        client.get("/change-password")
        with client.session_transaction() as session:
            return session["csrf_token"]

    def test_login_and_role_protection(self):
        response = self.login("student_test_01", "Student123!")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/student/dashboard", response.location)
        # 学生访问教师页面：不显示错误页，直接送回自己的主页
        blocked = self.client.get("/teacher/dashboard")
        self.assertEqual(blocked.status_code, 302)
        self.assertIn("/student/dashboard", blocked.location)
        self.assertEqual(self.client.get("/teacher/dashboard").status_code, 302)
        self.assertEqual(self.client.get("/student/dashboard").status_code, 200)

    def test_successful_login_counters_count_only_password_successes(self):
        login_page = self.client.get("/login").get_data(as_text=True)
        self.assertIn("累计登录次数：0 ｜ 今日登录次数：0", login_page)
        self.login("teacher_test", "wrong-password")
        self.assertIn("累计登录次数：0 ｜ 今日登录次数：0", self.client.get("/login").get_data(as_text=True))

        self.login("teacher_test", "test-only-teacher-password")
        self.client.get("/teacher/dashboard")
        self.client.get("/teacher/classes")
        self.assertEqual(self.client.get("/login").status_code, 302)
        self.assertIn("累计登录次数：1 ｜ 今日登录次数：1", self.client.get("/teacher/dashboard").get_data(as_text=True))
        self.client.post("/logout", data={"csrf_token": self.current_csrf()})
        self.login("student_test_01", "Student123!")
        self.assertIn("累计登录次数：2 ｜ 今日登录次数：2", self.client.get("/student/dashboard").get_data(as_text=True))
        restarted = create_app({
            "TESTING": True,
            "SECRET_KEY": "test-secret",
            "DATABASE": str(Path(self.temp) / "test.sqlite3"),
            "UPLOAD_ROOT": str(Path(self.temp) / "uploads"),
            "PENDING_ROOT": str(Path(self.temp) / "pending"),
            "SESSION_COOKIE_SECURE": False,
        })
        with restarted.app_context():
            self.assertEqual(get_db().execute("SELECT SUM(count) FROM login_daily_counts").fetchone()[0], 2)

    def test_quiz_creation_uses_server_generated_date_name_and_duplicate_confirmation(self):
        self.login("teacher_test", "test-only-teacher-password")
        url = "/teacher/quizzes/create"
        csrf = self.current_csrf()
        invalid_date = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-02-30", "class_id": self.class_id,
                  "total_score": "10", "name": "伪造名称"},
        )
        self.assertEqual(invalid_date.status_code, 200)
        invalid_n = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-10-15", "class_id": self.class_id,
                  "total_score": "1.5"},
        )
        self.assertEqual(invalid_n.status_code, 302)
        with self.app.app_context():
            draft = get_db().execute("SELECT total_score FROM quizzes WHERE quiz_date='2026-10-15'").fetchone()
            self.assertIsNone(draft["total_score"])
        forged_class = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-10-16", "class_id": "99999",
                  "total_score": "10"},
        )
        self.assertEqual(forged_class.status_code, 200)
        first = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-10-16", "class_id": self.class_id,
                  "total_score": "10", "name": "伪造名称"},
        )
        self.assertEqual(first.status_code, 302)
        first_id = int(first.location.rsplit("/", 1)[1])
        duplicate_prompt = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-10-16", "class_id": self.class_id,
                  "total_score": "10"},
        )
        self.assertEqual(duplicate_prompt.status_code, 302)
        self.assertEqual(duplicate_prompt.location,first.location)
        confirmed = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-10-16", "class_id": self.class_id,
                  "total_score": "10", "confirm_duplicate": "1", "name": "仍不能伪造"},
        )
        self.assertEqual(confirmed.status_code, 302)
        self.assertEqual(confirmed.location,first.location)
        other_class = self.client.post(
            url,
            data={"csrf_token": csrf, "quiz_date": "2026-10-16", "class_id": self.class2_id,
                  "total_score": "10"},
        )
        self.assertEqual(other_class.status_code, 302)
        with self.app.app_context():
            rows = get_db().execute(
                "SELECT id,name,total_score,scoring_mode,class_id FROM quizzes WHERE quiz_date='2026-10-16' ORDER BY id"
            ).fetchall()
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]["id"], first_id)
            self.assertEqual([row["name"] for row in rows], ["10月16日小测"] * 2)
            self.assertEqual([row["scoring_mode"] for row in rows], ["negative_marking"] * 2)
            self.assertEqual([row["total_score"] for row in rows], [None, None])
            self.assertNotEqual(rows[0]["class_id"], rows[1]["class_id"])

    def test_first_login_forces_password_change(self):
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?", (generate_password_hash("000001"), self.s1))
            database.commit()
        response = self.login("student_test_01", "000001")
        self.assertIn("/change-password", response.location)
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT SUM(count) FROM login_daily_counts").fetchone()[0], 1)
        token = self.current_csrf()
        changed = self.client.post("/change-password", data={"csrf_token": token, "current_password": "000001", "new_password": "NewPassword8!", "confirm_password": "NewPassword8!"})
        self.assertIn("/login", changed.location)
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT SUM(count) FROM login_daily_counts").fetchone()[0], 1)
        self.assertIn("/student/dashboard", self.login("student_test_01", "NewPassword8!").location)
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT SUM(count) FROM login_daily_counts").fetchone()[0], 2)

    def test_csrf_is_required(self):
        response = self.client.post("/login", data={"username": "teacher_test", "password": "test-only-teacher-password"})
        # 缺少 CSRF 的提交不会成功登录，也不会给用户看错误页，而是被送回页面并提示
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.location)

    def test_password_reset_invalidates_existing_session(self):
        self.login("student_test_01", "Student123!")
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE users SET session_version=session_version+1 WHERE id=?", (self.s1,))
            database.commit()
        response = self.client.get("/student/dashboard")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.location)

    def test_edit_and_filter_student_by_class(self):
        self.login("teacher_test", "test-only-teacher-password")
        token = self.current_csrf()
        response = self.client.post(
            f"/teacher/students/{self.s1}/edit",
            data={"csrf_token": token, "name": "学生一已改", "class_ids": str(self.class2_id), "class_name": "伪造新班"},
        )
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            self.assertIsNone(get_db().execute(
                "SELECT id FROM teaching_classes WHERE display_name='伪造新班'"
            ).fetchone())
        filtered = self.client.get(f"/teacher/students?class_id={self.class2_id}")
        self.assertIn("学生一已改".encode(), filtered.data)
        self.assertNotIn("学生二".encode(), filtered.data)

    def test_student_archive_restore_and_session_revocation(self):
        student_client = self.app.test_client()
        teacher_client = self.app.test_client()
        self.login("student_test_01", "Student123!", student_client)
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        token = self.current_csrf(teacher_client)
        archived = teacher_client.post(f"/teacher/students/{self.s1}/archive", data={"csrf_token": token})
        self.assertEqual(archived.status_code, 302)
        self.assertIn("/login", student_client.get("/student/dashboard").location)
        trash = teacher_client.get("/teacher/trash")
        self.assertIn("学生一".encode(), trash.data)
        token = self.current_csrf(teacher_client)
        restored = teacher_client.post(f"/teacher/trash/students/{self.s1}/restore", data={"csrf_token": token})
        self.assertEqual(restored.status_code, 302)
        self.assertIn("/student/dashboard", self.login("student_test_01", "Student123!", student_client).location)

    def test_permanent_student_delete_removes_image(self):
        self.login("teacher_test", "test-only-teacher-password")
        token = self.current_csrf()
        self.client.post(f"/teacher/students/{self.s1}/archive", data={"csrf_token": token})
        token = self.current_csrf()
        self.client.post(f"/teacher/trash/students/{self.s1}/purge", data={"csrf_token": token})
        with self.app.app_context():
            database = get_db()
            self.assertIsNone(database.execute("SELECT id FROM users WHERE id=?", (self.s1,)).fetchone())
            self.assertIsNone(database.execute("SELECT id FROM quiz_images WHERE id=?", (self.i1,)).fetchone())
            self.assertFalse((Path(self.temp) / "uploads" / "quiz_1" / "one.png").exists())

    def test_class_archive_and_restore(self):
        with self.app.app_context():
            now = int(time.time())
            get_db().execute(
                "INSERT INTO student_classes(student_id,class_id,status) VALUES(?,?,'active')",
                (self.s1, self.class2_id),
            )
            other_quiz = get_db().execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,published,created_by) "
                "VALUES(?,?,?,?,100,1,?)",
                ("另一课程小测", "2026-09-20", "概率论2班", self.class2_id, self.teacher),
            ).lastrowid
            get_db().execute(
                "INSERT INTO scores(quiz_id,student_id,score) VALUES(?,?,77)", (other_quiz, self.s1)
            )
            attendance = get_db().execute(
                "INSERT INTO attendance_sessions(title,class_name,code,starts_at,late_after,ends_at,created_by) VALUES(?,?,?,?,?,?,?)",
                ("课堂签到", "概率论1班", "123456", now, now + 60, now + 600, self.teacher),
            ).lastrowid
            get_db().commit()
        self.login("teacher_test", "test-only-teacher-password")
        token = self.current_csrf()
        archived = self.client.post(
            f"/teacher/classes/{self.class_id}/archive",
            data={"csrf_token": token, "confirm_name": "概率论1班"},
        )
        self.assertEqual(archived.status_code, 302)
        with self.app.app_context():
            database = get_db()
            batch = database.execute("SELECT id FROM class_trash WHERE class_name='概率论1班'").fetchone()["id"]
            self.assertEqual(database.execute("SELECT published FROM quizzes WHERE id=?", (self.quiz,)).fetchone()["published"], 0)
            self.assertIsNone(database.execute("SELECT archived_at FROM users WHERE id=?", (self.s1,)).fetchone()["archived_at"])
            archived_attendance = database.execute(
                "SELECT archived_batch,active FROM attendance_sessions WHERE id=?", (attendance,)
            ).fetchone()
            self.assertEqual(archived_attendance["archived_batch"], batch)
            self.assertEqual(archived_attendance["active"], 0)
        other = self.app.test_client()
        response = self.login("student_test_01", "Student123!", other)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/student/dashboard", response.location)
        self.assertEqual(other.get("/student/dashboard").status_code, 200)
        token = self.current_csrf()
        restored = self.client.post(f"/teacher/trash/classes/{batch}/restore", data={"csrf_token": token})
        self.assertEqual(restored.status_code, 302)
        self.assertIn("/student/dashboard", self.login("student_test_01", "Student123!", other).location)
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT published FROM quizzes WHERE id=?", (self.quiz,)).fetchone()["published"], 0)
            restored_attendance = get_db().execute(
                "SELECT archived_batch,active FROM attendance_sessions WHERE id=?", (attendance,)
            ).fetchone()
            self.assertIsNone(restored_attendance["archived_batch"])
            self.assertEqual(restored_attendance["active"], 0)
            self.assertEqual(get_db().execute(
                "SELECT COUNT(*) FROM student_classes WHERE student_id=? AND class_id=? AND status='active'",
                (self.s1, self.class2_id),
            ).fetchone()[0], 1)

        token = self.current_csrf()
        self.client.post(
            f"/teacher/classes/{self.class_id}/archive",
            data={"csrf_token": token, "confirm_name": "概率论1班"},
        )
        with self.app.app_context():
            second_batch = get_db().execute(
                "SELECT id FROM class_trash WHERE class_id=?", (self.class_id,)
            ).fetchone()["id"]
        purged = self.client.post(
            f"/teacher/trash/classes/{second_batch}/purge", data={"csrf_token": self.current_csrf()}
        )
        self.assertEqual(purged.status_code, 302)
        with self.app.app_context():
            database = get_db()
            self.assertIsNotNone(database.execute("SELECT id FROM users WHERE id=?", (self.s1,)).fetchone())
            self.assertIsNotNone(database.execute("SELECT id FROM quizzes WHERE id=?", (other_quiz,)).fetchone())
            self.assertEqual(database.execute(
                "SELECT score FROM scores WHERE quiz_id=? AND student_id=?", (other_quiz, self.s1)
            ).fetchone()["score"], 77)
            self.assertEqual(database.execute(
                "SELECT COUNT(*) FROM student_classes WHERE student_id=? AND class_id=?",
                (self.s1, self.class2_id),
            ).fetchone()[0], 1)

    def test_quiz_delete_move_to_trash_restore_and_purge(self):
        self.login("teacher_test", "test-only-teacher-password")
        page = self.client.get(f"/teacher/quizzes/{self.quiz}/delete")
        self.assertEqual(page.status_code, 200)
        self.assertIn("删除这次小测", page.get_data(as_text=True))
        moved = self.client.post(
            f"/teacher/quizzes/{self.quiz}/delete", data={"csrf_token": self.current_csrf()}
        )
        self.assertEqual(moved.status_code, 302)
        # 删除后：教师列表与详情不再显示，学生端立即不可见
        # （列表页还有一条含小测名的成功提示，所以直接看空状态而非标题）
        self.assertIn("还没有小测，请先新建。", self.client.get("/teacher/quizzes").get_data(as_text=True))
        # 已删除的小测详情：不显示错误页，而是回列表并提示它在回收站
        gone = self.client.get(f"/teacher/quizzes/{self.quiz}")
        self.assertEqual(gone.status_code, 302)
        self.assertIn("已经被移入回收站", self.client.get(gone.location).get_data(as_text=True))
        student = self.app.test_client()
        self.login("student_test_01", "Student123!", student)
        # 学生端同样看不到已删除的小测，但不会看到错误页
        student_view = student.get(f"/student/quizzes/{self.quiz}")
        self.assertEqual(student_view.status_code, 302)
        self.assertIn("已经下架", student.get(student_view.location).get_data(as_text=True))
        self.assertIn("已删除小测", self.client.get("/teacher/trash").get_data(as_text=True))
        with self.app.app_context():
            batch = get_db().execute(
                "SELECT id FROM record_trash WHERE kind='quiz' AND ref_id=?", (self.quiz,)
            ).fetchone()["id"]
        restored = self.client.post(f"/teacher/trash/records/{batch}/restore", data={"csrf_token": self.current_csrf()})
        self.assertEqual(restored.status_code, 302)
        with self.app.app_context():
            row = get_db().execute("SELECT published,archived_batch FROM quizzes WHERE id=?", (self.quiz,)).fetchone()
            self.assertIsNone(row["archived_batch"])
            self.assertEqual(row["published"], 0)  # 恢复后保持未发布，需老师重新发布
        # 再次删除后彻底清除：成绩、图片记录和文件都要消失
        self.client.post(f"/teacher/quizzes/{self.quiz}/delete", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            database = get_db()
            batch = database.execute("SELECT id FROM record_trash WHERE kind='quiz' AND ref_id=?", (self.quiz,)).fetchone()["id"]
            self.assertIsNotNone(database.execute("SELECT id FROM scores WHERE quiz_id=?", (self.quiz,)).fetchone())
        self.client.post(f"/teacher/trash/records/{batch}/purge", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            database = get_db()
            self.assertIsNone(database.execute("SELECT id FROM quizzes WHERE id=?", (self.quiz,)).fetchone())
            self.assertIsNone(database.execute("SELECT id FROM quiz_images WHERE id=?", (self.i1,)).fetchone())
            self.assertFalse((Path(self.temp) / "uploads" / "quiz_1" / "one.png").exists())

    def test_attendance_delete_move_to_trash_restore_and_purge(self):
        with self.app.app_context():
            database = get_db()
            now = int(time.time())
            session_id = database.execute(
                "INSERT INTO attendance_sessions(title,class_name,code,starts_at,late_after,ends_at,created_by) VALUES(?,?,?,?,?,?,?)",
                ("第一次签到", "概率论1班", "123456", now, now + 60, now + 600, self.teacher),
            ).lastrowid
            database.execute(
                "INSERT INTO attendance_records(session_id,student_id,signed_at,status) VALUES(?,?,?,?)",
                (session_id, self.s1, now, "normal"),
            )
            database.commit()
        self.login("teacher_test", "test-only-teacher-password")
        self.assertEqual(self.client.get(f"/teacher/attendance/{session_id}/delete").status_code, 200)
        moved = self.client.post(
            f"/teacher/attendance/{session_id}/delete", data={"csrf_token": self.current_csrf()}
        )
        self.assertEqual(moved.status_code, 302)
        with self.app.app_context():
            row = get_db().execute("SELECT archived_batch,active FROM attendance_sessions WHERE id=?", (session_id,)).fetchone()
            self.assertIsNotNone(row["archived_batch"])
            self.assertEqual(row["active"], 0)
        self.assertIn("还没有签到记录。", self.client.get("/teacher/attendance").get_data(as_text=True))
        # 已删除的签到详情：不显示错误页，而是回列表并提示它在回收站
        gone = self.client.get(f"/teacher/attendance/{session_id}")
        self.assertEqual(gone.status_code, 302)
        self.assertIn("已经被移入回收站", self.client.get(gone.location).get_data(as_text=True))
        with self.app.app_context():
            batch = get_db().execute(
                "SELECT id FROM record_trash WHERE kind='attendance' AND ref_id=?", (session_id,)
            ).fetchone()["id"]
        self.assertIn("已删除签到", self.client.get("/teacher/trash").get_data(as_text=True))
        self.client.post(f"/teacher/trash/records/{batch}/restore", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            row = get_db().execute("SELECT archived_batch,active FROM attendance_sessions WHERE id=?", (session_id,)).fetchone()
            self.assertIsNone(row["archived_batch"])
            self.assertEqual(row["active"], 0)
        self.client.post(f"/teacher/attendance/{session_id}/delete", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            database = get_db()
            batch = database.execute("SELECT id FROM record_trash WHERE kind='attendance' AND ref_id=?", (session_id,)).fetchone()["id"]
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM attendance_records WHERE session_id=?", (session_id,)).fetchone()["n"], 1)
        self.client.post(f"/teacher/trash/records/{batch}/purge", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            database = get_db()
            self.assertIsNone(database.execute("SELECT id FROM attendance_sessions WHERE id=?", (session_id,)).fetchone())
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM attendance_records WHERE session_id=?", (session_id,)).fetchone()["n"], 0)

    def test_deleted_records_are_purged_after_retention(self):
        self.login("teacher_test", "test-only-teacher-password")
        self.client.post(f"/teacher/quizzes/{self.quiz}/delete", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE record_trash SET purge_after=1 WHERE kind='quiz' AND ref_id=?", (self.quiz,))
            database.commit()
        self.client.get("/teacher/dashboard")
        with self.app.app_context():
            database = get_db()
            self.assertIsNone(database.execute("SELECT id FROM quizzes WHERE id=?", (self.quiz,)).fetchone())
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM record_trash").fetchone()["n"], 0)

    def test_bulk_restore_records_and_attendances(self):
        # 准备：建两场签到 + 一个新小测，都删除
        with self.app.app_context():
            database = get_db()
            now = int(time.time())
            for i in range(2):
                database.execute(
                    "INSERT INTO attendance_sessions(title,class_name,code,starts_at,late_after,ends_at,created_by) VALUES(?,?,?,?,?,?,?)",
                    (f"签到{i+1}", "概率论1班", f"{100000+i}", now - 600, now - 540, now - 60, self.teacher),
                )
            extra_quiz = database.execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,total_score,published,created_by) VALUES(?,?,?,?,0,?)",
                ("第二节小测", "2026-09-19", "概率论1班", 100, self.teacher),
            ).lastrowid
            database.commit()
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            sess_ids = [row["id"] for row in get_db().execute("SELECT id FROM attendance_sessions").fetchall()]
        for sid in sess_ids:
            self.client.post(f"/teacher/attendance/{sid}/delete", data={"csrf_token": self.current_csrf()})
        self.client.post(f"/teacher/quizzes/{extra_quiz}/delete", data={"csrf_token": self.current_csrf()})

        # 错误短语应被拒绝
        rejected = self.client.post(
            "/teacher/trash/attendances/restore",
            data={"csrf_token": self.current_csrf(), "confirm_phrase": "我点错了"},
        )
        self.assertEqual(rejected.status_code, 302)
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='attendance'").fetchone()["n"], 2)
            self.assertEqual(get_db().execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='quiz'").fetchone()["n"], 1)

        # 确认页能列出影响面
        page = self.client.get("/teacher/trash/attendances/restore")
        self.assertEqual(page.status_code, 200)
        self.assertIn("确认全部恢复", page.get_data(as_text=True))

        # 正确短语一次恢复全部签到
        ok = self.client.post(
            "/teacher/trash/attendances/restore",
            data={"csrf_token": self.current_csrf(), "confirm_phrase": "确认全部恢复"},
        )
        self.assertEqual(ok.status_code, 302)
        with self.app.app_context():
            database = get_db()
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='attendance'").fetchone()["n"], 0)
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM attendance_sessions WHERE archived_batch IS NULL").fetchone()["n"], 2)

        # 批量恢复小测
        self.client.post(
            "/teacher/trash/quizzes/restore",
            data={"csrf_token": self.current_csrf(), "confirm_phrase": "确认全部恢复"},
        )
        with self.app.app_context():
            database = get_db()
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='quiz'").fetchone()["n"], 0)
            row = database.execute("SELECT archived_batch,published FROM quizzes WHERE id=?", (extra_quiz,)).fetchone()
            self.assertIsNone(row["archived_batch"])
            self.assertEqual(row["published"], 0)

    def test_bulk_purge_records_removes_image_files(self):
        with self.app.app_context():
            database = get_db()
            extra_quiz = database.execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,total_score,published,created_by) VALUES(?,?,?,?,0,?)",
                ("第三节小测", "2026-09-20", "概率论1班", 100, self.teacher),
            ).lastrowid
            sid = database.execute(
                "INSERT INTO scores(quiz_id,student_id,score) VALUES(?,?,?)", (extra_quiz, self.s1, 77)
            ).lastrowid
            upload_dir = Path(self.temp) / "uploads" / f"quiz_{extra_quiz}"
            upload_dir.mkdir(parents=True)
            Image.new("RGB", (20, 20), "white").save(upload_dir / "extra.png")
            database.execute(
                "INSERT INTO quiz_images(score_id,original_name,storage_name,mime_type) VALUES(?,?,?,?)",
                (sid, "extra.png", f"quiz_{extra_quiz}/extra.png", "image/png"),
            )
            database.commit()
        self.login("teacher_test", "test-only-teacher-password")
        self.client.post(f"/teacher/quizzes/{extra_quiz}/delete", data={"csrf_token": self.current_csrf()})
        self.client.post(
            "/teacher/trash/quizzes/purge",
            data={"csrf_token": self.current_csrf(), "confirm_phrase": "确认永久删除"},
        )
        with self.app.app_context():
            database = get_db()
            self.assertIsNone(database.execute("SELECT id FROM quizzes WHERE id=?", (extra_quiz,)).fetchone())
            self.assertEqual(database.execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='quiz'").fetchone()["n"], 0)
        self.assertFalse((Path(self.temp) / "uploads" / f"quiz_{extra_quiz}" / "extra.png").exists())

    def test_bulk_confirm_redirects_when_section_empty(self):
        self.login("teacher_test", "test-only-teacher-password")
        # 当前数据库没有签到在回收站里，直接访问确认页应回到回收站
        response = self.client.get("/teacher/trash/attendances/restore", follow_redirects=False)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/teacher/trash", response.location)

    def test_unpublished_quiz_is_hidden(self):
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE quizzes SET published=0 WHERE id=?", (self.quiz,))
            database.commit()
        self.login("student_test_01", "Student123!")
        # 未发布的小测：学生看不到内容，但也不会看到错误页
        hidden = self.client.get(f"/student/quizzes/{self.quiz}")
        self.assertEqual(hidden.status_code, 200)
        self.assertIn("成绩未发布", hidden.get_data(as_text=True))
        self.assertNotIn("90", hidden.get_data(as_text=True))

    def test_student_import_preview_and_confirm(self):
        self.login("teacher_test", "test-only-teacher-password")
        stream = make_class_roster_xlsx([{
            "student_id": 123,
            "student_id_format": "000000000",
            "name": "学生三",
            "administrative_class": "数学与应用数学1班",
            "gender": "女",
            "study_type": "必修",
            "minor_mark": "否",
            "roster_notes": "名单备注",
        }])
        token = self.current_csrf()
        response = self.client.post(
            "/teacher/students/import",
            data={
                "csrf_token": token,
                "mode": "named",
                "school_year": "26-27",
                "term": "秋",
                "course_name": "统计学导论B",
                "section_no": "1",
                "student_file": (stream, "students.xlsx"),
            },
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 302)
        batch_id = response.location.split("/")[-2]
        preview = self.client.get(response.location)
        self.assertIn("可以导入".encode(), preview.data)
        self.assertIn("共 1 行".encode(), preview.data)
        self.assertIn("000000123".encode(), preview.data)
        self.assertIn("数学与应用数学1班".encode(), preview.data)
        self.assertIn("名单备注".encode(), preview.data)
        with self.app.app_context():
            self.assertIsNone(get_db().execute(
                "SELECT id FROM teaching_classes WHERE school_year='26-27' AND term='秋' "
                "AND course_name='统计学导论B' AND section_no=1"
            ).fetchone())
        token = self.current_csrf()
        confirmed = self.client.post(f"/teacher/students/import/{batch_id}/confirm", data={"csrf_token": token})
        self.assertEqual(confirmed.status_code, 302)
        with self.app.app_context():
            imported = get_db().execute(
                "SELECT administrative_class,gender,study_type,minor_mark,roster_notes "
                "FROM users WHERE username='000000123'"
            ).fetchone()
            self.assertIsNotNone(imported)
            self.assertEqual(dict(imported), {
                "administrative_class": "数学与应用数学1班",
                "gender": "女",
                "study_type": "必修",
                "minor_mark": "否",
                "roster_notes": "名单备注",
            })
            self.assertIsNotNone(get_db().execute(
                "SELECT id FROM teaching_classes WHERE school_year='26-27' AND term='秋' AND course_name='统计学导论B' AND section_no=1"
            ).fetchone())

    def test_class_creation_roster_rejects_bad_files_and_reports_row_errors(self):
        self.login("teacher_test", "test-only-teacher-password")
        base_data = {
            "csrf_token": self.current_csrf(),
            "mode": "named",
            "school_year": "26-27",
            "term": "秋",
            "course_name": "班级名单检查",
            "section_no": "1",
        }

        def upload(stream, filename):
            return self.client.post(
                "/teacher/students/import",
                data={**base_data, "student_file": (stream, filename)},
                content_type="multipart/form-data",
            )

        unsupported = upload(io.BytesIO(b"id,name\n1,test\n"), "roster.csv")
        unsupported_body = self.client.get(unsupported.location).get_data(as_text=True)
        self.assertIn("仅支持 .xlsx", unsupported_body)

        invalid_workbook = Workbook()
        invalid_workbook.active["A1"] = "课程说明"
        invalid_stream = io.BytesIO()
        invalid_workbook.save(invalid_stream)
        invalid_stream.seek(0)
        unrecognized = upload(invalid_stream, "unrecognized.xlsx")
        unrecognized_body = self.client.get(unrecognized.location).get_data(as_text=True)
        self.assertIn("无法识别学生表表头", unrecognized_body)

        missing_id = upload(
            make_class_roster_xlsx([{"name": "缺少学号"}]), "missing-id.xlsx"
        )
        missing_body = self.client.get(missing_id.location).get_data(as_text=True)
        self.assertIn("学号为空", missing_body)
        self.assertIn("<td>8</td>", missing_body)
        self.assertNotIn("确认导入", missing_body)

        duplicate = upload(
            make_class_roster_xlsx([
                {"student_id": "000001234", "name": "学生甲"},
                {"student_id": "000001234", "name": "学生乙"},
            ]),
            "duplicate-id.xlsx",
        )
        duplicate_body = self.client.get(duplicate.location).get_data(as_text=True)
        self.assertIn("名单内学号重复", duplicate_body)
        self.assertIn("<td>8</td>", duplicate_body)
        self.assertIn("<td>9</td>", duplicate_body)
        self.assertNotIn("确认导入", duplicate_body)

    def test_result_import_preview_and_confirm(self):
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            database = get_db()
            draft = database.execute("INSERT INTO quizzes(name,quiz_date,class_name,total_score,published,created_by) VALUES(?,?,?,?,0,1)", ("待导入", "2026-09-19", "概率论1班", 100)).lastrowid
            database.commit()
        csv_data = io.BytesIO(b"student_id,score,detail\nstudent_test_01,95,good\n")
        token = self.current_csrf()
        response = self.client.post(
            f"/teacher/quizzes/{draft}/import",
            data={"csrf_token": token, "score_file": (csv_data, "scores.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 302)
        batch_id = response.location.split("/")[-2]
        self.assertIn("匹配成功".encode(), self.client.get(response.location).data)
        token = self.current_csrf()
        self.client.post(f"/teacher/quizzes/{draft}/import/{batch_id}/confirm", data={"csrf_token": token})
        with self.app.app_context():
            row = get_db().execute("SELECT score FROM scores WHERE quiz_id=? AND student_id=?", (draft, self.s1)).fetchone()
            self.assertEqual(row["score"], 95)

    def test_teacher_creates_attendance_and_student_signs(self):
        self.app.config["ATTENDANCE_CLOCK"]=lambda:1791162000
        teacher_client = self.app.test_client()
        student_client = self.app.test_client()
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        response = teacher_client.post(
            "/teacher/attendance/create",
            data={
                "csrf_token": self.current_csrf(teacher_client),
                "attendance_date": "2026-10-05",
                "class_id": str(self.class_id),
                "duration_seconds": "120",
                "late_seconds": "30",
            },
        )
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            item = get_db().execute("SELECT * FROM attendance_sessions WHERE title='10月5日签到'").fetchone()
            session_id = item["id"]
            self.assertEqual(item["late_after"] - item["starts_at"], 30)
            self.assertEqual(item["ends_at"] - item["starts_at"], 120)
            self.assertTrue(item["qr_secret"])
        detail = teacher_client.get(f"/teacher/attendance/{session_id}")
        self.assertEqual(detail.status_code, 200)
        self.assertIn("扫码签到", detail.get_data(as_text=True))
        # 已取消六位数字签到，教师端不再显示签到码
        self.assertNotIn("六位签到码", detail.get_data(as_text=True))
        scan_url = teacher_client.get(f"/teacher/attendance/{session_id}/qr").get_json()["url"]
        parsed = urllib.parse.urlsplit(scan_url)
        scan_path = f"{parsed.path}?{parsed.query}"
        self.login("student_test_01", "Student123!", student_client)
        self.assertEqual(student_client.get("/student/attendance").status_code, 200)
        signed = student_client.get(scan_path)
        self.assertEqual(signed.status_code, 302)
        with self.app.app_context():
            record = get_db().execute(
                "SELECT status,source FROM attendance_records WHERE session_id=? AND student_id=?",
                (session_id, self.s1),
            ).fetchone()
            self.assertEqual(record["status"], "normal")
            self.assertEqual(record["source"], "qr")

    def test_attendance_scan_rejects_forged_token_and_duplicate(self):
        now = int(time.time())
        with self.app.app_context():
            database = get_db()
            session_id = database.execute(
                "INSERT INTO attendance_sessions(title,class_name,code,qr_secret,starts_at,late_after,ends_at,created_by) "
                "VALUES(?,?,?,?,?,?,?,?)",
                ("签到", "概率论1班", "", "secret", now, now + 60, now + 600, self.teacher),
            ).lastrowid
            database.commit()
        teacher_client = self.app.test_client()
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        scan_url = teacher_client.get(f"/teacher/attendance/{session_id}/qr").get_json()["url"]
        parsed = urllib.parse.urlsplit(scan_url)
        scan_path = f"{parsed.path}?{parsed.query}"
        self.login("student_test_01", "Student123!")
        # 伪造的二维码令牌：不产生任何签到记录
        self.client.get(f"/student/attendance/scan/{session_id}?t=forged-token-000")
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT COUNT(*) AS n FROM attendance_records").fetchone()["n"], 0)
        # 同一学生重复扫码：只记一条
        self.client.get(scan_path)
        self.client.get(scan_path)
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT COUNT(*) AS n FROM attendance_records").fetchone()["n"], 1)

    def test_attendance_export_and_statistics_pages(self):
        now = int(time.time())
        with self.app.app_context():
            database = get_db()
            session_id = database.execute(
                "INSERT INTO attendance_sessions(title,class_name,code,starts_at,late_after,ends_at,created_by) VALUES(?,?,?,?,?,?,?)",
                ("签到导出", "概率论1班", "123456", now, now + 60, now + 600, self.teacher),
            ).lastrowid
            database.execute(
                "INSERT INTO attendance_records(session_id,student_id,signed_at,status) VALUES(?,?,?,?)",
                (session_id, self.s1, now, "normal"),
            )
            database.commit()
        self.login("teacher_test", "test-only-teacher-password")
        exported = self.client.get(f"/teacher/attendance/{session_id}/export")
        self.assertEqual(exported.status_code, 200)
        self.assertIn("学生一".encode(), exported.data)
        self.assertIn("未签到".encode(), exported.data)
        stats = self.client.get(f"/teacher/statistics?class_id={self.class_id}")
        self.assertEqual(stats.status_code, 200)
        self.assertIn("88.0".encode(), stats.data)
        student_client = self.app.test_client()
        self.login("student_test_01", "Student123!", student_client)
        student_stats = student_client.get("/student/statistics")
        self.assertEqual(student_stats.status_code, 200)
        self.assertIn("成绩趋势".encode(), student_stats.data)

    def test_updated_site_name_is_visible(self):
        response = self.client.get("/login")
        self.assertIn("小测查询系统".encode(), response.data)
        self.login("student_test_01", "Student123!")
        dashboard = self.client.get("/student/dashboard").get_data(as_text=True)
        self.assertIn("小测查询", dashboard)
        self.assertNotIn("测试卷查询", dashboard)

    def test_shipped_copy_has_no_old_brand_or_workflow_instructions(self):
        project_root = Path(__file__).resolve().parents[1]
        sources = [
            "README.md", "USER_GUIDE.md", "DEPLOYMENT.md", "DATABASE_DESIGN.md", "TEST_REPORT.md",
            "VIDEO_SCRIPT.md", "给老师-使用说明.md", "给老师的数据格式说明.md", "老师请看-使用说明.txt",
            "示例账号.txt", "app/templates/base.html", "app/templates/auth/login.html",
            "app/templates/student/dashboard.html", "app/templates/student/quizzes.html",
            "app/templates/teacher/create_quiz.html", "app/templates/teacher/import_results.html",
            "app/templates/teacher/preview_results.html", "app/templates/teacher/create_attendance.html",
            "app/templates/teacher/import_students.html", "scripts/init_project.py",
        ]
        shipped_text = "\n".join((project_root / name).read_text(encoding="utf-8-sig") for name in sources)
        shipped_text += "\n".join(
            (project_root / name).read_bytes().decode("gbk")
            for name in ("start_windows.bat", "试用-演示数据.bat")
        )
        for phrase in (
            "概率论小测查询系统", "例如：概率论", "题目数量（满分）", "填题目数量",
            "测试卷查询", "预览会提示它与小测日期是否一致", "第3周课堂签到",
        ):
            with self.subTest(phrase=phrase):
                self.assertNotIn(phrase, shipped_text)

    def test_create_quiz_draft_does_not_require_manual_question_count(self):
        self.login("teacher_test", "test-only-teacher-password")
        page = self.client.get("/teacher/quizzes/create").get_data(as_text=True)
        self.assertNotIn('name="total_score"', page)
        response = self.client.post(
            "/teacher/quizzes/create",
            data={"csrf_token": self.current_csrf(), "quiz_date": "2026-10-17", "class_id": str(self.class_id)},
        )
        self.assertEqual(response.status_code, 302)
        quiz_id = int(response.location.rsplit("/", 1)[1])
        with self.app.app_context():
            quiz = get_db().execute(
                "SELECT total_score,scoring_mode,published FROM quizzes WHERE id=?",
                (quiz_id,),
            ).fetchone()
            self.assertEqual(tuple(quiz), (None, "negative_marking", 0))
        self.client.post(f"/teacher/quizzes/{quiz_id}/publish", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            self.assertEqual(get_db().execute("SELECT published FROM quizzes WHERE id=?", (quiz_id,)).fetchone()["published"], 0)

    def test_migrate_allows_unscored_drafts_and_preserves_quiz_history(self):
        with self.app.app_context():
            database = get_db()
            score_id = database.execute(
                "SELECT id FROM scores WHERE quiz_id=? ORDER BY id LIMIT 1", (self.quiz,)
            ).fetchone()["id"]
            original_score = database.execute("SELECT score FROM scores WHERE id=?", (score_id,)).fetchone()["score"]
            database.execute(
                "INSERT INTO answer_details(score_id,number,is_correct,answer_status) VALUES(?,1,1,'correct')",
                (score_id,),
            )
            database.commit()
            _replace_quiz_table_with_legacy_constraint(database)
            migrate_db()
            quiz = database.execute(
                "SELECT id,total_score,published FROM quizzes WHERE id=?", (self.quiz,)
            ).fetchone()
            self.assertEqual(tuple(quiz), (self.quiz, 100.0, 1))
            self.assertEqual(database.execute("SELECT score FROM scores WHERE id=?", (score_id,)).fetchone()["score"], original_score)
            detail = database.execute(
                "SELECT number,is_correct,answer_status FROM answer_details WHERE score_id=?", (score_id,)
            ).fetchone()
            self.assertEqual(tuple(detail), (1, 1, "correct"))
            self.assertEqual(database.execute("SELECT seq FROM sqlite_sequence WHERE name='quizzes'").fetchone()["seq"], 999)
            self.assertEqual(database.execute("PRAGMA foreign_key_check").fetchall(), [])
            self.assertEqual(database.execute("PRAGMA foreign_keys").fetchone()[0], 1)
            database.execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,scoring_mode,created_by) "
                "VALUES(?,?,?,?,NULL,'negative_marking',?)",
                ("待导入", "2026-10-17", "概率论1班", self.class_id, self.teacher),
            )
            with self.assertRaises(sqlite3.IntegrityError):
                database.execute(
                    "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,scoring_mode,created_by) "
                    "VALUES(?,?,?,?,0,'negative_marking',?)",
                    ("无效", "2026-10-17", "概率论1班", self.class_id, self.teacher),
                )
            with self.assertRaises(sqlite3.IntegrityError):
                database.execute(
                    "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,scoring_mode,published,created_by) "
                    "VALUES(?,?,?,?,NULL,'negative_marking',1,?)",
                    ("已发布空题数", "2026-10-17", "概率论1班", self.class_id, self.teacher),
                )
            database.rollback()

    def test_app_can_run_under_url_prefix(self):
        """挂到学校现有站点的子路径下（例如 http://courseware.example.invalid/quiz/）时的行为。"""
        os.environ["QUIZ_URL_PREFIX"] = "/quiz"
        folder = tempfile.mkdtemp()
        try:
            root = Path(folder)
            app = create_app({
                "TESTING": True,
                "SECRET_KEY": "prefix-test",
                "DATABASE": str(root / "prefix.sqlite3"),
                "UPLOAD_ROOT": str(root / "uploads"),
                "PENDING_ROOT": str(root / "pending"),
                "SESSION_COOKIE_SECURE": False,
            })
            client = app.test_client()
            page = client.get("/quiz/login")
            self.assertEqual(page.status_code, 200)
            self.assertIn(b"/quiz/static/css/app.css", page.data)
            with client.session_transaction() as session:
                self.assertTrue(session["csrf_token"])
            redirect = client.get("/quiz/teacher/dashboard")
            self.assertEqual(redirect.status_code, 302)
            self.assertTrue(redirect.location.startswith("/quiz/login"))
            # 同一份部署在根路径下依然可用
            self.assertEqual(client.get("/login").status_code, 200)
        finally:
            os.environ.pop("QUIZ_URL_PREFIX", None)
            shutil.rmtree(folder, ignore_errors=True)

    def test_unknown_address_never_shows_error_page(self):
        """用户不该看到任何错误页面：陌生地址会被送回登录页并给一句提示。"""
        response = self.client.get("/this-page-does-not-exist")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response.location)
        page = self.client.get(response.location).data.decode()
        self.assertIn("页面不存在", page)
        self.assertNotIn("Not Found", page)
        self.assertNotIn("The requested URL", page)

    def test_deleted_quiz_redirects_to_list_with_hint(self):
        self.login("teacher_test", "test-only-teacher-password")
        self.client.post(f"/teacher/quizzes/{self.quiz}/delete", data={"csrf_token": self.current_csrf()})
        response = self.client.get(f"/teacher/quizzes/{self.quiz}")
        self.assertEqual(response.status_code, 302)
        self.assertIn("/teacher/quizzes", response.location)
        page = self.client.get(response.location).data.decode()
        self.assertIn("已经被移入回收站", page)
        self.assertNotIn("Not Found", page)

    def test_unpublished_quiz_redirects_student_with_hint(self):
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE quizzes SET published=0 WHERE id=?", (self.quiz,))
            database.commit()
        self.login("student_test_01", "Student123!")
        response = self.client.get(f"/student/quizzes/{self.quiz}")
        self.assertEqual(response.status_code, 200)
        self.assertIn("成绩未发布", response.get_data(as_text=True))

    def test_permission_and_expired_form_never_show_error_page(self):
        self.login("student_test_01", "Student123!")
        forbidden = self.client.get("/teacher/dashboard")
        self.assertEqual(forbidden.status_code, 302)
        self.assertIn("/student/dashboard", forbidden.location)
        self.assertIn("没有权限", self.client.get(forbidden.location).data.decode())
        client = self.app.test_client()
        expired = client.post(
            "/login",
            data={"username": "teacher_test", "password": "test-only-teacher-password"},
            headers={"Referer": "http://localhost/login"},
        )
        self.assertEqual(expired.status_code, 302)
        self.assertNotIn("Bad Request", client.get(expired.location).data.decode())

    def test_wrong_method_never_shows_error_page(self):
        response = self.client.get("/logout")
        self.assertEqual(response.status_code, 302)
        self.assertNotIn("Method Not Allowed", self.client.get(response.location).data.decode())

    def test_import_ignores_date_in_filename(self):
        """文件名前缀不参与成绩导入判断。"""
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE quizzes SET published=0 WHERE id=?", (self.quiz,))
            database.commit()
        for filename in ("20260916成绩.csv", "20990101成绩.csv"):
            score_file = io.BytesIO("student_id,score\nstudent_test_01,88\nstudent_test_02,66\n".encode("utf-8"))
            response = self.client.post(
                f"/teacher/quizzes/{self.quiz}/import",
                data={"csrf_token": self.current_csrf(), "score_file": (score_file, filename)},
                content_type="multipart/form-data",
            )
            self.assertEqual(response.status_code, 302)
            batch_id = response.location.split("/")[-2]
            body = self.client.get(response.location).get_data(as_text=True)
            self.assertNotIn("日期对不上", body)
            self.assertNotIn("文件名日期", body)
            with self.app.app_context():
                payload = json.loads(get_db().execute(
                    "SELECT payload FROM import_batches WHERE id=?", (batch_id,)
                ).fetchone()["payload"])
                self.assertNotIn("file_date", payload)
                self.assertNotIn("quiz_date", payload)
                self.assertNotIn("date_mismatch", payload)

    def test_quiz_import_infers_question_count_from_headers(self):
        self.login("teacher_test", "test-only-teacher-password")
        created = self.client.post(
            "/teacher/quizzes/create",
            data={"csrf_token": self.current_csrf(), "quiz_date": "2026-10-17", "class_id": str(self.class_id)},
        )
        quiz_id = int(created.location.rsplit("/", 1)[1])
        workbook = make_machine_export_xlsx([
            ["姓名", "学号", "判断题1", "判断题2", "判断题3", "判断题得分"],
            ["学生一", "student_test_01", 1, -1, 0, 0],
            ["学生二", "student_test_02", 1, 1, 1, 3],
        ])
        uploaded = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (workbook, "20990101成绩表.xlsx")},
            content_type="multipart/form-data",
        )
        preview = self.client.get(uploaded.location).get_data(as_text=True)
        self.assertIn("本文件识别到 3 题", preview)
        self.assertIn("发现 0 项问题", preview)
        batch_id = uploaded.location.split("/")[-2]
        confirmed = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import/{batch_id}/confirm",
            data={"csrf_token": self.current_csrf()},
        )
        self.assertEqual(confirmed.status_code, 302)
        with self.app.app_context():
            database = get_db()
            self.assertEqual(database.execute("SELECT total_score FROM quizzes WHERE id=?", (quiz_id,)).fetchone()["total_score"], 3)
            self.assertEqual(database.execute(
                "SELECT COUNT(*) FROM answer_details d JOIN scores s ON s.id=d.score_id WHERE s.quiz_id=?",
                (quiz_id,),
            ).fetchone()[0], 6)
        # 已确认题数的小测不能换成不同题数的文件。
        changed = make_machine_export_xlsx([
            ["姓名", "学号", "判断题1", "判断题2", "判断题得分"],
            ["学生一", "student_test_01", 1, -1, 0],
            ["学生二", "student_test_02", 1, 1, 2],
        ])
        uploaded = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (changed, "scores.xlsx")},
            content_type="multipart/form-data",
        )
        preview = self.client.get(uploaded.location).get_data(as_text=True)
        self.assertIn("与本次小测已确认的 3 题不一致", preview)

        created = self.client.post(
            "/teacher/quizzes/create",
            data={"csrf_token": self.current_csrf(), "quiz_date": "2026-10-19", "class_id": str(self.class_id)},
        )
        quiz_id_4 = int(created.location.rsplit("/", 1)[1])
        headers = ["姓名", "学号", *[f"判断题{number}" for number in range(1, 5)], "判断题得分"]
        workbook_4 = make_machine_export_xlsx([
            headers,
            ["学生一", "student_test_01", 1, 1, -1, 0, 1],
            ["学生二", "student_test_02", 1, 1, 1, 1, 4],
        ])
        uploaded = self.client.post(
            f"/teacher/quizzes/{quiz_id_4}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (workbook_4, "scores.xlsx")},
            content_type="multipart/form-data",
        )
        batch_id = uploaded.location.split("/")[-2]
        self.assertIn("本文件识别到 4 题", self.client.get(uploaded.location).get_data(as_text=True))
        self.client.post(
            f"/teacher/quizzes/{quiz_id_4}/import/{batch_id}/confirm",
            data={"csrf_token": self.current_csrf()},
        )
        with self.app.app_context():
            self.assertEqual(
                get_db().execute("SELECT total_score FROM quizzes WHERE id=?", (quiz_id_4,)).fetchone()["total_score"],
                4,
            )

    def test_new_quiz_import_rejects_gapped_or_duplicate_question_headers(self):
        self.login("teacher_test", "test-only-teacher-password")
        created = self.client.post(
            "/teacher/quizzes/create",
            data={"csrf_token": self.current_csrf(), "quiz_date": "2026-10-18", "class_id": str(self.class_id)},
        )
        quiz_id = int(created.location.rsplit("/", 1)[1])
        for headers, values, expected in (
            (["判断题1", "判断题3"], [1, 0], "从第1题开始连续编号"),
            (["判断题1", "判断题1"], [1, 1], "表头题号重复"),
        ):
            workbook = make_machine_export_xlsx([
                ["姓名", "学号", *headers, "判断题得分"],
                ["学生一", "student_test_01", *values, 2 if sum(values) == 2 else 1],
            ])
            uploaded = self.client.post(
                f"/teacher/quizzes/{quiz_id}/import",
                data={"csrf_token": self.current_csrf(), "score_file": (workbook, "scores.xlsx")},
                content_type="multipart/form-data",
            )
            preview = self.client.get(uploaded.location).get_data(as_text=True)
            self.assertIn(expected, preview)
            self.assertIn("发现", preview)
        score_only = io.BytesIO(b"student_id,score\nstudent_test_01,80\n")
        uploaded = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (score_only, "scores.csv")},
            content_type="multipart/form-data",
        )
        preview = self.client.get(uploaded.location).get_data(as_text=True)
        self.assertIn("成绩表须包含从第1题开始连续编号的逐题列", preview)

    def test_attendance_title_is_generated_from_selected_date(self):
        self.app.config["ATTENDANCE_CLOCK"]=lambda:1791162000
        self.login("teacher_test", "test-only-teacher-password")
        response = self.client.post(
            "/teacher/attendance/create",
            data={
                "csrf_token": self.current_csrf(),
                "attendance_date": "2026-10-05",
                "class_id": str(self.class_id),
                "duration_seconds": "120",
                "late_seconds": "30",
            },
        )
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            session = get_db().execute(
                "SELECT title,starts_at,late_after,ends_at FROM attendance_sessions ORDER BY id DESC LIMIT 1"
            ).fetchone()
            self.assertEqual(session["title"], "10月5日签到")
            self.assertAlmostEqual(session["late_after"] - session["starts_at"], 30, delta=2)
            self.assertAlmostEqual(session["ends_at"] - session["starts_at"], 120, delta=2)

    def test_attendance_creation_rejects_missing_or_invalid_selected_date(self):
        self.login("teacher_test", "test-only-teacher-password")
        for selected_date in ("", "2026-02-30"):
            response = self.client.post(
                "/teacher/attendance/create",
                data={
                    "csrf_token": self.current_csrf(),
                    "attendance_date": selected_date,
                    "class_id": str(self.class_id),
                    "duration_seconds": "120",
                    "late_seconds": "30",
                },
            )
            self.assertEqual(response.status_code, 200)
            self.assertIn("真实有效的日期", response.get_data(as_text=True))

    def test_quiz_statistics_visible_to_students_without_internal_column(self):
        """每题统计对所有学生公布，但不含机改系统的内部编号（SN）。"""
        with self.app.app_context():
            database = get_db()
            # 一个没参加这次小测的学生，用来验证"公布给所有学生"
            outsider_id = database.execute(
                "INSERT INTO users(username,name,password_hash,role,class_name,must_change_password) "
                "VALUES(?,?,?,?,?,0)",
                ("student_test_09", "学生九", generate_password_hash("Student123!"), "student", "概率论1班"),
            ).lastrowid
            database.execute(
                "INSERT INTO student_classes(student_id,class_id,status) VALUES(?,?,'active')",
                (outsider_id, self.class_id),
            )
            database.execute("UPDATE quizzes SET published=0 WHERE id=?", (self.quiz,))
            database.commit()
        self.login("teacher_test", "test-only-teacher-password")
        # 题目与答案
        questions = io.BytesIO(
            "题号,题干,答案\n1,\"若 X 与 Y 独立，则 Cov(X,Y)=0\",T\n2,\"期望一定存在\",F\n3,\"E(X²) 一定非负\",T\n".encode(
                "utf-8"
            )
        )
        self.client.post(
            f"/teacher/quizzes/{self.quiz}/questions",
            data={"csrf_token": self.current_csrf(), "question_file": (questions, "q.csv")},
            content_type="multipart/form-data",
        )
        # 逐题成绩：学生一 第2题错、第3题未作答；学生二 全对
        workbook = make_machine_export_xlsx(
            [
                ["姓名", "学号", "判断题1", "判断题2", "判断题3", "判断题得分"],
                ["学生一", "student_test_01", 1, -1, 0, 0],
                ["学生二", "student_test_02", 1, 1, 1, 3],
            ]
        )
        preview = self.client.post(
            f"/teacher/quizzes/{self.quiz}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (workbook, "考试成绩表.xlsx")},
            content_type="multipart/form-data",
        )
        batch_id = preview.location.split("/")[-2]
        self.client.post(
            f"/teacher/quizzes/{self.quiz}/import/{batch_id}/confirm",
            data={"csrf_token": self.current_csrf()},
        )
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE quizzes SET published=1 WHERE id=?", (self.quiz,))
            database.commit()

        # 教师端小测详情页也有这张统计表
        detail = self.client.get(f"/teacher/quizzes/{self.quiz}").get_data(as_text=True)
        self.assertIn("每题作答统计", detail)
        self.assertIn("2 份有效成绩", detail)

        # 参加了的学生
        student = self.app.test_client()
        self.login("student_test_01", "Student123!", student)
        page = student.get(f"/student/quizzes/{self.quiz}/statistics")
        self.assertEqual(page.status_code, 200)
        body = page.get_data(as_text=True)
        self.assertIn("每题统计", body)
        self.assertIn("有效成绩人数", body)
        self.assertNotIn("E(X²) 一定非负", body)   # 题目原文不向学生公布
        self.assertNotIn(">SN<", body)             # 机改系统的内部编号不公布
        # 第 2 题：1 人答对、1 人答错 -> 50%
        self.assertIn("50%", body)
        # 未参加的学生同样能打开统计页
        outsider = self.app.test_client()
        self.login("student_test_09", "Student123!", outsider)
        self.assertEqual(outsider.get(f"/student/quizzes/{self.quiz}/statistics").status_code, 200)

    def test_machine_export_xlsx_import(self):
        """合成机改格式 XLSX 样表：题号表头、1/-1/0 扣分制和缺考行。"""
        workbook = make_machine_export_xlsx(
            [
                ["姓名", "学号", "判断题1", "判断题2", "判断题3", "判断题得分"],
                ["学生一", "student_test_01", 1, -1, 0, 0],   # 对1题、错1题、1题未作答 => 1-1=0
                ["学生二", "student_test_02", 1, 1, 1, 3],
                ["学生三", "student_test_03", 0, 0, 0, 0],   # 整份都没作答 => 缺考
            ]
        )
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            database = get_db()
            # 缺考行也必须是目标教学班的有效学生，才能按逐题状态标记为缺考。
            student3 = database.execute(
                "INSERT INTO users(username,name,password_hash,role,class_name,must_change_password) VALUES(?,?,?,?,?,0)",
                ("student_test_03", "学生三", generate_password_hash("Student123!"), "student", "概率论1班"),
            ).lastrowid
            database.execute(
                "INSERT INTO student_classes(student_id,class_id,status) VALUES(?,?,'active')",
                (student3, self.class_id),
            )
            database.execute("UPDATE quizzes SET published=0 WHERE id=?", (self.quiz,))
            database.commit()
        response = self.client.post(
            f"/teacher/quizzes/{self.quiz}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (workbook, "20260918考试成绩表.xlsx")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 302)
        batch_id = response.location.split("/")[-2]
        preview = self.client.get(response.location).get_data(as_text=True)
        self.assertIn("学生三", preview)
        self.assertIn("保存为“未交”", preview)
        self.client.post(
            f"/teacher/quizzes/{self.quiz}/import/{batch_id}/confirm",
            data={"csrf_token": self.current_csrf()},
        )
        with self.app.app_context():
            database = get_db()
            rows = {
                row["username"]: dict(row)
                for row in database.execute(
                    "SELECT u.username, s.score, s.id AS score_id FROM scores s "
                    "JOIN users u ON u.id=s.student_id WHERE s.quiz_id=?",
                    (self.quiz,),
                )
            }
            self.assertIn("student_test_01", rows)
            self.assertNotIn("student_test_03", rows)          # 缺考的学生不写入成绩
            self.assertEqual(rows["student_test_01"]["score"], 0.0)
            self.assertEqual(rows["student_test_02"]["score"], 3.0)
            details = database.execute(
                "SELECT number, answer_status FROM answer_details WHERE score_id=? ORDER BY number",
                (rows["student_test_01"]["score_id"],),
            ).fetchall()
            self.assertEqual(
                [(item["number"], item["answer_status"]) for item in details],
                [(1, "correct"), (2, "wrong"), (3, "blank")],
            )

    def test_negative_marking_import_preserves_boundaries_zero_and_absence(self):
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            database = get_db()
            student_ids = [self.s1, self.s2]
            for index in range(3, 7):
                user_id = database.execute(
                    "INSERT INTO users(username,name,password_hash,role,class_name,must_change_password) VALUES(?,?,?,?,?,0)",
                    (f"202600000{index}", f"学生{index}", generate_password_hash("Student123!"), "student", "概率论1班"),
                ).lastrowid
                database.execute(
                    "INSERT INTO student_classes(student_id,class_id,status) VALUES(?,?,'active')",
                    (user_id, self.class_id),
                )
                student_ids.append(user_id)
            quiz_id = database.execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,scoring_mode,published,created_by) "
                "VALUES(?,?,?,?,?,'negative_marking',0,?)",
                ("10月16日小测", "2026-10-16", "概率论1班", self.class_id, 10, self.teacher),
            ).lastrowid
            database.commit()

        cases = [
            (10, ["1.0"] * 10),
            (-10, ["-1.0"] * 10),
            (-3, ["-1.0"] * 3 + ["0.0"] * 7),
            (0, ["1.0", "-1.0"] + ["0.0"] * 8),
            (2, ["1", "1", "1", "-1"] + ["0.0"] * 6),
            (0, ["0.0"] * 10),
        ]
        header = ["student_id", "score", *map(str, range(1, 11))]
        lines = [",".join(header)]
        for user_id, (score, answers) in zip(student_ids, cases):
            with self.app.app_context():
                sid = get_db().execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()["username"]
            lines.append(",".join([sid, str(score), *answers]))
        response = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (io.BytesIO(("\n".join(lines)).encode()), "scores.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(response.status_code, 302)
        batch_id = response.location.split("/")[-2]
        preview = self.client.get(response.location).get_data(as_text=True)
        self.assertIn("发现 0 项问题", preview)
        self.assertIn("保存为“未交”", preview)
        self.client.post(
            f"/teacher/quizzes/{quiz_id}/import/{batch_id}/confirm",
            data={"csrf_token": self.current_csrf()},
        )
        self.client.post(f"/teacher/quizzes/{quiz_id}/publish", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            database = get_db()
            stored = database.execute(
                "SELECT u.username,s.score,s.id AS score_id FROM scores s JOIN users u ON u.id=s.student_id WHERE s.quiz_id=? ORDER BY u.username",
                (quiz_id,),
            ).fetchall()
            self.assertEqual([row["score"] for row in stored], [10, -10, -3, 0, 2])
            self.assertEqual(len(stored), 5)
            neutral = database.execute(
                "SELECT d.number,d.answer_status FROM answer_details d JOIN scores s ON s.id=d.score_id "
                "JOIN users u ON u.id=s.student_id WHERE s.quiz_id=? AND u.username='student_test_04' ORDER BY d.number",
                (quiz_id,),
            ).fetchall()
            self.assertEqual(neutral[0]["answer_status"], "correct")
            self.assertEqual(neutral[1]["answer_status"], "wrong")
            self.assertEqual(sum(item["answer_status"] == "blank" for item in neutral), 8)
            self.assertIsNone(database.execute(
                "SELECT id FROM scores WHERE quiz_id=? AND student_id=?", (quiz_id, student_ids[-1])
            ).fetchone())
        student = self.app.test_client()
        self.login("student_test_02", "Student123!", student)
        detail = student.get(f"/student/quizzes/{quiz_id}").get_data(as_text=True)
        self.assertIn("-10", detail)
        self.assertIn("得分率 -100.0%", detail)
        self.assertIn("正确率 = 答对题数 ÷ 10 = 0.0%", detail)
        trend = student.get(f"/student/statistics?class_id={self.class_id}").get_data(as_text=True)
        self.assertIn("-100.0%", trend)

    def test_negative_marking_rejects_invalid_scores_and_question_columns(self):
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            quiz_id = get_db().execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,scoring_mode,created_by) "
                "VALUES(?,?,?,?,10,'negative_marking',?)",
                ("10月16日小测", "2026-10-16", "概率论1班", self.class_id, self.teacher),
            ).lastrowid
            get_db().commit()
        header = ["student_id", "score", *map(str, range(1, 11))]
        rows = [
            ("student_test_01", "11", ["1"] * 10),
            ("student_test_02", "-11", ["-1"] * 10),
            ("student_test_01", "0.5", ["0"] * 10),
            ("student_test_02", "NaN", ["0"] * 10),
        ]
        content = [",".join(header), *(",".join([sid, score, *answers]) for sid, score, answers in rows)]
        response = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (io.BytesIO("\n".join(content).encode()), "invalid.csv")},
            content_type="multipart/form-data",
        )
        body = self.client.get(response.location).get_data(as_text=True)
        self.assertIn("总成绩越界", body)
        self.assertIn("总成绩必须是整数", body)
        self.assertIn("总成绩必须是有限数字", body)
        self.assertIn("总成绩 11 与逐题合计 10 不一致", body)
        self.assertNotIn("确认导入成绩", body)

        missing_header = ["student_id", "score", *map(str, range(1, 10))]
        missing_data = ",".join(["student_test_01", "0", *(["0"] * 9)])
        missing = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (io.BytesIO((",".join(missing_header) + "\n" + missing_data).encode()), "missing.csv")},
            content_type="multipart/form-data",
        )
        missing_body = self.client.get(missing.location).get_data(as_text=True)
        self.assertIn("缺少题号 10", missing_body)
        self.assertNotIn("确认导入成绩", missing_body)

        duplicate_header = ["student_id", "score", "1", "1", *map(str, range(3, 11))]
        duplicate_data = ",".join(["student_test_01", "0", *(["0"] * 10)])
        duplicate = self.client.post(
            f"/teacher/quizzes/{quiz_id}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (io.BytesIO((",".join(duplicate_header) + "\n" + duplicate_data).encode()), "duplicate.csv")},
            content_type="multipart/form-data",
        )
        duplicate_body = self.client.get(duplicate.location).get_data(as_text=True)
        self.assertIn("表头题号重复", duplicate_body)
        self.assertNotIn("确认导入成绩", duplicate_body)

    def test_append_existing_student_to_second_class_keeps_account_and_password(self):
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            before = dict(get_db().execute(
                "SELECT password_hash,must_change_password FROM users WHERE id=?", (self.s1,)
            ).fetchone())

        def roster(name="学生一"):
            workbook = Workbook()
            sheet = workbook.active
            sheet.append(["学号", "姓名", "班级"])
            sheet.append(["student_test_01", name, "名单原始班级"])
            stream = io.BytesIO()
            workbook.save(stream)
            stream.seek(0)
            return stream

        response = self.client.post(
            f"/teacher/classes/{self.class2_id}/students/import",
            data={"csrf_token": self.current_csrf(), "student_file": (roster(), "roster.xlsx")},
            content_type="multipart/form-data",
        )
        preview = self.client.get(response.location).get_data(as_text=True)
        self.assertIn("名单原始班级", preview)
        self.assertIn("概率论2班", preview)
        batch_id = response.location.split("/")[-2]
        self.client.post(f"/teacher/students/import/{batch_id}/confirm", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            after = dict(get_db().execute(
                "SELECT password_hash,must_change_password FROM users WHERE id=?", (self.s1,)
            ).fetchone())
            membership_count = get_db().execute(
                "SELECT COUNT(*) FROM student_classes WHERE student_id=? AND status='active'", (self.s1,)
            ).fetchone()[0]
        self.assertEqual(after, before)
        self.assertEqual(membership_count, 2)
        student = self.app.test_client()
        self.assertIn("/student/dashboard", self.login("student_test_01", "Student123!", student).location)

        duplicate = self.client.post(
            f"/teacher/classes/{self.class2_id}/students/import",
            data={"csrf_token": self.current_csrf(), "student_file": (roster(), "roster.xlsx")},
            content_type="multipart/form-data",
        )
        duplicate_body = self.client.get(duplicate.location).get_data(as_text=True)
        self.assertIn("已加入，本次跳过", duplicate_body)
        self.assertIn("可以导入", duplicate_body)
        duplicate_batch = duplicate.location.split("/")[-2]
        self.client.post(f"/teacher/students/import/{duplicate_batch}/confirm", data={"csrf_token": self.current_csrf()})
        with self.app.app_context():
            self.assertEqual(get_db().execute(
                "SELECT COUNT(*) FROM student_classes WHERE student_id=? AND class_id=?", (self.s1, self.class2_id)
            ).fetchone()[0], 1)

        conflict = self.client.post(
            f"/teacher/classes/{self.class2_id}/students/import",
            data={"csrf_token": self.current_csrf(), "student_file": (roster("名字冲突"), "roster.xlsx")},
            content_type="multipart/form-data",
        )
        conflict_body = self.client.get(conflict.location).get_data(as_text=True)
        self.assertIn("姓名与已有账号不一致", conflict_body)
        self.assertNotIn("确认导入名单", conflict_body)

    def test_import_results_then_student_sees_score_and_stats_only(self):
        """导入逐题成绩后：学生端只看到总分和班级统计，看不到题目内容、答案或图片。"""
        self.login("teacher_test", "test-only-teacher-password")
        with self.app.app_context():
            database = get_db()
            database.execute("UPDATE quizzes SET published=0 WHERE id=?", (self.quiz,))
            database.commit()
        scores_csv = io.BytesIO(
            "student_id,score,1,2\n"
            "student_test_01,0,1,-1\n"
            "student_test_02,2,1,1\n".encode("utf-8")
        )
        preview = self.client.post(
            f"/teacher/quizzes/{self.quiz}/import",
            data={"csrf_token": self.current_csrf(), "score_file": (scores_csv, "scores.csv")},
            content_type="multipart/form-data",
        )
        self.assertEqual(preview.status_code, 302)
        self.assertIn("匹配成功", self.client.get(preview.location).get_data(as_text=True))
        batch_id = preview.location.split("/")[-2]
        confirmed = self.client.post(
            f"/teacher/quizzes/{self.quiz}/import/{batch_id}/confirm",
            data={"csrf_token": self.current_csrf()},
        )
        self.assertEqual(confirmed.status_code, 302)
        with self.app.app_context():
            database = get_db()
            self.assertEqual(
                database.execute("SELECT COUNT(*) AS n FROM answer_details").fetchone()["n"], 4
            )
            database.execute("UPDATE quizzes SET published=1 WHERE id=?", (self.quiz,))
            database.commit()
        student_client = self.app.test_client()
        self.login("student_test_01", "Student123!", student_client)
        body = student_client.get(f"/student/quizzes/{self.quiz}").get_data(as_text=True)
        self.assertIn("0", body)
        self.assertNotIn("正确答案", body)
        self.assertNotIn("试卷图片", body)
        stats_page = student_client.get(f"/student/quizzes/{self.quiz}/statistics")
        self.assertEqual(stats_page.status_code, 200)
        stats_body = stats_page.get_data(as_text=True)
        self.assertIn("每题统计", stats_body)
        self.assertIn("50%", stats_body)      # 第 2 题：1 人答对、1 人答错
        # 学生自己的逐题作答（答对 / 答错 / 未作答）也要能看到
        self.assertIn("我的逐题作答", body)
        self.assertIn("答对 <strong>1</strong>", body)
        self.assertIn("答错 1", body)
        self.assertIn("我的结果", stats_body)

    def test_student_page_never_shows_question_text_or_answers(self):
        """没有题库时同样只显示总分：学生页面不应出现任何题目内容或答案。"""
        self.login("student_test_01", "Student123!")
        body = self.client.get(f"/student/quizzes/{self.quiz}").get_data(as_text=True)
        self.assertNotIn("错题", body)
        self.assertNotIn("正确答案", body)
        self.assertIn("88", body)

    def test_end_attendance_before_late_threshold(self):
        """签到刚开始就点"结束"也必须成功。

        以前的 bug：把 ends_at 写成当前时间，若此刻还没到 late_after，
        就违反 starts_at <= late_after <= ends_at 的约束，导致签到结束不了。
        """
        now = int(time.time())
        with self.app.app_context():
            database = get_db()
            session_id = database.execute(
                "INSERT INTO attendance_sessions(title,class_name,code,qr_secret,starts_at,late_after,ends_at,created_by) "
                "VALUES(?,?,?,?,?,?,?,?)",
                ("刚开的签到", "概率论1班", "888888", "secret", now, now + 60, now + 600, self.teacher),
            ).lastrowid
            database.commit()
        self.login("teacher_test", "test-only-teacher-password")
        response = self.client.post(
            f"/teacher/attendance/{session_id}/end", data={"csrf_token": self.current_csrf()}
        )
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            row = get_db().execute(
                "SELECT active,ends_at,late_after FROM attendance_sessions WHERE id=?", (session_id,)
            ).fetchone()
            self.assertEqual(row["active"], 0)
            self.assertGreaterEqual(row["ends_at"], row["late_after"])

    def test_every_bulk_link_on_trash_page_works(self):
        """回收站页面上每个批量链接都必须能打开。

        曾经的问题：模板把"已删除小测"区块的 key 写成 records，而后端只认 quizzes，
        于是点"全部恢复/全部删除"直接 404 Not Found。
        """
        from app.teacher import _move_record_to_trash

        now = int(time.time() * 1000)
        with self.app.app_context():
            database = get_db()
            database.execute(
                "UPDATE users SET archived_at=?,purge_after=? WHERE id=?", (now, now + 86400000, self.s1)
            )
            batch = uuid.uuid4().hex
            database.execute(
                "INSERT INTO class_trash(id,class_name,deleted_at,purge_after) VALUES(?,?,?,?)",
                (batch, "概率论1班", now, now + 86400000),
            )
            database.execute("UPDATE users SET archived_batch=? WHERE id=?", (batch, self.s2))
            database.execute("UPDATE quizzes SET archived_batch=?,published=0 WHERE id=?", (batch, self.quiz))
            quiz_id = database.execute(
                "INSERT INTO quizzes(name,quiz_date,class_name,total_score,published,created_by) VALUES(?,?,?,?,0,?)",
                ("待删除小测", "2026-09-20", "概率论1班", 100, self.teacher),
            ).lastrowid
            now_seconds = int(time.time())
            session_id = database.execute(
                "INSERT INTO attendance_sessions(title,class_name,code,qr_secret,starts_at,late_after,ends_at,created_by) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (
                    "待删除签到",
                    "概率论1班",
                    "123456",
                    "secret",
                    now_seconds,
                    now_seconds + 60,
                    now_seconds + 600,
                    self.teacher,
                ),
            ).lastrowid
            database.commit()
            _move_record_to_trash("quiz", quiz_id)
            _move_record_to_trash("attendance", session_id)

        self.login("teacher_test", "test-only-teacher-password")
        page = self.client.get("/teacher/trash")
        self.assertEqual(page.status_code, 200)
        links = sorted(set(re.findall(r'href="(/teacher/trash/[^"]+)"', page.data.decode())))
        self.assertTrue(links, "回收站页面应出现批量操作链接")
        for link in links:
            response = self.client.get(link)
            self.assertLess(response.status_code, 400, f"回收站链接 {link} 异常：{response.status_code}")
        self.assertIn("/teacher/trash/quizzes/restore", links)
        self.assertIn("/teacher/trash/quizzes/purge", links)
        self.assertIn("/teacher/trash/attendances/restore", links)
        self.assertNotIn("/teacher/trash/records/restore", links)

    def _new_attendance(self, title="扫码签到", code="246810", duration=600):
        now = int(time.time())
        with self.app.app_context():
            session_id = get_db().execute(
                "INSERT INTO attendance_sessions(title,class_name,code,starts_at,late_after,ends_at,created_by) VALUES(?,?,?,?,?,?,?)",
                (title, "概率论1班", code, now, now + 60, now + duration, self.teacher),
            ).lastrowid
            get_db().commit()
        return session_id

    def test_qr_token_windows(self):
        from app import attendance_qr

        moment = 100
        token = attendance_qr.make_token("secret", 1, moment)
        self.assertTrue(attendance_qr.verify_token("secret", 1, token, moment=moment))
        self.assertFalse(attendance_qr.verify_token("secret", 1, token, moment=120))
        self.assertFalse(attendance_qr.verify_token("secret", 2, token, moment=moment))
        self.assertFalse(attendance_qr.verify_token("other-secret", 1, token, moment=moment))
        self.assertFalse(attendance_qr.verify_token("secret", 1, "", moment=moment))
        self.assertFalse(attendance_qr.verify_token("secret", 1, "not-a-token", moment=moment))
        previous = attendance_qr.make_token("secret", 1, 80)
        self.assertFalse(attendance_qr.verify_token("secret", 1, previous, moment=100))

    def test_teacher_qr_endpoint_returns_scan_url(self):
        session_id = self._new_attendance()
        self.login("teacher_test", "test-only-teacher-password")
        response = self.client.get(f"/teacher/attendance/{session_id}/qr")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn(f"/student/attendance/scan/{session_id}?t=", data["url"])
        self.assertTrue(data["open"])
        self.assertEqual(data["total"], 2)
        self.assertEqual(data["signed"], 0)
        self.assertEqual(data["window"], 20)
        self.assertTrue(0 < data["seconds_left"] <= 20)
        with self.app.app_context():
            stored = get_db().execute("SELECT qr_secret FROM attendance_sessions WHERE id=?", (session_id,)).fetchone()
            self.assertTrue(stored["qr_secret"])

    def test_student_scans_qr_code_and_signs(self):
        session_id = self._new_attendance()
        fixed_now = int(time.time())
        self.app.config["ATTENDANCE_CLOCK"] = lambda: fixed_now
        teacher_client = self.app.test_client()
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        scan_url = teacher_client.get(f"/teacher/attendance/{session_id}/qr").get_json()["url"]
        parsed = urllib.parse.urlsplit(scan_url)
        scan_path = f"{parsed.path}?{parsed.query}"

        student_client = self.app.test_client()
        self.login("student_test_01", "Student123!", student_client)
        response = student_client.get(scan_path)
        self.assertEqual(response.status_code, 302)
        self.assertIn("/student/attendance", response.location)
        with self.app.app_context():
            record = get_db().execute(
                "SELECT status,source FROM attendance_records WHERE session_id=? AND student_id=?",
                (session_id, self.s1),
            ).fetchone()
            self.assertIsNotNone(record)
            self.assertEqual(record["status"], "normal")
            self.assertEqual(record["source"], "qr")

        # 重复扫码不能产生第二条记录
        student_client.get(scan_path)
        with self.app.app_context():
            count = get_db().execute(
                "SELECT COUNT(*) AS n FROM attendance_records WHERE session_id=?", (session_id,)
            ).fetchone()["n"]
            self.assertEqual(count, 1)

    def test_scan_rejects_tampered_token(self):
        session_id = self._new_attendance()
        self.login("student_test_01", "Student123!")
        response = self.client.get(f"/student/attendance/scan/{session_id}?t=deadbeefdeadbeef")
        self.assertEqual(response.status_code, 302)
        with self.app.app_context():
            count = get_db().execute("SELECT COUNT(*) AS n FROM attendance_records").fetchone()["n"]
            self.assertEqual(count, 0)

    def test_unauthenticated_scan_does_not_create_pending_signin(self):
        """未登录扫码可以去登录，但不会创建延长签到机会的会话状态。"""
        session_id = self._new_attendance()
        fixed_now = int(time.time())
        self.app.config["ATTENDANCE_CLOCK"] = lambda: fixed_now
        teacher_client = self.app.test_client()
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        scan_url = teacher_client.get(f"/teacher/attendance/{session_id}/qr").get_json()["url"]
        parsed = urllib.parse.urlsplit(scan_url)
        scan_path = f"{parsed.path}?{parsed.query}"

        student_client = self.app.test_client()
        first = student_client.get(scan_path)
        self.assertEqual(first.status_code, 302)
        self.assertIn("/login?next=", first.location)
        with student_client.session_transaction() as sess:
            self.assertNotIn("pending_signin", sess)

        self.login("student_test_01", "Student123!", student_client)
        # 登录返回时进入下一个窗口，原扫码链接必须重新验码并失效。
        self.app.config["ATTENDANCE_CLOCK"] = lambda: (fixed_now // 20 + 1) * 20
        response = student_client.get(scan_path, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("二维码已刷新或已过期，请重新扫描屏幕上的当前二维码。", response.get_data(as_text=True))
        with self.app.app_context():
            record = get_db().execute(
                "SELECT status,source FROM attendance_records WHERE session_id=? AND student_id=?",
                (session_id, self.s1),
            ).fetchone()
            self.assertIsNone(record)

    def test_first_login_student_can_scan_through_password_change(self):
        """首次登录改密后返回扫码链接时，已过期二维码必须重新扫描。"""
        session_id = self._new_attendance()
        fixed_now = int(time.time())
        self.app.config["ATTENDANCE_CLOCK"] = lambda: fixed_now
        with self.app.app_context():
            database = get_db()
            database.execute(
                "UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?",
                (generate_password_hash("000001"), self.s1),
            )
            database.commit()
        teacher_client = self.app.test_client()
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        scan_url = teacher_client.get(f"/teacher/attendance/{session_id}/qr").get_json()["url"]
        parsed = urllib.parse.urlsplit(scan_url)
        scan_path = f"{parsed.path}?{parsed.query}"

        student_client = self.app.test_client()
        self.assertEqual(student_client.get(scan_path).status_code, 302)
        login = student_client.post(
            "/login",
            data={
                "csrf_token": self.csrf(student_client),
                "username": "student_test_01",
                "password": "000001",
                "next": scan_path,
            },
        )
        self.assertIn("/change-password", login.location)
        self.assertIn("next=", login.location)
        changed = student_client.post(
            "/change-password",
            data={
                "csrf_token": self.current_csrf(student_client),
                "current_password": "000001",
                "new_password": "BrandNew123!",
                "confirm_password": "BrandNew123!",
                "next": scan_path,
            },
        )
        self.assertIn("/login", changed.location)
        self.assertIn("next=", changed.location)
        relogin = student_client.post(
            "/login",
            data={
                "csrf_token": self.csrf(student_client),
                "username": "student_test_01",
                "password": "BrandNew123!",
                "next": scan_path,
            },
        )
        self.assertEqual(relogin.location, scan_path)
        self.app.config["ATTENDANCE_CLOCK"] = lambda: (fixed_now // 20 + 1) * 20
        returned = student_client.get(scan_path, follow_redirects=True)
        self.assertEqual(returned.status_code, 200)
        self.assertIn("二维码已刷新或已过期，请重新扫描屏幕上的当前二维码。", returned.get_data(as_text=True))
        with self.app.app_context():
            record = get_db().execute(
                "SELECT status,source FROM attendance_records WHERE session_id=? AND student_id=?",
                (session_id, self.s1),
            ).fetchone()
            self.assertIsNone(record)

    def test_login_keeps_scan_token_in_next(self):
        session_id = self._new_attendance()
        teacher_client = self.app.test_client()
        self.login("teacher_test", "test-only-teacher-password", teacher_client)
        scan_url = teacher_client.get(f"/teacher/attendance/{session_id}/qr").get_json()["url"]
        parsed = urllib.parse.urlsplit(scan_url)
        target = f"{parsed.path}?{parsed.query}"
        anonymous = self.app.test_client()
        redirect_response = anonymous.get(target)
        self.assertEqual(redirect_response.status_code, 302)
        self.assertIn("/login?next=", redirect_response.location)
        token = self.csrf(anonymous)
        posted = anonymous.post(
            "/login",
            data={"csrf_token": token, "username": "student_test_01", "password": "Student123!", "next": target},
        )
        self.assertEqual(posted.status_code, 302)
        self.assertEqual(posted.location, target)
        # 外部跳转必须被拒绝
        other = self.app.test_client()
        token = self.csrf(other)
        posted = other.post(
            "/login",
            data={"csrf_token": token, "username": "student_test_01", "password": "Student123!", "next": "//evil.example.com/x"},
        )
        self.assertEqual(posted.location, "/student/dashboard")


if __name__ == "__main__":
    unittest.main()
