import tempfile
import unittest
from pathlib import Path

from werkzeug.security import generate_password_hash

from app import create_app
from app.db import get_db


class FakeUpdaterClient:
    def __init__(self):
        self.check_calls = 0
        self.install_calls = 0
        self.state = {
            "phase": "checked",
            "current_version": "1.0.0",
            "available_version": "1.1.0",
            "update_notes": "合成更新说明",
            "operation_busy": False,
            "last_success_version": "1.0.0",
        }

    def status(self):
        return dict(self.state)

    def check(self):
        self.check_calls += 1
        return {"accepted": True}

    def install(self):
        self.install_calls += 1
        return {"accepted": True}


class UpdateRouteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.root = Path(self.temp.name)
        self.app = create_app(
            {
                "TESTING": True,
                "SECRET_KEY": "synthetic-update-page-key",
                "DATABASE": str(self.root / "instance" / "quiz.sqlite3"),
                "UPLOAD_ROOT": str(self.root / "instance" / "uploads"),
                "PENDING_ROOT": str(self.root / "instance" / "pending"),
                "URL_PREFIX": "/quiz",
                "APP_VERSION": "1.0.0",
            }
        )
        self.updater = FakeUpdaterClient()
        self.app.extensions["updater_client"] = self.updater
        with self.app.app_context():
            database = get_db()
            for username, role in (("teacher_test", "teacher"), ("A001", "admin"), ("S001", "student")):
                database.execute(
                    "INSERT INTO users(username,name,password_hash,role,must_change_password) VALUES(?,?,?,?,0)",
                    (username, role, generate_password_hash("Synthetic123!"), role),
                )
            database.commit()
        self.client = self.app.test_client()

    def tearDown(self):
        self.temp.cleanup()

    def csrf(self, client, logged_in=False):
        client.get("/quiz/change-password" if logged_in else "/quiz/login")
        with client.session_transaction() as session:
            return session["csrf_token"]

    def login(self, username, role="teacher"):
        client = self.app.test_client()
        client.post(
            "/quiz/login",
            data={"csrf_token": self.csrf(client), "username": username, "password": "Synthetic123!"},
        )
        return client

    def test_teacher_page_shows_status_and_prefixed_fixed_actions(self):
        client = self.login("teacher_test")
        response = client.get("/quiz/teacher/system-update")
        page = response.get_data(as_text=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("系统更新", page)
        self.assertIn("1.0.0", page)
        self.assertIn("1.1.0", page)
        self.assertIn("合成更新说明", page)
        self.assertIn('action="/quiz/teacher/system-update/check"', page)
        self.assertIn('action="/quiz/teacher/system-update/install"', page)
        self.assertIn('name="csrf_token"', page)

    def test_student_cannot_see_or_trigger_update(self):
        client = self.login("S001")
        dashboard = client.get("/quiz/student/dashboard").get_data(as_text=True)
        self.assertNotIn("系统更新", dashboard)
        blocked = client.get("/quiz/teacher/system-update")
        self.assertEqual(blocked.status_code, 302)
        token = self.csrf(client, logged_in=True)
        response = client.post(
            "/quiz/teacher/system-update/install",
            data={"csrf_token": token},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.updater.install_calls, 0)

    def test_posts_require_csrf_and_forward_only_fixed_methods(self):
        client = self.login("A001")
        missing = client.post("/quiz/teacher/system-update/check")
        self.assertEqual(missing.status_code, 302)
        self.assertEqual(self.updater.check_calls, 0)
        token = self.csrf(client, logged_in=True)
        checked = client.post(
            "/quiz/teacher/system-update/check",
            data={"csrf_token": token, "url": "https://evil.example", "path": "C:\\Windows", "command": "powershell"},
        )
        self.assertEqual(checked.status_code, 302)
        self.assertEqual(self.updater.check_calls, 1)
        token = self.csrf(client, logged_in=True)
        installed = client.post(
            "/quiz/teacher/system-update/install",
            data={"csrf_token": token, "url": "https://evil.example", "path": "C:\\Windows", "command": "powershell"},
            follow_redirects=True,
        )
        self.assertEqual(installed.status_code, 200)
        self.assertEqual(self.updater.install_calls, 1)
        self.assertIn("网站会短暂不可访问", installed.get_data(as_text=True))

    def test_disconnected_agent_shows_admin_guidance(self):
        self.app.extensions["updater_client"] = None
        client = self.login("teacher_test")
        page = client.get("/quiz/teacher/system-update").get_data(as_text=True)
        self.assertIn("更新助手尚未安装", page)
        self.assertIn("disabled", page)


if __name__ == "__main__":
    unittest.main()
