from __future__ import annotations

import hashlib
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from updater.package_builder import (
    PackageBuildError,
    _validate_archive_names,
    build_program_zip,
)


class ProgramPackageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(dir=Path.cwd())
        self.root = Path(self.temp.name) / "project"
        self.root.mkdir()
        self._write("app/routes.py", b"routes = True\n")
        self._write("scripts/start_server.py", b"print('server')\n")
        self._write("run.py", b"print('run')\n")
        self._write("wsgi.py", b"app = None\n")
        self._write("requirements.txt", b"Flask==3.1.2\n")
        self._write("VERSION", b"1.0.0\n")
        self._write("instance/quiz.sqlite3", b"database")
        self._write("instance_demo/quiz.sqlite3", b"demo")
        self._write("secret_key.txt", b"secret")
        self._write(".venv/marker", b"venv")
        self._write("backups/old.zip", b"backup")
        self._write("logs/server.log", b"log")

    def tearDown(self) -> None:
        self.temp.cleanup()

    def _write(self, relative: str, data: bytes) -> Path:
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def test_package_contains_only_the_fixed_allowlist(self) -> None:
        output = Path(self.temp.name) / "program.zip"
        digest = build_program_zip(self.root, output)
        with zipfile.ZipFile(output) as archive:
            names = archive.namelist()
            self.assertEqual(
                names,
                [
                    "app/routes.py",
                    "requirements.txt",
                    "run.py",
                    "scripts/start_server.py",
                    "VERSION",
                    "wsgi.py",
                ],
            )
            self.assertEqual(archive.read("app/routes.py"), b"routes = True\n")
            self.assertEqual(archive.read("scripts/start_server.py"), b"print('server')\n")
            self.assertNotIn("secret_key.txt", names)
            self.assertFalse(any(name.startswith("instance") for name in names))
            self.assertFalse(any("backup" in name.lower() for name in names))
        self.assertEqual(digest.size, output.stat().st_size)
        self.assertEqual(digest.sha256, hashlib.sha256(output.read_bytes()).hexdigest())
        self.assertEqual(
            digest.requirements_sha256,
            hashlib.sha256(b"Flask==3.1.2\n").hexdigest(),
        )

    def test_source_change_changes_digest(self) -> None:
        first = Path(self.temp.name) / "first.zip"
        second = Path(self.temp.name) / "second.zip"
        first_digest = build_program_zip(self.root, first)
        self._write("app/routes.py", b"routes = False\n")
        second_digest = build_program_zip(self.root, second)
        self.assertNotEqual(first_digest.sha256, second_digest.sha256)

    def test_missing_required_file_fails_without_leaving_partial_output(self) -> None:
        (self.root / "wsgi.py").unlink()
        output = Path(self.temp.name) / "broken.zip"
        with self.assertRaises(PackageBuildError):
            build_program_zip(self.root, output)
        self.assertFalse(output.exists())
        self.assertEqual(list(Path(self.temp.name).glob(".broken.zip.*.tmp")), [])

    def test_reparse_points_are_rejected(self) -> None:
        output = Path(self.temp.name) / "reparse.zip"
        with patch(
            "updater.package_builder._is_reparse_point",
            side_effect=lambda path: path.name == "routes.py",
        ):
            with self.assertRaises(PackageBuildError):
                build_program_zip(self.root, output)
        self.assertFalse(output.exists())

    def test_archive_names_reject_traversal_absolute_and_case_duplicates(self) -> None:
        for names in (
            ["../outside.txt"],
            ["/absolute.txt"],
            ["app/first.py", "app/FIRST.py"],
            ["C:/outside.txt"],
        ):
            with self.subTest(names=names), self.assertRaises(PackageBuildError):
                _validate_archive_names(names)


if __name__ == "__main__":
    unittest.main()
