import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class WindowsStartupContractTests(unittest.TestCase):
    def test_managed_mode_hands_off_before_dependency_or_secret_setup(self):
        launcher = (ROOT / "start_windows.bat").read_bytes().decode("cp936")
        managed = launcher.index(":managed_start")
        python_probe = launcher.index("rem ---------- 1.")
        self.assertLess(managed, python_probe)
        self.assertIn('if /i "%QUIZ_INSTANCE_DIR%"=="instance_demo" goto :startup_direct', launcher)
        self.assertIn('".venv\\Scripts\\python.exe" -I -S "%ProgramData%\\ProbabilityQuizUpdater\\quiz-updater.pyz" --open-site', launcher)
        self.assertIn('if exist "%ProgramData%\\ProbabilityQuizUpdater\\quiz-updater.pyz" goto :managed_start', launcher)
        managed_block = launcher[managed:python_probe]
        self.assertNotIn("--agent", managed_block)
        self.assertNotIn("--config", managed_block)
        self.assertNotIn("QUIZ_INSTANCE_DIR=instance_demo", managed_block)

    def test_demo_launcher_still_selects_only_demo_data(self):
        demo = (ROOT / "试用-演示数据.bat").read_bytes().decode("cp936")
        self.assertIn('set "QUIZ_INSTANCE_DIR=instance_demo"', demo)
        self.assertIn("start_windows.bat", demo)


if __name__ == "__main__":
    unittest.main()
