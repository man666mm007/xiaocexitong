import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
INSTALLER = PROJECT / "scripts" / "install_updater.ps1"
PWSH = shutil.which("pwsh") or shutil.which("powershell")


@unittest.skipUnless(PWSH, "PowerShell is required for installer contract tests")
class InstallScriptContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=PROJECT)
        self.root = Path(self.temp.name)
        self.project = self.root / "project with spaces"
        self.data = self.project / "instance"
        self.project.mkdir()
        self.data.mkdir()
        (self.project / "VERSION").write_text("1.0.0\n", encoding="ascii")
        (self.project / "secret_key.txt").write_text("synthetic-secret", encoding="utf-8")
        (self.project / "scripts").mkdir()
        (self.project / "scripts" / "install_program_version.py").write_text("# fixture\n", encoding="utf-8")
        self.key = self.root / "public.pem"
        self.key.write_text("synthetic-public-key", encoding="ascii")
        self.helper = self.root / "quiz-updater.pyz"
        self.helper.write_bytes(b"synthetic-helper")
        self.python = self.project / ".venv" / "Scripts" / "python.exe"
        self.python.parent.mkdir(parents=True)
        self.python.write_bytes(b"synthetic-python")
        self.backup = self.root / "external backup"

    def tearDown(self):
        self.temp.cleanup()

    def invoke(self, **overrides):
        args = {
            "ProjectRoot": self.project,
            "DataRoot": self.data,
            "Repository": "school/probability-quiz",
            "PublicKey": self.key,
            "HelperPackage": self.helper,
            "PythonPath": self.python,
            "BackupRoot": self.backup,
            "Port": 5000,
            "UrlPrefix": "/quiz",
        }
        args.update(overrides)
        command = [PWSH, "-NoLogo", "-NoProfile", "-File", str(INSTALLER)]
        for key, value in args.items():
            command.extend([f"-{key}", str(value)])
        command.append("-WhatIf")
        return subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)

    def test_whatif_outputs_a_plan_without_creating_server_files(self):
        result = self.invoke()
        self.assertEqual(result.returncode, 0, result.stderr)
        plan = json.loads(result.stdout.strip())
        self.assertEqual(plan["status"], "what-if")
        self.assertEqual(plan["repository"], "school/probability-quiz")
        self.assertEqual(Path(plan["paths"]["project_root"]), self.project)
        self.assertFalse(self.backup.exists())
        self.assertFalse((self.root / "ProbabilityQuizUpdater").exists())

    def test_whatif_rejects_bad_repository_port_prefix_and_overlapping_backup(self):
        invalid = (
            {"Repository": "https://github.com/school/repo"},
            {"Port": 8000},
            {"UrlPrefix": "/other"},
            {"BackupRoot": self.project / "backups"},
            {"DataRoot": self.project},
        )
        for values in invalid:
            with self.subTest(values=values):
                result = self.invoke(**values)
                self.assertNotEqual(result.returncode, 0)

    def test_installer_protects_assistant_and_child_directories_from_inherited_acl(self):
        source = INSTALLER.read_text(encoding="utf-8")
        self.assertIn('Invoke-Icacls @($assistantRoot, "/inheritance:r")', source)
        self.assertIn('Invoke-Icacls @($writable, "/inheritance:r")', source)
        self.assertIn('"$ns`:(OI)(CI)(M)"', source)


if __name__ == "__main__":
    unittest.main()
