from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
SCRIPT = PROJECT / "scripts" / "rehearse_update.py"
SCENARIOS = {
    "success": ("succeeded", "1.1.0", 1),
    "download-failure": ("failed", "1.0.0", 0),
    "bad-signature": ("failed", "1.0.0", 0),
    "incompatible": ("failed", "1.0.0", 0),
    "dependency-change": ("failed", "1.0.0", 0),
    "startup-failure": ("recovered", "1.0.0", 2),
}


class UpdateRehearsalTests(unittest.TestCase):
    def test_all_scenarios_preserve_synthetic_data_and_report_expected_result(self):
        source_version = PROJECT / "VERSION"
        source_before = hashlib.sha256(source_version.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory(dir=PROJECT) as folder:
            root = Path(folder)
            for scenario, (expected_status, expected_version, expected_stops) in SCENARIOS.items():
                output = root / scenario
                result = subprocess.run(
                    [sys.executable, "-I", "-S", str(SCRIPT), "--source", str(PROJECT), "--output", str(output), "--scenario", scenario],
                    check=False,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    timeout=20,
                )
                with self.subTest(scenario=scenario):
                    self.assertEqual(result.returncode, 0, (result.stderr or "") + (result.stdout or ""))
                    report = json.loads(result.stdout)
                    self.assertEqual(report["status"], expected_status)
                    self.assertEqual(report["program_version"], expected_version)
                    self.assertEqual(report["site_stop_calls"], expected_stops)
                    self.assertTrue(report["data_preserved"])
                    self.assertEqual(report["old_version_restored"], scenario == "startup-failure")
                    self.assertIn("quiz.sqlite3", report["database_upload_pending_sha256"])
                    self.assertTrue((output / "synthetic-instance" / "uploads" / "synthetic.png").is_file())
                    self.assertTrue((output / "synthetic-instance" / "pending" / "batch.json").is_file())
        self.assertEqual(hashlib.sha256(source_version.read_bytes()).hexdigest(), source_before)

    def test_refuses_nonempty_output_directory(self):
        with tempfile.TemporaryDirectory(dir=PROJECT) as folder:
            output = Path(folder) / "occupied"
            output.mkdir()
            sentinel = output / "keep.txt"
            sentinel.write_text("preserve", encoding="utf-8")
            result = subprocess.run(
                [sys.executable, "-I", "-S", str(SCRIPT), "--source", str(PROJECT), "--output", str(output), "--scenario", "success"],
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=10,
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "preserve")


if __name__ == "__main__":
    unittest.main()
