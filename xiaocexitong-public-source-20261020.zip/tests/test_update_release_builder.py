from __future__ import annotations

import base64
import contextlib
import hashlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from updater.manifest import UpdateManifest
from updater.release_builder import ReleaseBuildError, build_release
from updater.signatures import verify_manifest_signature
from scripts import build_update_release


class ReleaseBuilderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(dir=Path.cwd())
        self.root = Path(self.temp.name) / "project"
        self.root.mkdir()
        for relative, content in {
            "app/routes.py": b"routes = True\n",
            "scripts/start_server.py": b"print('server')\n",
            "run.py": b"print('run')\n",
            "wsgi.py": b"app = None\n",
            "requirements.txt": b"Flask==3.1.2\n",
            "VERSION": b"1.0.1\n",
        }.items():
            path = self.root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        self.output = Path(self.temp.name) / "release-assets"
        self.output.mkdir()
        self.private_key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        self.private_path = Path(self.temp.name) / "release-private.pem"
        self.private_pem = self.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        self.private_path.write_bytes(self.private_pem)
        self.public_pem = self.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def tearDown(self) -> None:
        self.temp.cleanup()

    def build(self):
        return build_release(
            project_root=self.root,
            repository="example/quiz-system",
            tag="v1.0.1",
            notes="Bug fixes and stability improvements.",
            min_version="1.0.0",
            max_version="1.0.0",
            required_schema_version=5,
            key_id="release-key-2026",
            private_key_path=self.private_path,
            output_dir=self.output,
        )

    def test_builds_verifiable_release_assets(self) -> None:
        result = self.build()
        self.assertEqual(result.package_path.name, "quiz-program-v1.0.1.zip")
        self.assertEqual(result.manifest_path.name, "update-manifest.json")
        self.assertEqual(result.signature_path.name, "update-manifest.json.sig")

        raw = result.manifest_path.read_bytes()
        signature = base64.b64decode(result.signature_path.read_bytes().strip(), validate=True)
        verify_manifest_signature(raw, signature, self.public_pem)
        manifest = UpdateManifest.from_bytes(raw, "example/quiz-system", "v1.0.1")
        package_bytes = result.package_path.read_bytes()
        self.assertEqual(manifest.package_size, len(package_bytes))
        self.assertEqual(manifest.package_sha256, hashlib.sha256(package_bytes).hexdigest())
        self.assertEqual(
            manifest.requirements_sha256,
            hashlib.sha256((self.root / "requirements.txt").read_bytes()).hexdigest(),
        )
        self.assertEqual(
            manifest.package_url,
            "https://github.com/example/quiz-system/releases/download/"
            "v1.0.1/quiz-program-v1.0.1.zip",
        )
        with zipfile.ZipFile(result.package_path) as archive:
            self.assertIn("app/routes.py", archive.namelist())
        for asset in (result.package_path, result.manifest_path, result.signature_path):
            self.assertNotIn(self.private_pem, asset.read_bytes())

    def test_refuses_private_key_inside_project_tree(self) -> None:
        internal_key = self.root / "developer-key.pem"
        internal_key.write_bytes(self.private_pem)
        with self.assertRaises(ReleaseBuildError):
            build_release(
                project_root=self.root,
                repository="example/quiz-system",
                tag="v1.0.1",
                notes="notes",
                min_version="1.0.0",
                max_version="1.0.0",
                required_schema_version=5,
                key_id="release-key-2026",
                private_key_path=internal_key,
                output_dir=self.output,
            )

    def test_release_args_must_match_program_version(self) -> None:
        with self.assertRaises(ReleaseBuildError):
            build_release(
                project_root=self.root,
                repository="example/quiz-system",
                tag="v1.0.2",
                notes="notes",
                min_version="1.0.0",
                max_version="1.0.0",
                required_schema_version=5,
                key_id="release-key-2026",
                private_key_path=self.private_path,
                output_dir=self.output,
            )

    def test_cli_builds_local_assets_without_printing_private_key(self) -> None:
        notes_path = Path(self.temp.name) / "notes.md"
        notes_path.write_text("Local fixture release.\n", encoding="utf-8")
        output_dir = Path(self.temp.name) / "cli-assets"
        output = io.StringIO()
        with patch.object(build_update_release, "PROJECT_ROOT", self.root), contextlib.redirect_stdout(output):
            return_code = build_update_release.main(
                [
                    "--repository",
                    "example/quiz-system",
                    "--tag",
                    "v1.0.1",
                    "--notes-file",
                    str(notes_path),
                    "--min-version",
                    "1.0.0",
                    "--max-version",
                    "1.0.0",
                    "--schema-version",
                    "5",
                    "--key-id",
                    "test-key",
                    "--private-key",
                    str(self.private_path),
                    "--output-dir",
                    str(output_dir),
                ]
            )
        self.assertEqual(return_code, 0)
        self.assertNotIn(self.private_pem.decode("ascii"), output.getvalue())
        self.assertEqual(
            sorted(path.name for path in output_dir.iterdir()),
            ["quiz-program-v1.0.1.zip", "update-manifest.json", "update-manifest.json.sig"],
        )


if __name__ == "__main__":
    unittest.main()
