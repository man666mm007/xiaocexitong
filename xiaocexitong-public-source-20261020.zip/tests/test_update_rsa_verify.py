import unittest

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from updater.rsa_verify import SignatureVerificationError, verify_rsa_pss_sha256


class StandardLibraryRSAVerificationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.private = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        cls.public_pem = cls.private.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def test_accepts_rsa_pss_sha256_signature_with_fixed_salt(self):
        message = b"signed update manifest bytes"
        signature = self.private.sign(
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        verify_rsa_pss_sha256(message, signature, self.public_pem)

    def test_rejects_changed_message_signature_or_wrong_salt_length(self):
        message = b"signed update manifest bytes"
        signature = self.private.sign(
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        for candidate in (signature[:-1] + bytes([signature[-1] ^ 1]), b"short"):
            with self.subTest(candidate_length=len(candidate)):
                with self.assertRaises(SignatureVerificationError):
                    verify_rsa_pss_sha256(message, candidate, self.public_pem)
        with self.assertRaises(SignatureVerificationError):
            verify_rsa_pss_sha256(message + b"!", signature, self.public_pem)

        nonstandard_salt = self.private.sign(
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )
        with self.assertRaises(SignatureVerificationError):
            verify_rsa_pss_sha256(message, nonstandard_salt, self.public_pem)

    def test_rejects_invalid_or_undersized_key(self):
        with self.assertRaises(SignatureVerificationError):
            verify_rsa_pss_sha256(b"message", b"signature", b"not a key")


if __name__ == "__main__":
    unittest.main()
