from __future__ import annotations

import unittest

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from updater.signatures import SignatureError, sign_manifest, verify_manifest_signature


class ManifestSignatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.private_key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        cls.public_pem = cls.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        cls.private_pem = cls.private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def test_valid_rsa_pss_signature_verifies(self) -> None:
        payload = b'{"version":"1.0.1"}'
        signature = sign_manifest(payload, self.private_pem)
        verify_manifest_signature(payload, signature, self.public_pem)

    def test_tampered_payload_is_rejected(self) -> None:
        signature = sign_manifest(b'{"version":"1.0.1"}', self.private_pem)
        with self.assertRaises(SignatureError):
            verify_manifest_signature(b'{"version":"9.9.9"}', signature, self.public_pem)

    def test_wrong_key_is_rejected(self) -> None:
        other = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        other_public = other.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        signature = sign_manifest(b"release", self.private_pem)
        with self.assertRaises(SignatureError):
            verify_manifest_signature(b"release", signature, other_public)

    def test_weak_or_non_rsa_keys_are_rejected(self) -> None:
        weak = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        weak_pem = weak.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        with self.assertRaises(SignatureError):
            sign_manifest(b"release", weak_pem)
        with self.assertRaises(SignatureError):
            verify_manifest_signature(b"release", b"invalid", b"not a public key")


if __name__ == "__main__":
    unittest.main()
