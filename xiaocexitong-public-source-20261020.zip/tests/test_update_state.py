import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from updater.state import UpdateState, read_state, write_state


class UpdateStateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.path = Path(self.temp.name) / "state.json"

    def tearDown(self):
        self.temp.cleanup()

    def test_missing_or_corrupt_state_is_safe_idle_state(self):
        self.assertEqual(read_state(self.path), UpdateState())
        self.path.write_text("not-json", encoding="utf-8")
        self.assertEqual(read_state(self.path), UpdateState())

    def test_state_sequence_is_atomically_serialized(self):
        sequence = [
            UpdateState(phase="idle"),
            UpdateState(phase="checked", current_version="1.0.0", available_version="1.1.0"),
            UpdateState(phase="downloading", current_version="1.0.0", available_version="1.1.0"),
            UpdateState(phase="installing", current_version="1.0.0", available_version="1.1.0"),
            UpdateState(phase="succeeded", current_version="1.1.0", last_success_version="1.1.0"),
        ]
        for expected in sequence:
            write_state(self.path, expected)
            self.assertEqual(read_state(self.path), expected)

    def test_failed_replace_preserves_old_state(self):
        original = UpdateState(phase="checked", current_version="1.0.0")
        write_state(self.path, original)
        with mock.patch("updater.state.os.replace", side_effect=OSError("synthetic replace failure")):
            with self.assertRaises(OSError):
                write_state(self.path, UpdateState(phase="installing", current_version="1.0.0"))
        self.assertEqual(read_state(self.path), original)
        self.assertEqual(list(Path(self.temp.name).glob("*.tmp")), [])

    def test_state_serialization_rejects_secret_fields_and_values(self):
        state = UpdateState(phase="failed", message="ordinary failure")
        write_state(self.path, state)
        raw = self.path.read_text(encoding="utf-8")
        for forbidden in ("agent_token", "QUIZ_SECRET_KEY", "PRIVATE KEY", "synthetic-token"):
            self.assertNotIn(forbidden, raw)
        self.assertEqual(json.loads(raw)["phase"], "failed")


if __name__ == "__main__":
    unittest.main()
