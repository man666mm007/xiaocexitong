import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

from scripts.build_update_agent import build_agent_zipapp


class UpdateAgentBundleTests(unittest.TestCase):
    def test_builds_reproducible_standalone_standard_library_zipapp(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]) as folder:
            output = Path(folder) / "quiz-updater.pyz"
            build_agent_zipapp(Path(__file__).resolve().parents[1], output)
            first = output.read_bytes()
            build_agent_zipapp(Path(__file__).resolve().parents[1], output)
            self.assertEqual(output.read_bytes(), first)
            with zipfile.ZipFile(output) as archive:
                names = set(archive.namelist())
                self.assertIn("__main__.py", names)
                self.assertIn("updater/engine.py", names)
                self.assertNotIn("updater/signatures.py", names)
                self.assertFalse(any(name.startswith(("app/", "instance/", ".venv/")) for name in names))
                payload = b"".join(archive.read(name) for name in names)
                self.assertNotIn(b"BEGIN PRIVATE KEY", payload)

            result = subprocess.run(
                [sys.executable, "-I", "-S", str(output), "--help"],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("--agent", result.stdout)
            self.assertIn("--open-site", result.stdout)


if __name__ == "__main__":
    unittest.main()
