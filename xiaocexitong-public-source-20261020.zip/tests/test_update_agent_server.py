import json
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from updater.agent_server import AgentServer


class AgentServerTests(unittest.TestCase):
    def setUp(self):
        self.token = "synthetic-agent-token"
        self.calls = []
        self.release_operation = threading.Event()
        self.server = AgentServer(
            0,
            self.token,
            status=lambda: {"phase": "checked", "current_version": "1.0.0", "api_token": "must-not-leak"},
            check=lambda: self.calls.append("check"),
            install=self.blocking_install,
        )
        self.thread = self.server.start_in_thread()
        self.base = f"http://127.0.0.1:{self.server.address[1]}"

    def tearDown(self):
        self.release_operation.set()
        self.server.close()
        self.thread.join(timeout=2)

    def blocking_install(self):
        self.calls.append("install")
        self.release_operation.wait(2)

    def request(self, path, method="GET", token=None, body=None, content_type="application/json"):
        headers = {}
        if token is not None:
            headers["Authorization"] = f"Bearer {token}"
        if body is not None:
            headers["Content-Type"] = content_type
        request = urllib.request.Request(
            self.base + path,
            data=body,
            headers=headers,
            method=method,
        )
        try:
            response = urllib.request.urlopen(request, timeout=2)
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()
        with response:
            return response.status, response.read()

    def test_loopback_status_requires_token_and_filters_unknown_state_fields(self):
        self.assertEqual(self.server.address[0], "127.0.0.1")
        self.assertEqual(self.request("/v1/status")[0], 401)
        status, body = self.request("/v1/status", token=self.token)
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body), {"phase": "checked", "current_version": "1.0.0", "operation_busy": False})

    def test_only_empty_json_and_fixed_post_actions_are_accepted(self):
        self.assertEqual(self.request("/v1/check", method="POST", token=self.token, body=b'{"command":"powershell"}')[0], 400)
        self.assertEqual(self.request("/v1/install", method="POST", token=self.token, body=b'{"url":"https://evil.example"}')[0], 400)
        self.assertEqual(self.request("/v1/install", method="POST", token=self.token, body=b'{"path":"C:\\\\Windows"}')[0], 400)
        self.assertEqual(self.request("/v1/unknown", method="POST", token=self.token, body=b"{}")[0], 404)
        self.assertEqual(self.request("/v1/check", method="POST", token="wrong", body=b"{}")[0], 401)
        self.assertEqual(self.request("/v1/check", method="POST", token=self.token, body=b"{}", content_type="text/plain")[0], 415)

    def test_install_is_accepted_async_and_concurrent_action_is_rejected(self):
        status, body = self.request("/v1/install", method="POST", token=self.token, body=b"{}")
        self.assertEqual(status, 202)
        self.assertEqual(json.loads(body)["operation"], "install")
        deadline = time.monotonic() + 1
        while not self.calls and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertEqual(self.calls, ["install"])
        self.assertEqual(self.request("/v1/check", method="POST", token=self.token, body=b"{}")[0], 409)


if __name__ == "__main__":
    unittest.main()
