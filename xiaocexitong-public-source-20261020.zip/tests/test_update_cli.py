import io
import unittest
from unittest import mock

from updater import __main__ as cli


class FakeResponse:
    status = 200

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


class UpdaterCliTests(unittest.TestCase):
    def test_token_acl_accepts_only_the_installer_principals(self):
        path = cli.Path("C:/ProgramData/ProbabilityQuizUpdater/agent.token")
        safe = (
            f"{path}\n"
            "  NT AUTHORITY\\SYSTEM:(F)\n"
            "  BUILTIN\\Administrators:(F)\n"
            "  NT AUTHORITY\\NETWORK SERVICE:(R)\n"
        )
        with mock.patch.object(cli.sys, "platform", "win32"), mock.patch.object(
            cli.subprocess, "run", return_value=mock.Mock(returncode=0, stdout=safe)
        ):
            cli._validate_token_acl(path)

        for untrusted in (
            safe + "  BUILTIN\\Users:(R)\n",
            safe.replace("NETWORK SERVICE:(R)", "NETWORK SERVICE:(F)"),
            safe.replace("SYSTEM:(F)", "SYSTEM:(R)"),
        ):
            with self.subTest(acl=untrusted), mock.patch.object(cli.sys, "platform", "win32"), mock.patch.object(
                cli.subprocess, "run", return_value=mock.Mock(returncode=0, stdout=untrusted)
            ), self.assertRaises(RuntimeError):
                cli._validate_token_acl(path)

    def test_open_site_uses_fixed_address_without_loading_configuration(self):
        with mock.patch.object(cli.urllib.request, "urlopen", return_value=FakeResponse()) as opened, mock.patch.object(
            cli.webbrowser, "open", return_value=True
        ) as browser:
            self.assertEqual(cli.main(["--open-site"]), 0)
        self.assertEqual(opened.call_args.args[0], "http://127.0.0.1:5000/quiz/")
        self.assertEqual(browser.call_args.args[0], "http://127.0.0.1:5000/quiz/")
        self.assertNotIn("config", [call.args[0] for call in []])

    def test_agent_requires_absolute_protected_config_path(self):
        for arguments in (["--agent"], ["--agent", "--config", "relative.json"]):
            with self.subTest(arguments=arguments), self.assertRaises(SystemExit) as raised:
                cli.main(arguments)
            self.assertEqual(raised.exception.code, 2)

    def test_open_site_rejects_config_and_unknown_dynamic_commands(self):
        for arguments in (
            ["--open-site", "--config", "C:\\ProgramData\\secret.json"],
            ["--agent", "--config", "C:\\ProgramData\\config.json", "--command", "powershell"],
        ):
            with self.subTest(arguments=arguments), self.assertRaises(SystemExit) as raised:
                cli.main(arguments)
            self.assertEqual(raised.exception.code, 2)

    def test_help_does_not_start_site_or_read_configuration(self):
        with mock.patch.object(cli, "_run_agent") as run_agent, mock.patch.object(cli, "_open_site") as open_site:
            with self.assertRaises(SystemExit) as raised:
                cli.main(["--help"])
        self.assertEqual(raised.exception.code, 0)
        run_agent.assert_not_called()
        open_site.assert_not_called()


if __name__ == "__main__":
    unittest.main()
