from __future__ import annotations

import hashlib
import json
import unittest

from updater.manifest import ManifestError, UpdateManifest, parse_version


class ManifestContractTests(unittest.TestCase):
    repository = "example/quiz-system"
    tag = "v1.0.1"

    def valid_manifest(self) -> dict[str, object]:
        return {
            "version": "1.0.1",
            "compatible_min": "1.0.0",
            "compatible_max": "1.0.0",
            "notes": "Security and stability updates.",
            "tag": self.tag,
            "repository": self.repository,
            "package_url": (
                "https://github.com/example/quiz-system/releases/download/"
                "v1.0.1/quiz-program-v1.0.1.zip"
            ),
            "package_size": 1234,
            "package_sha256": hashlib.sha256(b"package").hexdigest(),
            "requirements_sha256": hashlib.sha256(b"requirements").hexdigest(),
            "required_schema_version": 5,
            "key_id": "release-key-2026",
        }

    def parse(self, value: dict[str, object] | bytes | None = None) -> UpdateManifest:
        if value is None:
            value = self.valid_manifest()
        raw = value if isinstance(value, bytes) else json.dumps(value).encode("utf-8")
        return UpdateManifest.from_bytes(raw, self.repository, self.tag)

    def test_parse_strict_semantic_version(self) -> None:
        self.assertEqual(parse_version("1.0.0"), (1, 0, 0))
        for value in ("01.0.0", "1.0", "1.0.0-rc1", "", "1.0.0+build"):
            with self.subTest(value=value), self.assertRaises(ManifestError):
                parse_version(value)

    def test_accepts_valid_manifest(self) -> None:
        parsed = self.parse()
        self.assertEqual(parsed.version, "1.0.1")
        self.assertEqual(parsed.required_schema_version, 5)
        self.assertEqual(parsed.repository, self.repository)

    def test_rejects_missing_and_unknown_fields(self) -> None:
        missing = self.valid_manifest()
        del missing["package_size"]
        with self.assertRaises(ManifestError):
            self.parse(missing)

        unknown = self.valid_manifest()
        unknown["command"] = "powershell"
        with self.assertRaises(ManifestError):
            self.parse(unknown)

    def test_rejects_invalid_compatibility_range(self) -> None:
        manifest = self.valid_manifest()
        manifest["compatible_min"] = "2.0.0"
        manifest["compatible_max"] = "1.0.0"
        with self.assertRaises(ManifestError):
            self.parse(manifest)

    def test_rejects_repository_or_tag_mismatch(self) -> None:
        manifest = self.valid_manifest()
        manifest["repository"] = "attacker/other"
        with self.assertRaises(ManifestError):
            self.parse(manifest)

        manifest = self.valid_manifest()
        manifest["tag"] = "v1.0.2"
        with self.assertRaises(ManifestError):
            self.parse(manifest)

        manifest = self.valid_manifest()
        manifest["version"] = "1.0.2"
        with self.assertRaises(ManifestError):
            self.parse(manifest)

    def test_rejects_non_release_or_untrusted_package_urls(self) -> None:
        for url in (
            "http://github.com/example/quiz-system/releases/download/v1.0.1/a.zip",
            "https://evil.example/example/quiz-system/releases/download/v1.0.1/a.zip",
            "https://github.com/attacker/other/releases/download/v1.0.1/a.zip",
            "https://user@github.com/example/quiz-system/releases/download/v1.0.1/a.zip",
            "https://github.com:443/example/quiz-system/releases/download/v1.0.1/a.zip",
            "https://github.com/example/quiz-system/releases/download/v1.0.1/../a.zip",
        ):
            manifest = self.valid_manifest()
            manifest["package_url"] = url
            with self.subTest(url=url), self.assertRaises(ManifestError):
                self.parse(manifest)

    def test_rejects_invalid_sizes_schema_and_digests(self) -> None:
        for field, value in (
            ("package_size", 0),
            ("package_size", True),
            ("required_schema_version", 0),
            ("required_schema_version", True),
            ("package_sha256", "x" * 64),
            ("requirements_sha256", "a" * 63),
        ):
            manifest = self.valid_manifest()
            manifest[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ManifestError):
                self.parse(manifest)

    def test_rejects_duplicate_json_keys(self) -> None:
        raw = b'{"version":"1.0.1","version":"9.9.9"}'
        with self.assertRaises(ManifestError):
            UpdateManifest.from_bytes(raw, self.repository, self.tag)


if __name__ == "__main__":
    unittest.main()
