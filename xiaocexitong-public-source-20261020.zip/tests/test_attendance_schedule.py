import unittest
from app.attendance_schedule import expand_schedule, single_occurrence
from app.attendance_state import attendance_window_state


class AttendanceScheduleTest(unittest.TestCase):
    def test_odd_weeks_skip_and_shanghai_time(self):
        rows=expand_schedule(start_date='2026-10-19',end_date='2026-11-08',week1_monday='2026-10-19',slots=[dict(weekday=1,start='09:40',end='09:50',late_minutes=5)],weeks=[1,3],skip_dates=['2026-11-03'])
        self.assertEqual(['2026-10-20'],[r['class_date'] for r in rows])
        self.assertEqual(600,rows[0]['ends_at']-rows[0]['starts_at'])
        import datetime
        self.assertEqual(1,datetime.datetime.fromtimestamp(rows[0]['starts_at'],datetime.timezone.utc).hour)

    def test_windows_and_disabled_late(self):
        self.assertEqual(['scheduled','open_normal','open_late','ended'],[attendance_window_state(now=n,starts_at=100,late_after=130,ends_at=200) for n in (99,100,130,200)])
        self.assertEqual('open_normal',attendance_window_state(now=130,starts_at=100,late_after=130,ends_at=200,late_enabled=False))
        self.assertEqual('disabled',attendance_window_state(now=130,starts_at=100,late_after=130,ends_at=200,disabled=True))

    def test_validation_and_cross_year(self):
        args=dict(start_date='2026-12-28',end_date='2027-01-10',week1_monday='2026-12-28',slots=[dict(weekday=0,start='09:00',end='10:00',late_minutes=None)],weeks=None,skip_dates=[])
        self.assertEqual(['2026-12-28','2027-01-04'],[r['class_date'] for r in expand_schedule(**args)])
        for patch in (dict(week1_monday='2026-12-29'),dict(end_date='2028-01-10'),dict(weeks=[0]),dict(weeks=[54]),dict(slots=args['slots']*2)):
            with self.assertRaises(ValueError): expand_schedule(**(args|patch))
        for start,end,late in [('10:00','09:00',2),('9:00','10:00',2),('09:00','10:00',61),('23:00','01:00',None)]:
            with self.assertRaises(ValueError): single_occurrence('2026-10-18',start,end,late)

    def test_even_weeks_distinct_weekday_times_and_before_first_week(self):
        rows=expand_schedule(start_date='2026-10-17',end_date='2026-11-01',week1_monday='2026-10-19',slots=[dict(weekday=0,start='08:00',end='08:10',late_minutes=0),dict(weekday=2,start='14:00',end='14:20',late_minutes=None)],weeks=[2],skip_dates=[])
        self.assertEqual(['2026-10-26','2026-10-28'],[r['class_date'] for r in rows])
        self.assertEqual([600,1200],[r['ends_at']-r['starts_at'] for r in rows])
