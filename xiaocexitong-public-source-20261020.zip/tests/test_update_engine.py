import hashlib
import json
import shutil
import sqlite3
import tempfile
import threading
import time
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace

from updater.engine import UpdateEngine, read_active_version, write_active_version
from updater.manifest import UpdateManifest
from updater.release_client import UpdateCandidate


def file_hashes(root):
    root = Path(root)
    return {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


class FakeProcessManager:
    def __init__(self, fail_new_start=False):
        self.running_version = "1.0.0"
        self.health_token = "synthetic-health-token"
        self.fail_new_start = fail_new_start
        self.stop_calls = 0
        self.start_calls = []

    @property
    def pid(self):
        return 9001 if self.running_version else None

    def stop(self, timeout_seconds=30):
        self.stop_calls += 1
        self.running_version = None

    def start(self, version_dir):
        version = (Path(version_dir) / "VERSION").read_text(encoding="ascii").strip()
        self.start_calls.append(version)
        if version == "1.1.0" and self.fail_new_start:
            raise RuntimeError("synthetic new version startup failure")
        self.running_version = version
        self.health_token = f"health-{version}"


class FakeReleaseClient:
    def __init__(self, candidate, package_path, *, failure=None, entered=None, release_download=None):
        self.candidate = candidate
        self.package_path = Path(package_path)
        self.failure = failure
        self.entered = entered
        self.release_download = release_download
        self.download_calls = 0

    def latest(self, current_version):
        if self.failure == "latest":
            raise RuntimeError("synthetic signed release failure")
        if current_version == "1.0.0":
            return self.candidate
        return None

    def download(self, candidate, destination):
        self.download_calls += 1
        if self.entered:
            self.entered.set()
        if self.release_download:
            self.release_download.wait(3)
        if self.failure == "download":
            raise RuntimeError("synthetic download interruption")
        shutil.copyfile(self.package_path, destination)


class UpdateEngineTests(unittest.TestCase):
    requirements = b"flask==3.1.0\n"

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.root = Path(self.temp.name)
        self.project = self.root / "project"
        self.data = self.project / "instance"
        self.assistant = self.root / "ProgramData" / "ProbabilityQuizUpdater"
        self.versions = self.assistant / "versions"
        self.work = self.assistant / "work"
        self.old_version = self.versions / "1.0.0"
        self.project.mkdir()
        self.data.mkdir(parents=True)
        self.old_version.mkdir(parents=True)
        self.work.mkdir(parents=True)
        self._program_files(self.old_version, "1.0.0", self.requirements)
        self.secret = self.project / "secret_key.txt"
        self.secret.write_text("synthetic-secret-key", encoding="utf-8")
        self._create_synthetic_data()
        write_active_version(self.work, {"version": "1.0.0", "required_schema_version": 5})
        self.package_path = self.root / "quiz-program-v1.1.0.zip"
        self.package_bytes = self._create_package(self.package_path, "1.1.0", self.requirements)
        self.candidate = UpdateCandidate(self._manifest(self.package_bytes, self.requirements))
        self.config = SimpleNamespace(
            program_root=self.project,
            data_root=self.data,
            versions_root=self.versions,
            work_root=self.work,
            assistant_root=self.assistant,
            backup_root=self.assistant / "backups",
            backup_retention=5,
            health_url="http://127.0.0.1:5000/quiz/__updater_health",
        )
        self.process_manager = FakeProcessManager()
        self.release_client = FakeReleaseClient(self.candidate, self.package_path)
        self.engine = self._engine()
        self.data_before = file_hashes(self.data)
        self.secret_before = hashlib.sha256(self.secret.read_bytes()).hexdigest()

    def tearDown(self):
        self.temp.cleanup()

    def _program_files(self, root, version, requirements):
        (root / "app").mkdir(exist_ok=True)
        (root / "scripts").mkdir(exist_ok=True)
        (root / "app" / "__init__.py").write_text("# synthetic app\n", encoding="utf-8")
        (root / "scripts" / "start_server.py").write_text("# synthetic entry\n", encoding="utf-8")
        (root / "run.py").write_text("# run\n", encoding="utf-8")
        (root / "wsgi.py").write_text("# wsgi\n", encoding="utf-8")
        (root / "requirements.txt").write_bytes(requirements)
        (root / "VERSION").write_text(version + "\n", encoding="ascii")

    def _create_package(self, path, version, requirements):
        source = self.root / f"source-{version}"
        shutil.rmtree(source, ignore_errors=True)
        source.mkdir()
        self._program_files(source, version, requirements)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            for item in sorted(source.rglob("*")):
                if item.is_file():
                    archive.write(item, item.relative_to(source).as_posix())
        return path.read_bytes()

    def _manifest(self, package, requirements):
        return UpdateManifest(
            version="1.1.0",
            compatible_min="1.0.0",
            compatible_max="1.0.9",
            notes="synthetic release",
            tag="v1.1.0",
            repository="school/probability-quiz",
            package_url="https://github.com/school/probability-quiz/releases/download/v1.1.0/quiz-program-v1.1.0.zip",
            package_size=len(package),
            package_sha256=hashlib.sha256(package).hexdigest(),
            requirements_sha256=hashlib.sha256(requirements).hexdigest(),
            required_schema_version=5,
            key_id="release-2026",
        )

    def _create_synthetic_data(self):
        database = sqlite3.connect(self.data / "quiz.sqlite3")
        database.execute("CREATE TABLE users(username TEXT PRIMARY KEY, role TEXT)")
        database.execute("INSERT INTO users VALUES('synthetic-teacher','teacher')")
        database.execute("INSERT INTO users VALUES('synthetic-student','student')")
        database.commit()
        database.close()
        (self.data / "uploads").mkdir()
        (self.data / "uploads" / "student.png").write_bytes(b"synthetic-png-data")
        (self.data / "pending").mkdir()
        (self.data / "pending" / "batch.json").write_text('{"fixture":true}', encoding="utf-8")

    def _health_probe(self, _url, _token, _timeout):
        version = self.process_manager.running_version
        if not version:
            raise RuntimeError("site is stopped")
        return {"version": version, "database_ok": True, "schema_version": 5}

    def _engine(self, *, health_probe=None, disk_usage=None, health_timeout=0.05, sleep=lambda _delay: time.sleep(0.001)):
        kwargs = {"health_probe": health_probe or self._health_probe, "health_timeout_seconds": health_timeout, "health_poll_interval": 0.001, "sleep": sleep}
        if disk_usage is not None:
            kwargs["disk_usage"] = disk_usage
        return UpdateEngine(self.config, self.process_manager, self.release_client, **kwargs)

    def test_successful_update_changes_program_pointer_and_preserves_all_data(self):
        result = self.engine.install()
        self.assertEqual(result.phase, "succeeded")
        self.assertEqual(read_active_version(self.work)["version"], "1.1.0")
        self.assertEqual(file_hashes(self.data), self.data_before)
        self.assertEqual(hashlib.sha256(self.secret.read_bytes()).hexdigest(), self.secret_before)
        backups = list((self.assistant / "backups").glob("backup-*"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(json.loads((backups[0] / "result.json").read_text(encoding="utf-8"))["status"], "succeeded")
        self.assertEqual(file_hashes(backups[0] / "data"), self.data_before)

    def _assert_preflight_failure(self):
        result = self.engine.install()
        self.assertEqual(result.phase, "failed")
        self.assertEqual(self.process_manager.stop_calls, 0)
        self.assertEqual(read_active_version(self.work)["version"], "1.0.0")
        self.assertEqual(file_hashes(self.data), self.data_before)
        self.assertEqual(self.process_manager.running_version, "1.0.0")

    def test_download_failure_does_not_stop_site_or_touch_data(self):
        self.release_client.failure = "download"
        self._assert_preflight_failure()

    def test_dependency_change_does_not_stop_site_or_touch_data(self):
        changed = b"flask==9.9.9\n"
        self.package_bytes = self._create_package(self.package_path, "1.1.0", changed)
        self.release_client.package_path = self.package_path
        self.release_client.candidate = UpdateCandidate(self._manifest(self.package_bytes, changed))
        self.engine = self._engine()
        self._assert_preflight_failure()

    def test_insufficient_disk_space_does_not_stop_site_or_touch_data(self):
        self.engine = self._engine(disk_usage=lambda _path: SimpleNamespace(free=0))
        self._assert_preflight_failure()

    def test_new_version_startup_failure_restores_old_program_and_data(self):
        self.process_manager.fail_new_start = True
        result = self.engine.install()
        self.assertEqual(result.phase, "recovered")
        self.assertEqual(read_active_version(self.work)["version"], "1.0.0")
        self.assertEqual(self.process_manager.running_version, "1.0.0")
        self.assertEqual(file_hashes(self.data), self.data_before)
        backups = list((self.assistant / "backups").glob("backup-*"))
        self.assertEqual(json.loads((backups[0] / "result.json").read_text(encoding="utf-8"))["status"], "failed")

    def test_health_check_failure_rolls_back_and_keeps_failed_backup(self):
        def unhealthy_new(url, token, timeout):
            version = self.process_manager.running_version
            return {"version": version, "database_ok": version == "1.0.0", "schema_version": 5}

        self.engine = self._engine(health_probe=unhealthy_new, health_timeout=0.015)
        result = self.engine.install()
        self.assertEqual(result.phase, "recovered")
        self.assertEqual(read_active_version(self.work)["version"], "1.0.0")
        self.assertEqual(file_hashes(self.data), self.data_before)
        self.assertTrue(list((self.assistant / "backups").glob("backup-*")))

    def test_parallel_install_attempt_does_not_start_second_download(self):
        entered = threading.Event()
        release = threading.Event()
        self.release_client = FakeReleaseClient(self.candidate, self.package_path, entered=entered, release_download=release)
        self.engine = self._engine()
        results = []
        first = threading.Thread(target=lambda: results.append(self.engine.install()))
        first.start()
        self.assertTrue(entered.wait(2))
        second = self.engine.install()
        self.assertEqual(second.phase, "downloading")
        release.set()
        first.join(timeout=3)
        self.assertFalse(first.is_alive())
        self.assertEqual(self.release_client.download_calls, 1)
        self.assertEqual(results[0].phase, "succeeded")


if __name__ == "__main__":
    unittest.main()
