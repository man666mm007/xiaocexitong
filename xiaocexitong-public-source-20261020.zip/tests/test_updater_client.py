import json
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest import mock

from app.updater_client import UpdaterClient, UpdaterClientError


class FakeResponse:
    status = 200

    def __init__(self, value):
        self.value = value

    def read(self, _size=-1):
        return json.dumps(self.value).encode("utf-8")

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


class UpdaterClientTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.root = Path(self.temp.name)
        self.token = self.root / "agent.token"
        self.token.write_text("synthetic-agent-token", encoding="utf-8")
        self.client = UpdaterClient("http://127.0.0.1:58121", self.token)

    def tearDown(self):
        self.temp.cleanup()

    def test_only_fixed_loopback_paths_and_empty_post_body_are_used(self):
        requests = []

        def fake_urlopen(request, timeout):
            requests.append((request, timeout))
            return FakeResponse({"accepted": True})

        with mock.patch("app.updater_client.urllib.request.urlopen", side_effect=fake_urlopen):
            self.client.status()
            self.client.check()
            self.client.install()
        self.assertEqual([request.full_url for request, _ in requests], [
            "http://127.0.0.1:58121/v1/status",
            "http://127.0.0.1:58121/v1/check",
            "http://127.0.0.1:58121/v1/install",
        ])
        self.assertEqual([request.get_method() for request, _ in requests], ["GET", "POST", "POST"])
        self.assertIsNone(requests[0][0].data)
        self.assertEqual(requests[1][0].data, b"{}")
        self.assertEqual(requests[2][0].data, b"{}")
        for request, timeout in requests:
            headers = {key.lower(): value for key, value in request.header_items()}
            self.assertEqual(headers["authorization"], "Bearer synthetic-agent-token")
            self.assertEqual(timeout, 5)

    def test_rejects_non_loopback_or_dynamic_agent_address(self):
        for url in (
            "https://127.0.0.1:58121",
            "http://example.com:58121",
            "http://127.0.0.1:58121/other",
        ):
            with self.subTest(url=url), self.assertRaises(ValueError):
                UpdaterClient(url, self.token)
        with self.assertRaises(TypeError):
            self.client.install("C:\\Windows", "powershell")

    def test_maps_agent_errors_without_exposing_headers_or_paths(self):
        with mock.patch(
            "app.updater_client.urllib.request.urlopen",
            side_effect=urllib.error.HTTPError("url", 401, "bad", {"Authorization": "secret"}, None),
        ):
            with self.assertRaisesRegex(UpdaterClientError, "配置错误"):
                self.client.status()
        with mock.patch("app.updater_client.urllib.request.urlopen", side_effect=ConnectionError("secret path")):
            with self.assertRaisesRegex(UpdaterClientError, "未安装或未运行") as raised:
                self.client.status()
            self.assertNotIn("secret path", str(raised.exception))

    def test_missing_token_file_maps_to_admin_install_message(self):
        client = UpdaterClient("http://127.0.0.1:58121", self.root / "missing.token")
        with self.assertRaisesRegex(UpdaterClientError, "联系管理员"):
            client.install()


if __name__ == "__main__":
    unittest.main()
