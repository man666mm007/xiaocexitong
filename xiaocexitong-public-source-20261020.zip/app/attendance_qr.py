"""动态签到二维码的令牌生成与校验。

令牌 = HMAC-SHA256(该场签到的随机密钥, "场次ID:时间窗口")，服务端不需要保存历史令牌：
老师端每 WINDOW_SECONDS 秒刷新一次二维码，服务端只接受当前窗口的令牌。
"""

import base64
import hashlib
import hmac
import time

WINDOW_SECONDS = 20
TOKEN_LENGTH = 16


def _token_for_counter(secret, session_id, counter):
    digest = hmac.new(
        str(secret).encode("utf-8"),
        f"{session_id}:{counter}".encode("utf-8"),
        hashlib.sha256,
    ).digest()
    return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")[:TOKEN_LENGTH]


def make_token(secret, session_id, moment=None):
    """生成当前时间窗口的令牌。"""
    timestamp = int(time.time() if moment is None else moment)
    return _token_for_counter(secret, session_id, timestamp // WINDOW_SECONDS)


def verify_token(secret, session_id, token, moment=None):
    """只校验当前 20 秒时间窗口的令牌。"""
    if not secret or not token:
        return False
    current = int(time.time() if moment is None else moment) // WINDOW_SECONDS
    expected = _token_for_counter(secret, session_id, current)
    return hmac.compare_digest(expected, str(token))


def seconds_left(moment=None):
    """当前窗口还剩多少秒（用于前端倒计时）。"""
    timestamp = int(time.time() if moment is None else moment)
    return WINDOW_SECONDS - (timestamp % WINDOW_SECONDS)
