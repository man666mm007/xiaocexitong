"""Single server clock, time-window policy and teacher overrides."""
import time
from flask import current_app


def server_now():
    clock = current_app.config.get('ATTENDANCE_CLOCK')
    return int(clock() if clock else time.time())


def effective_attendance(raw_status, adjustment_status):
    return adjustment_status if adjustment_status is not None else (raw_status or 'absent')


def attendance_window_state(*, now, starts_at, late_after, ends_at, disabled=False, late_enabled=True):
    if disabled: return 'disabled'
    if now < starts_at: return 'scheduled'
    if now >= ends_at: return 'ended'
    return 'open_late' if late_enabled and now >= late_after else 'open_normal'


def session_state(database, item, now=None):
    item = dict(item)
    cls = database.execute('SELECT archived_at FROM teaching_classes WHERE id=?',(item['class_id'],)).fetchone()
    room = database.execute('SELECT state,needs_review FROM classroom_sessions WHERE attendance_session_id=?',(item['id'],)).fetchone()
    disabled = not item['active'] or item.get('archived_batch') is not None or item.get('cancelled_at') is not None or item.get('closed_at') is not None or cls is None or cls['archived_at'] is not None or bool(room and (room['state']!='ready' or room['needs_review']))
    return attendance_window_state(now=server_now() if now is None else now,starts_at=item['starts_at'],late_after=item['late_after'],ends_at=item['ends_at'],disabled=disabled,late_enabled=bool(item.get('late_enabled',1)))


def adjust_attendance(database, *, session_id, student_id, status, reason, expected_version, actor_id, now):
    if status not in ('normal','late','absent') or not reason.strip() or len(reason)>1000:
        raise ValueError('请选择有效状态并填写原因（最多1000字）')
    actor = database.execute("SELECT name FROM users WHERE id=? AND role IN ('teacher','admin') AND active=1 AND archived_at IS NULL",(actor_id,)).fetchone()
    if not actor: raise ValueError('无管理权限')
    membership = database.execute("SELECT 1 FROM attendance_sessions a JOIN student_classes sc ON sc.class_id=a.class_id JOIN users u ON u.id=sc.student_id WHERE a.id=? AND u.id=? AND u.role='student'",(session_id,student_id)).fetchone()
    if not membership: raise ValueError('学生与教学班不匹配')
    old = database.execute('SELECT * FROM attendance_adjustments WHERE session_id=? AND student_id=?',(session_id,student_id)).fetchone()
    raw = database.execute('SELECT status FROM attendance_records WHERE session_id=? AND student_id=?',(session_id,student_id)).fetchone()
    version = old['version'] if old else 0
    if expected_version != version: raise ValueError('版本冲突，请刷新后重新操作')
    before = effective_attendance(raw['status'] if raw else None,old['status'] if old else None)
    if old:
        changed = database.execute('UPDATE attendance_adjustments SET status=?,version=version+1,changed_by=?,changed_at=?,reason=? WHERE id=? AND version=?',(status,actor_id,now,reason.strip(),old['id'],version))
        if changed.rowcount!=1: raise ValueError('版本冲突，请刷新后重新操作')
    else:
        database.execute('INSERT INTO attendance_adjustments(session_id,student_id,status,version,changed_by,changed_at,reason) VALUES(?,?,?,1,?,?,?)',(session_id,student_id,status,actor_id,now,reason.strip()))
    database.execute('INSERT INTO attendance_adjustment_events(session_id,student_id,actor_id,actor_name,changed_at,before_status,after_status,version,reason) VALUES(?,?,?,?,?,?,?,?,?)',(session_id,student_id,actor_id,actor['name'],now,before,status,version+1,reason.strip()))
    return dict(status=status,version=version+1,changed_at=now)
