from datetime import timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


try:
    SHANGHAI_TIMEZONE = ZoneInfo("Asia/Shanghai")
except ZoneInfoNotFoundError:
    # Windows may not have an IANA timezone database; Shanghai currently uses UTC+8.
    SHANGHAI_TIMEZONE = timezone(timedelta(hours=8))
