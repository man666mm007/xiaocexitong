import re
import sqlite3

import click
from flask import current_app, g


MIGRATION_VERSION = 5
LEGACY_CLASS_RE = re.compile(r"^(\d{2})-(\d{2})(春|秋)(.+?)(\d+)班$")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"], timeout=15)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
        g.db.execute("PRAGMA busy_timeout = 15000")
    return g.db


def close_db(_error=None):
    database = g.pop("db", None)
    if database is not None:
        database.close()


def _execute_script_in_transaction(database, script):
    statement = ""
    for line in script.splitlines():
        statement += line + "\n"
        if sqlite3.complete_statement(statement):
            sql = statement.strip()
            if sql:
                database.execute(sql)
            statement = ""
    if statement.strip():
        raise sqlite3.OperationalError("database schema contains an incomplete SQL statement")


def init_db():
    database = get_db()
    with current_app.open_resource("schema.sql") as schema:
        _execute_script_in_transaction(database, schema.read().decode("utf-8-sig"))
    database.execute(
        "INSERT OR IGNORE INTO schema_migrations(version) VALUES(?)",
        (MIGRATION_VERSION,),
    )
    database.execute("INSERT OR IGNORE INTO schema_migrations(version) VALUES(2)")
    database.execute("INSERT OR IGNORE INTO schema_migrations(version) VALUES(3)")
    database.execute("INSERT OR IGNORE INTO schema_migrations(version) VALUES(4)")
    database.commit()


def _columns(database, table):
    return {row["name"] for row in database.execute(f"PRAGMA table_info({table})").fetchall()}


def _ensure_column(database, table, name, declaration):
    if name in _columns(database, table):
        return
    if database.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone():
        database.execute(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")


def _quiz_score_constraint_needs_rebuild(database):
    row = database.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='quizzes'"
    ).fetchone()
    return bool(row and re.search(r"\btotal_score\s+REAL\s+NOT\s+NULL\b", row["sql"] or "", re.I))


def _rebuild_quiz_total_score_nullable(database):
    """Allow an unpublished negative-marking quiz draft to await its first import."""
    if not _quiz_score_constraint_needs_rebuild(database):
        return False

    columns = [row["name"] for row in database.execute("PRAGMA table_info(quizzes)").fetchall()]
    sequence_row = database.execute(
        "SELECT seq FROM sqlite_sequence WHERE name='quizzes'"
    ).fetchone()
    old_sequence = sequence_row["seq"] if sequence_row else 0
    database.execute(
        """
        CREATE TABLE quizzes_replacement (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quiz_date TEXT NOT NULL,
            class_name TEXT NOT NULL,
            class_id INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL,
            total_score REAL CHECK (
                (total_score IS NOT NULL AND total_score > 0) OR
                (total_score IS NULL AND scoring_mode='negative_marking' AND published=0)
            ),
            scoring_mode TEXT NOT NULL DEFAULT 'legacy' CHECK (scoring_mode IN ('legacy','negative_marking')),
            published INTEGER NOT NULL DEFAULT 0,
            results_confirmed_at INTEGER,
            archived_batch TEXT,
            created_by INTEGER NOT NULL REFERENCES users(id),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    quoted = ",".join('"' + name.replace('"', '""') + '"' for name in columns)
    database.execute(
        f"INSERT INTO quizzes_replacement ({quoted}) SELECT {quoted} FROM quizzes"
    )
    database.execute("DROP TABLE quizzes")
    database.execute("ALTER TABLE quizzes_replacement RENAME TO quizzes")
    max_id = database.execute("SELECT COALESCE(MAX(id), 0) AS id FROM quizzes").fetchone()["id"]
    sequence = max(old_sequence, max_id)
    database.execute("DELETE FROM sqlite_sequence WHERE name IN ('quizzes','quizzes_replacement')")
    database.execute("INSERT INTO sqlite_sequence(name,seq) VALUES('quizzes',?)", (sequence,))
    return True


def _rebuild_class_trash_without_name_identity(database):
    row = database.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='class_trash'"
    ).fetchone()
    if not row or not re.search(r"class_name\s+TEXT\s+NOT\s+NULL\s+UNIQUE", row["sql"] or "", re.I):
        return
    database.execute("ALTER TABLE class_trash RENAME TO class_trash_legacy")
    database.execute(
        "CREATE TABLE class_trash (id TEXT PRIMARY KEY,class_name TEXT NOT NULL,"
        "deleted_at INTEGER NOT NULL,purge_after INTEGER NOT NULL,"
        "class_id INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL)"
    )
    database.execute(
        "INSERT INTO class_trash(id,class_name,deleted_at,purge_after) "
        "SELECT id,class_name,deleted_at,purge_after FROM class_trash_legacy"
    )
    database.execute("DROP TABLE class_trash_legacy")


def _metadata_for_legacy_name(name):
    match = LEGACY_CLASS_RE.fullmatch(name)
    if not match:
        return None, None, None, None
    start, end, term, course, section = match.groups()
    if (int(start) + 1) % 100 != int(end) or not course.strip():
        return None, None, None, None
    return f"{start}-{end}", term, course.strip(), int(section)


def _backfill_legacy_classes(database):
    names = set()
    for table in ("users", "quizzes", "attendance_sessions", "class_trash", "record_trash"):
        if "class_name" in _columns(database, table):
            names.update(
                row["class_name"].strip()
                for row in database.execute(
                    f"SELECT DISTINCT class_name FROM {table} WHERE class_name IS NOT NULL AND trim(class_name)<>''"
                ).fetchall()
            )

    ids = {}
    for name in sorted(names):
        existing = database.execute(
            "SELECT id FROM teaching_classes WHERE display_name=? ORDER BY id LIMIT 1", (name,)
        ).fetchone()
        if existing:
            ids[name] = existing["id"]
            continue
        school_year, term, course, section = _metadata_for_legacy_name(name)
        cursor = database.execute(
            """
            INSERT INTO teaching_classes(school_year,term,course_name,section_no,display_name,legacy_name)
            VALUES(?,?,?,?,?,?)
            """,
            (school_year, term, course, section, name, name),
        )
        ids[name] = cursor.lastrowid

    def class_id(name):
        if not name:
            return None
        if name not in ids:
            row = database.execute(
                "SELECT id FROM teaching_classes WHERE display_name=? ORDER BY id LIMIT 1", (name,)
            ).fetchone()
            if row is None:
                return None
            ids[name] = row["id"]
        return ids[name]

    for row in database.execute("SELECT id,class_name FROM quizzes").fetchall():
        database.execute(
            "UPDATE quizzes SET class_id=? WHERE id=? AND class_id IS NULL",
            (class_id(row["class_name"]), row["id"]),
        )
    for row in database.execute("SELECT id,class_name FROM attendance_sessions").fetchall():
        database.execute(
            "UPDATE attendance_sessions SET class_id=? WHERE id=? AND class_id IS NULL",
            (class_id(row["class_name"]), row["id"]),
        )
    for row in database.execute("SELECT id,class_name FROM record_trash").fetchall():
        database.execute(
            "UPDATE record_trash SET class_id=? WHERE id=? AND class_id IS NULL",
            (class_id(row["class_name"]), row["id"]),
        )

    for row in database.execute("SELECT id,class_name FROM class_trash").fetchall():
        mapped = class_id(row["class_name"])
        if mapped is None:
            continue
        batch = database.execute(
            "SELECT deleted_at,purge_after FROM class_trash WHERE id=?", (row["id"],)
        ).fetchone()
        database.execute(
            "UPDATE class_trash SET class_id=? WHERE id=?", (mapped, row["id"])
        )
        database.execute(
            "UPDATE teaching_classes SET archived_at=?,purge_after=?,archived_batch=? WHERE id=?",
            (batch["deleted_at"], batch["purge_after"], row["id"], mapped),
        )

    # Old whole-class archives incorrectly archived shared student accounts.
    # Restore those accounts and retain the archived class state on teaching_classes.
    database.execute(
        "UPDATE users SET archived_at=NULL,purge_after=NULL,archived_batch=NULL "
        "WHERE role='student' AND archived_batch IS NOT NULL"
    )

    for row in database.execute(
        "SELECT id,class_name FROM users WHERE role='student' AND class_name IS NOT NULL AND trim(class_name)<>''"
    ).fetchall():
        mapped = class_id(row["class_name"])
        if mapped is not None:
            database.execute(
                "INSERT OR IGNORE INTO student_classes(student_id,class_id,status) VALUES(?,?,'active')",
                (row["id"], mapped),
            )

    # Scores and attendance records are authoritative evidence for historical memberships,
    # including classes different from the student's current legacy class_name.
    history = database.execute(
        """
        SELECT DISTINCT s.student_id,q.class_id,
               CASE WHEN u.class_name=q.class_name THEN 'active' ELSE 'removed' END AS status
        FROM scores s JOIN quizzes q ON q.id=s.quiz_id
        JOIN users u ON u.id=s.student_id
        WHERE u.role='student' AND q.class_id IS NOT NULL
        UNION
        SELECT DISTINCT r.student_id,a.class_id,
               CASE WHEN u.class_name=a.class_name THEN 'active' ELSE 'removed' END AS status
        FROM attendance_records r JOIN attendance_sessions a ON a.id=r.session_id
        JOIN users u ON u.id=r.student_id
        WHERE u.role='student' AND a.class_id IS NOT NULL
        """
    ).fetchall()
    for row in history:
        database.execute(
            "INSERT OR IGNORE INTO student_classes(student_id,class_id,status) VALUES(?,?,?)",
            (row["student_id"], row["class_id"], row["status"]),
        )
        if row["status"] == "active":
            database.execute(
                "UPDATE student_classes SET status='active',removed_at=NULL WHERE student_id=? AND class_id=?",
                (row["student_id"], row["class_id"]),
            )


def migrate_db():
    """Apply repeatable, transactional SQLite migrations and preserve legacy class history."""
    database = get_db()
    has_users = database.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='users'"
    ).fetchone()
    if not has_users:
        init_db()
        return

    rebuild_quizzes = _quiz_score_constraint_needs_rebuild(database)
    if rebuild_quizzes:
        if database.in_transaction:
            raise sqlite3.OperationalError("quiz schema migration requires a clean transaction")
        database.execute("PRAGMA foreign_keys = OFF")
    try:
        database.execute("BEGIN IMMEDIATE")
        # Older installs may lack columns introduced without a migration marker.
        for name, declaration in (
            ("archived_at", "INTEGER"),
            ("purge_after", "INTEGER"),
            ("archived_batch", "TEXT"),
            ("administrative_class", "TEXT"),
            ("gender", "TEXT"),
            ("study_type", "TEXT"),
            ("minor_mark", "TEXT"),
            ("roster_notes", "TEXT"),
        ):
            _ensure_column(database, "users", name, declaration)
        _ensure_column(database, "quizzes", "archived_batch", "TEXT")
        _ensure_column(database, "quizzes", "class_id", "INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL")
        _ensure_column(database, "quizzes", "scoring_mode", "TEXT NOT NULL DEFAULT 'legacy'")
        _rebuild_quiz_total_score_nullable(database)
        # class_trash is rebuilt below with a foreign key to this table; create
        # the referenced table first so SQLite can copy the legacy rows.
        database.execute(
            "CREATE TABLE IF NOT EXISTS teaching_classes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,school_year TEXT,"
            "term TEXT CHECK (term IS NULL OR term IN ('春','秋')),course_name TEXT,"
            "section_no INTEGER CHECK (section_no IS NULL OR section_no > 0),"
            "display_name TEXT NOT NULL,legacy_name TEXT,archived_at INTEGER,"
            "purge_after INTEGER,archived_batch TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        _rebuild_class_trash_without_name_identity(database)
        _ensure_column(database, "class_trash", "class_id", "INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL")
        _ensure_column(database, "record_trash", "class_id", "INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL")
        _ensure_column(database, "attendance_sessions", "qr_secret", "TEXT")
        _ensure_column(database, "attendance_sessions", "archived_batch", "TEXT")
        _ensure_column(database, "attendance_sessions", "class_id", "INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL")
        _ensure_column(database, "attendance_records", "source", "TEXT NOT NULL DEFAULT 'manual'")
        _ensure_column(database, "answer_details", "answer_status", "TEXT NOT NULL DEFAULT 'wrong'")

        _ensure_column(database, "quizzes", "results_confirmed_at", "INTEGER")
        for name, declaration in (
            ("attendance_date", "TEXT"),
            ("schedule_rule_id", "INTEGER REFERENCES attendance_schedule_rules(id) ON DELETE SET NULL"),
            ("schedule_revision", "INTEGER"),
            ("schedule_origin_date", "TEXT"),
            ("is_exception", "INTEGER NOT NULL DEFAULT 0 CHECK(is_exception IN (0,1))"),
            ("cancelled_at", "INTEGER"), ("closed_at", "INTEGER"),
            ("late_enabled", "INTEGER NOT NULL DEFAULT 1 CHECK(late_enabled IN (0,1))"),
        ):
            _ensure_column(database, "attendance_sessions", name, declaration)
        batch_ddl = database.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='import_batches'").fetchone()
        if batch_ddl and "attendance_schedule" not in batch_ddl["sql"]:
            database.execute("ALTER TABLE import_batches RENAME TO import_batches_v2")
            database.execute("CREATE TABLE import_batches (id TEXT PRIMARY KEY,teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,kind TEXT NOT NULL CHECK(kind IN ('students','results','attendance_schedule')),payload TEXT NOT NULL,storage_dir TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
            database.execute("INSERT INTO import_batches SELECT * FROM import_batches_v2")
            database.execute("DROP TABLE import_batches_v2")

        with current_app.open_resource("schema.sql") as schema:
            _execute_script_in_transaction(database, schema.read().decode("utf-8-sig"))

        applied = database.execute(
            "SELECT 1 FROM schema_migrations WHERE version=?", (2,)
        ).fetchone()
        if not applied:
            _backfill_legacy_classes(database)
            database.execute(
                "INSERT INTO schema_migrations(version) VALUES(?)", (2,)
            )
        if not database.execute("SELECT 1 FROM schema_migrations WHERE version=3").fetchone():
            from .classroom import backfill_classrooms
            backfill_classrooms(database)
            if database.execute("PRAGMA foreign_key_check").fetchall():
                raise sqlite3.IntegrityError("foreign key violations during classroom migration")
            database.execute("INSERT INTO schema_migrations(version) VALUES(3)")
        if not database.execute("SELECT 1 FROM schema_migrations WHERE version=4").fetchone():
            from .classroom import repair_legacy_total_submissions
            repair_legacy_total_submissions(database)
            if database.execute("PRAGMA foreign_key_check").fetchall():
                raise sqlite3.IntegrityError("foreign key violations during submission repair")
            database.execute("INSERT INTO schema_migrations(version) VALUES(4)")
        if not database.execute("SELECT 1 FROM schema_migrations WHERE version=5").fetchone():
            database.execute("INSERT INTO schema_migrations(version) VALUES(5)")
        if rebuild_quizzes and database.execute("PRAGMA foreign_key_check").fetchall():
            raise sqlite3.IntegrityError("foreign key violations found while rebuilding quizzes")
        database.commit()
    except Exception:
        if database.in_transaction:
            database.rollback()
        raise
    finally:
        if rebuild_quizzes:
            database.execute("PRAGMA foreign_keys = ON")


@click.command("init-db")
def init_db_command():
    init_db()
    click.echo("数据库已初始化。")


def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)


