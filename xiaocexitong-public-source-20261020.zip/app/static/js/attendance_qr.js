/* Server time is authoritative; polling continues across scheduled start. */
(() => {
  const panel = document.getElementById('qrPanel');
  if (!panel || typeof QRCode === 'undefined') return;
  const el = id => document.getElementById(id);
  const target=el('qrTarget'), fallback=el('qrFallback'), stateEl=el('qrState');
  let qr=null, currentUrl='', data=null, receivedAt=0;
  const labels={scheduled:'待开始',open_normal:'进行中',open_late:'进行中',ended:'已结束',disabled:'已关闭／已取消'};
  function clear(message) {
    if (qr) qr.clear(); qr=null; currentUrl='';
    if (target) target.innerHTML='';
    if (fallback) {fallback.hidden=false; fallback.textContent=message;}
    if (el('qrUrl')) el('qrUrl').textContent='';
    panel.classList.add('qr-panel-closed');
  }
  function tick() {
    if (!data) return;
    const elapsed=(Date.now()-receivedAt)/1000;
    const now=data.server_now+elapsed;
    const seconds=data.state==='scheduled' ? Math.ceil(data.starts_at-now) : Math.ceil(Math.min(data.seconds_left-elapsed,data.ends_at-now));
    if (el('qrSeconds')) el('qrSeconds').textContent=Math.max(0,seconds);
    if (el('qrProgress')) el('qrProgress').style.width=`${Math.max(0,Math.min(100,seconds/data.window*100))}%`;
    if (data.open && seconds<=0) clear('正在向服务器确认最新二维码…');
    if (data.state==='scheduled' && fallback) fallback.textContent=`预约尚未开始，距开始约 ${Math.max(0,seconds)} 秒（北京时间）`;
  }
  async function refresh() {
    try {
      const response=await fetch(panel.dataset.endpoint,{cache:'no-store',credentials:'same-origin'});
      if (!response.ok) throw new Error('请求失败');
      data=await response.json(); receivedAt=Date.now();
      if (el('endAttendanceForm')) el('endAttendanceForm').hidden=!data.open;
      if (el('qrCountdownLabel')) el('qrCountdownLabel').textContent=data.state==='scheduled'?'秒后开始':'秒后自动刷新';
      if (stateEl) {stateEl.textContent=labels[data.state]||'待核查'; stateEl.className='badge '+(data.open?'success':'neutral');}
      if (el('qrSigned')) el('qrSigned').textContent=data.signed;
      if (el('qrTotal')) el('qrTotal').textContent=data.total;
      if (!data.open || !data.url) { clear(data.state==='scheduled'?'等待预约开始…':'签到已关闭，二维码已清除。'); tick(); return; }
      panel.classList.remove('qr-panel-closed');
      if (data.url!==currentUrl) {
        currentUrl=data.url;
        if (!qr) {target.innerHTML=''; qr=new QRCode(target,{text:data.url,width:260,height:260,colorDark:'#14213d',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.M});}
        else {qr.clear(); qr.makeCode(data.url);}
        if (fallback) fallback.hidden=true;
        if (el('qrUrl')) el('qrUrl').textContent=data.url;
      }
      tick();
    } catch (error) {data=null; clear('连接暂时中断，正在重试；请教师检查服务状态。'); if (el('qrSeconds')) el('qrSeconds').textContent='--';}
  }
  refresh(); setInterval(refresh,4000); setInterval(tick,1000);
})();
