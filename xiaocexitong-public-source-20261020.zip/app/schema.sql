PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('student', 'teacher', 'admin')),
    class_name TEXT,
    administrative_class TEXT,
    gender TEXT,
    study_type TEXT,
    minor_mark TEXT,
    roster_notes TEXT,
    must_change_password INTEGER NOT NULL DEFAULT 1,
    session_version INTEGER NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1,
    archived_at INTEGER,
    purge_after INTEGER,
    archived_batch TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 教学班是稳定实体；旧名称保留在 display_name/legacy_name 中。
CREATE TABLE IF NOT EXISTS teaching_classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_year TEXT,
    term TEXT CHECK (term IS NULL OR term IN ('春', '秋')),
    course_name TEXT,
    section_no INTEGER CHECK (section_no IS NULL OR section_no > 0),
    display_name TEXT NOT NULL,
    legacy_name TEXT,
    archived_at INTEGER,
    purge_after INTEGER,
    archived_batch TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_teaching_class_identity
    ON teaching_classes(school_year, term, course_name, section_no)
    WHERE school_year IS NOT NULL AND term IS NOT NULL AND course_name IS NOT NULL AND section_no IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_teaching_class_archive ON teaching_classes(archived_at, purge_after);

-- removed 关系保留历年关联；新成绩和签到只接受 active 关系。
CREATE TABLE IF NOT EXISTS student_classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    class_id INTEGER NOT NULL REFERENCES teaching_classes(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'removed')),
    added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    removed_at TEXT,
    UNIQUE (student_id, class_id)
);
CREATE INDEX IF NOT EXISTS idx_student_classes_class ON student_classes(class_id, status, student_id);
CREATE INDEX IF NOT EXISTS idx_student_classes_student ON student_classes(student_id, status, class_id);

CREATE TABLE IF NOT EXISTS quizzes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    quiz_date TEXT NOT NULL,
    class_name TEXT NOT NULL,
    class_id INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL,
    total_score REAL CHECK (
        (total_score IS NOT NULL AND total_score > 0) OR
        (total_score IS NULL AND scoring_mode='negative_marking' AND published=0)
    ),
    scoring_mode TEXT NOT NULL DEFAULT 'legacy' CHECK (scoring_mode IN ('legacy', 'negative_marking')),
    published INTEGER NOT NULL DEFAULT 0,
    results_confirmed_at INTEGER,
    archived_batch TEXT,
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score REAL NOT NULL,
    detail TEXT,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (quiz_id, student_id)
);

CREATE TABLE IF NOT EXISTS quiz_images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    score_id INTEGER NOT NULL REFERENCES scores(id) ON DELETE CASCADE,
    original_name TEXT NOT NULL,
    storage_name TEXT NOT NULL UNIQUE,
    mime_type TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 判断题的题干与正确答案：每道题一行，答案只记 T / F
CREATE TABLE IF NOT EXISTS quiz_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    number INTEGER NOT NULL,
    stem TEXT NOT NULL,
    answer TEXT NOT NULL CHECK (answer IN ('T', 'F')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (quiz_id, number)
);

-- 每名学生每道题的结果：is_correct 1 = 答对、0 = 答错或未答；
-- answer_status 区分 correct（答对）/ wrong（答错）/ blank（未作答）。
CREATE TABLE IF NOT EXISTS answer_details (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    score_id INTEGER NOT NULL REFERENCES scores(id) ON DELETE CASCADE,
    number INTEGER NOT NULL,
    is_correct INTEGER NOT NULL CHECK (is_correct IN (0, 1)),
    answer_status TEXT NOT NULL DEFAULT 'wrong',
    UNIQUE (score_id, number)
);

CREATE TABLE IF NOT EXISTS import_batches (
    id TEXT PRIMARY KEY,
    teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK (kind IN ('students', 'results', 'attendance_schedule')),
    payload TEXT NOT NULL,
    storage_dir TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS login_attempts (
    attempt_key TEXT PRIMARY KEY,
    failures INTEGER NOT NULL DEFAULT 0,
    blocked_until INTEGER NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL
);

-- 按上海自然日保存成功登录次数；累计次数由此表汇总。
CREATE TABLE IF NOT EXISTS login_daily_counts (
    login_date TEXT PRIMARY KEY,
    count INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0)
);

CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS class_trash (
    id TEXT PRIMARY KEY,
    class_name TEXT NOT NULL,
    deleted_at INTEGER NOT NULL,
    purge_after INTEGER NOT NULL,
    class_id INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL
);

-- 单条记录回收站：小测或签到保留 30 天后再清理。
CREATE TABLE IF NOT EXISTS record_trash (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL CHECK (kind IN ('quiz', 'attendance')),
    ref_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    class_name TEXT NOT NULL,
    class_id INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL,
    detail TEXT,
    deleted_at INTEGER NOT NULL,
    purge_after INTEGER NOT NULL,
    UNIQUE (kind, ref_id)
);

CREATE TABLE IF NOT EXISTS attendance_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    class_name TEXT NOT NULL,
    class_id INTEGER REFERENCES teaching_classes(id) ON DELETE SET NULL,
    code TEXT NOT NULL,
    qr_secret TEXT,
    attendance_date TEXT,
    schedule_rule_id INTEGER REFERENCES attendance_schedule_rules(id) ON DELETE SET NULL,
    schedule_revision INTEGER,
    schedule_origin_date TEXT,
    is_exception INTEGER NOT NULL DEFAULT 0 CHECK(is_exception IN (0,1)),
    cancelled_at INTEGER,
    closed_at INTEGER,
    late_enabled INTEGER NOT NULL DEFAULT 1 CHECK(late_enabled IN (0,1)),
    starts_at INTEGER NOT NULL,
    late_after INTEGER NOT NULL,
    ends_at INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    archived_batch TEXT,
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (starts_at <= late_after AND late_after <= ends_at)
);

CREATE TABLE IF NOT EXISTS attendance_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    signed_at INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('normal', 'late')),
    source TEXT NOT NULL DEFAULT 'manual',
    UNIQUE (session_id, student_id)
);

-- Legacy writers may still send class_name. Resolve it only to an existing class; this never creates one.
CREATE TRIGGER IF NOT EXISTS attach_quiz_to_existing_class
AFTER INSERT ON quizzes WHEN NEW.class_id IS NULL
BEGIN
    UPDATE quizzes SET class_id=(
        SELECT id FROM teaching_classes WHERE display_name=NEW.class_name AND archived_at IS NULL ORDER BY id LIMIT 1
    ) WHERE id=NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS attach_attendance_to_existing_class
AFTER INSERT ON attendance_sessions WHEN NEW.class_id IS NULL
BEGIN
    UPDATE attendance_sessions SET class_id=(
        SELECT id FROM teaching_classes WHERE display_name=NEW.class_name AND archived_at IS NULL ORDER BY id LIMIT 1
    ) WHERE id=NEW.id;
END;

CREATE INDEX IF NOT EXISTS idx_quizzes_class ON quizzes(class_name);
CREATE INDEX IF NOT EXISTS idx_quizzes_class_id ON quizzes(class_id, quiz_date);
CREATE INDEX IF NOT EXISTS idx_scores_student ON scores(student_id);
CREATE INDEX IF NOT EXISTS idx_images_score ON quiz_images(score_id);
CREATE INDEX IF NOT EXISTS idx_questions_quiz ON quiz_questions(quiz_id, number);
CREATE INDEX IF NOT EXISTS idx_answer_details_score ON answer_details(score_id, number);
CREATE INDEX IF NOT EXISTS idx_users_archive ON users(archived_at, purge_after);
CREATE INDEX IF NOT EXISTS idx_users_batch ON users(archived_batch);
CREATE INDEX IF NOT EXISTS idx_quizzes_batch ON quizzes(archived_batch);
CREATE INDEX IF NOT EXISTS idx_attendance_class ON attendance_sessions(class_name, starts_at);
CREATE INDEX IF NOT EXISTS idx_attendance_class_id ON attendance_sessions(class_id, starts_at);
CREATE INDEX IF NOT EXISTS idx_attendance_batch ON attendance_sessions(archived_batch);
CREATE INDEX IF NOT EXISTS idx_record_trash_purge ON record_trash(purge_after);
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance_records(student_id);

CREATE TABLE IF NOT EXISTS classroom_sessions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 class_id INTEGER NOT NULL REFERENCES teaching_classes(id) ON DELETE CASCADE,
 class_date TEXT NOT NULL,
 quiz_id INTEGER UNIQUE REFERENCES quizzes(id) ON DELETE SET NULL,
 attendance_session_id INTEGER UNIQUE REFERENCES attendance_sessions(id) ON DELETE SET NULL,
 state TEXT NOT NULL DEFAULT 'ready' CHECK(state IN ('ready','conflict','cancelled')),
 needs_review INTEGER NOT NULL DEFAULT 0 CHECK(needs_review IN (0,1)),
 review_note TEXT, version INTEGER NOT NULL DEFAULT 0,
 created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
 UNIQUE(class_id,class_date)
);
CREATE TABLE IF NOT EXISTS quiz_submissions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
 student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL CHECK(status IN ('submitted','unsubmitted')),
 source TEXT NOT NULL, import_batch_id TEXT, confirmed_at INTEGER NOT NULL,
 UNIQUE(quiz_id,student_id)
);
CREATE TABLE IF NOT EXISTS quiz_submission_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
 student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 actor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 actor_name TEXT NOT NULL, changed_at INTEGER NOT NULL,
 import_batch_id TEXT, before_json TEXT NOT NULL, after_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attendance_adjustments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
 student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 status TEXT NOT NULL CHECK(status IN ('normal','late','absent')),
 version INTEGER NOT NULL, changed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
 changed_at INTEGER NOT NULL, reason TEXT NOT NULL,
 UNIQUE(session_id,student_id)
);
CREATE TABLE IF NOT EXISTS attendance_adjustment_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 session_id INTEGER NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
 student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 actor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 actor_name TEXT NOT NULL, changed_at INTEGER NOT NULL,
 before_status TEXT NOT NULL, after_status TEXT NOT NULL, version INTEGER NOT NULL, reason TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attendance_schedule_rules (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 class_id INTEGER NOT NULL REFERENCES teaching_classes(id) ON DELETE CASCADE,
 start_date TEXT NOT NULL, end_date TEXT NOT NULL, week1_monday TEXT NOT NULL,
 slots_json TEXT NOT NULL, weeks_json TEXT NOT NULL, skip_dates_json TEXT NOT NULL,
 enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
 revision INTEGER NOT NULL DEFAULT 1,
 created_by INTEGER REFERENCES users(id) ON DELETE SET NULL, created_at INTEGER NOT NULL
);
