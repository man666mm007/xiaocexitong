"""Authenticated loopback readiness endpoint used only by the updater agent."""

from __future__ import annotations

import hmac
import os
import sqlite3
from pathlib import Path

from flask import Blueprint, current_app, jsonify, request


bp = Blueprint("updater_health", __name__)


@bp.get("/__updater_health")
def updater_health():
    original = request.environ.get("werkzeug.proxy_fix.orig", {})
    peer = original.get("REMOTE_ADDR") or request.environ.get("REMOTE_ADDR", "")
    if peer not in {"127.0.0.1", "::1"}:
        return "", 404
    expected = os.environ.get("QUIZ_UPDATE_HEALTH_TOKEN", "")
    supplied = request.headers.get("X-Quiz-Updater-Token", "")
    if not expected or not supplied or not hmac.compare_digest(expected, supplied):
        return "", 404

    database_ok = False
    schema_version = 0
    connection = None
    try:
        connection = sqlite3.connect(current_app.config["DATABASE"], timeout=1)
        connection.execute("PRAGMA busy_timeout=1000")
        connection.execute("SELECT 1").fetchone()
        row = connection.execute("SELECT COALESCE(MAX(version), 0) FROM schema_migrations").fetchone()
        schema_version = int(row[0])
        database_ok = True
    except (sqlite3.Error, OSError, TypeError, ValueError):
        database_ok = False
    finally:
        if connection is not None:
            connection.close()

    version = str(current_app.config.get("APP_VERSION", ""))
    status_code = 200 if database_ok else 503
    return jsonify(
        version=version,
        database_ok=database_ok,
        schema_version=schema_version,
    ), status_code
