"""Fixed loopback client for the separately managed update agent."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit


class UpdaterClientError(RuntimeError):
    def __init__(self, public_message: str):
        super().__init__(public_message)
        self.public_message = public_message


class UpdaterClient:
    def __init__(self, base_url: str, token_path: Path, timeout_seconds: float = 5):
        try:
            parsed = urlsplit(base_url)
            port = parsed.port
        except ValueError as exc:
            raise ValueError("updater agent URL is invalid") from exc
        if (
            parsed.scheme != "http"
            or parsed.hostname != "127.0.0.1"
            or parsed.username is not None
            or parsed.password is not None
            or parsed.query
            or parsed.fragment
            or parsed.path not in {"", "/"}
            or port is None
            or not 1024 < port <= 65535
        ):
            raise ValueError("updater agent must use a configured loopback HTTP endpoint")
        path = Path(token_path)
        if not path.is_absolute():
            raise ValueError("updater agent token path must be absolute")
        self._base_url = f"http://127.0.0.1:{port}"
        self._token_path = path
        self._timeout_seconds = timeout_seconds

    @classmethod
    def from_environment(cls, environ=None):
        import os

        values = os.environ if environ is None else environ
        base_url = values.get("QUIZ_UPDATER_AGENT_URL", "")
        token_path = values.get("QUIZ_UPDATER_AGENT_TOKEN_FILE", "")
        if not base_url or not token_path:
            return None
        try:
            return cls(base_url, Path(token_path))
        except ValueError:
            return None

    def status(self) -> dict[str, object]:
        return self._request("GET", "/v1/status")

    def check(self) -> dict[str, object]:
        return self._request("POST", "/v1/check")

    def install(self) -> dict[str, object]:
        return self._request("POST", "/v1/install")

    def _request(self, method: str, path: str) -> dict[str, object]:
        if path not in {"/v1/status", "/v1/check", "/v1/install"}:
            raise UpdaterClientError("不支持的更新操作")
        try:
            token = self._token_path.read_text(encoding="utf-8").strip()
        except (OSError, UnicodeError) as exc:
            raise UpdaterClientError("更新助手未安装或配置不完整，请联系管理员。") from exc
        if not token or "\r" in token or "\n" in token:
            raise UpdaterClientError("更新助手未安装或配置不完整，请联系管理员。")
        body = b"{}" if method == "POST" else None
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self._base_url + path, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=self._timeout_seconds) as response:
                payload = json.loads(response.read(64 * 1024).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise UpdaterClientError("更新助手返回了无法识别的状态。")
                return payload
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                raise UpdaterClientError("更新助手配置错误，请联系管理员。") from exc
            if exc.code == 409:
                raise UpdaterClientError("已有更新操作正在进行，请稍后刷新页面。") from exc
            raise UpdaterClientError("更新助手暂时无法处理请求，请稍后重试。") from exc
        except (OSError, urllib.error.URLError, TimeoutError, UnicodeError, json.JSONDecodeError) as exc:
            raise UpdaterClientError("更新助手未安装或未运行，请联系管理员。") from exc
