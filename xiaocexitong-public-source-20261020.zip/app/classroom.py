"""Class/date identity, conservative legacy linking and complete classroom rosters."""
import datetime
import re
import secrets
from .timezone import SHANGHAI_TIMEZONE


def iso_date(value):
    try:
        day = datetime.date.fromisoformat(value)
    except (ValueError,TypeError):
        raise ValueError('请填写真实有效的日期（YYYY-MM-DD）')
    if day.isoformat() != value:
        raise ValueError('日期必须为 YYYY-MM-DD')
    return day


def legacy_attendance_date(title, starts_at):
    day = datetime.datetime.fromtimestamp(starts_at, SHANGHAI_TIMEZONE).date()
    match = re.fullmatch(r'(\d{1,2})月(\d{1,2})日签到', title.strip())
    return day.isoformat() if match and (int(match[1]),int(match[2])) == (day.month,day.day) else None


def ensure_classroom(database, *, class_id, class_date, actor_id):
    iso_date(class_date)
    if not database.execute('SELECT 1 FROM teaching_classes WHERE id=?', (class_id,)).fetchone():
        raise ValueError('教学班不存在')
    database.execute('INSERT INTO classroom_sessions(class_id,class_date,created_by) VALUES(?,?,?) ON CONFLICT(class_id,class_date) DO NOTHING', (class_id,class_date,actor_id))
    return database.execute('SELECT id FROM classroom_sessions WHERE class_id=? AND class_date=?', (class_id,class_date)).fetchone()['id']


def link_existing(database, *, classroom_id, quiz_id=None, attendance_id=None, actor_id=None):
    room = database.execute('SELECT * FROM classroom_sessions WHERE id=?', (classroom_id,)).fetchone()
    if room is None:
        raise ValueError('课堂不存在')
    for value, table, field, date_field in ((quiz_id,'quizzes','quiz_id','quiz_date'),(attendance_id,'attendance_sessions','attendance_session_id','attendance_date')):
        if value is None:
            continue
        item = database.execute(f'SELECT * FROM {table} WHERE id=?', (value,)).fetchone()
        if item is None or item['class_id'] != room['class_id'] or item[date_field] != room['class_date']:
            raise ValueError('只能关联同教学班、同日期记录')
        if room[field] is not None and room[field] != value:
            raise ValueError('已有不同关联，请先核对历史冲突')
        if database.execute(f'SELECT 1 FROM classroom_sessions WHERE {field}=? AND id<>?', (value,classroom_id)).fetchone():
            raise ValueError('记录已关联其他课堂')
        database.execute(f'UPDATE classroom_sessions SET {field}=? WHERE id=?', (value,classroom_id))


def create_classroom_item(database, *, class_id, class_date, kind, actor_id, attendance_options=None):
    """Caller owns BEGIN IMMEDIATE and commit/rollback."""
    if kind not in ('quiz','attendance'):
        raise ValueError('记录类型无效')
    day = iso_date(class_date)
    cls = database.execute('SELECT * FROM teaching_classes WHERE id=? AND archived_at IS NULL', (class_id,)).fetchone()
    if cls is None:
        raise ValueError('教学班不存在或已归档')
    if database.execute('SELECT 1 FROM attendance_sessions WHERE class_id=? AND attendance_date IS NULL', (class_id,)).fetchone():
        raise ValueError('该班有待确认日期的历史签到，请先在历史冲突页核对')
    rid = ensure_classroom(database,class_id=class_id,class_date=class_date,actor_id=actor_id)
    room = database.execute('SELECT * FROM classroom_sessions WHERE id=?', (rid,)).fetchone()
    if room['state'] == 'conflict':
        raise ValueError('该日课堂有历史冲突，请先处理原记录')
    field = 'quiz_id' if kind == 'quiz' else 'attendance_session_id'
    if room[field] is not None:
        return dict(classroom_id=rid,item_id=room[field],created=False)
    # Also detect records from older writers, including records in the recycle bin.
    table, date_field = ('quizzes','quiz_date') if kind == 'quiz' else ('attendance_sessions','attendance_date')
    existing = database.execute(f'SELECT id FROM {table} WHERE class_id=? AND {date_field}=?', (class_id,class_date)).fetchall()
    if len(existing) > 1:
        raise ValueError('同日存在历史重复候选，请先核对')
    if existing:
        item_id = existing[0]['id']
        created = False
    elif kind == 'quiz':
        item_id = database.execute("INSERT INTO quizzes(name,quiz_date,class_name,class_id,total_score,scoring_mode,created_by) VALUES(?,?,?,?,NULL,'negative_marking',?)", (f'{day.month}月{day.day}日小测',class_date,cls['display_name'],class_id,actor_id)).lastrowid
        created = True
    else:
        opts = attendance_options or {}
        start,end,late = (int(opts[k]) for k in ('starts_at','ends_at','late_after'))
        if not start <= late <= end or end <= start:
            raise ValueError('签到时间窗口无效')
        if any(datetime.datetime.fromtimestamp(t, SHANGHAI_TIMEZONE).date() != day for t in (start,end)):
            raise ValueError('签到时间必须在选定的北京时间日期内')
        item_id = database.execute('INSERT INTO attendance_sessions(title,class_name,class_id,attendance_date,code,qr_secret,starts_at,late_after,ends_at,late_enabled,schedule_rule_id,schedule_revision,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', (f'{day.month}月{day.day}日签到',cls['display_name'],class_id,class_date,'',secrets.token_hex(16),start,late,end,int(opts.get('late_enabled',True)),opts.get('schedule_rule_id'),opts.get('schedule_revision'),actor_id)).lastrowid
        created = True
    link_existing(database,classroom_id=rid,quiz_id=item_id if kind=='quiz' else None,attendance_id=item_id if kind=='attendance' else None,actor_id=actor_id)
    if kind=='attendance' and room['state']=='cancelled':
        import time
        database.execute('UPDATE attendance_sessions SET active=0,cancelled_at=? WHERE id=?',(int(time.time()),item_id))
    return dict(classroom_id=rid,item_id=item_id,created=created)


def backfill_classrooms(database):
    """Run once at migration 3; never synthesize missing submissions."""
    from .submissions import submission_from_answers
    import time
    now = int(time.time())
    for row in database.execute('SELECT * FROM attendance_sessions').fetchall():
        day = legacy_attendance_date(row['title'],row['starts_at'])
        database.execute('UPDATE attendance_sessions SET attendance_date=? WHERE id=?', (day,row['id']))
    dates = database.execute('SELECT class_id,quiz_date AS day FROM quizzes WHERE class_id IS NOT NULL UNION SELECT class_id,attendance_date AS day FROM attendance_sessions WHERE class_id IS NOT NULL AND attendance_date IS NOT NULL').fetchall()
    for row in dates:
        try:
            rid = ensure_classroom(database,class_id=row['class_id'],class_date=row['day'],actor_id=None)
        except ValueError:
            continue
        quizzes = database.execute('SELECT id FROM quizzes WHERE class_id=? AND quiz_date=?', (row['class_id'],row['day'])).fetchall()
        atts = database.execute('SELECT id FROM attendance_sessions WHERE class_id=? AND attendance_date=?', (row['class_id'],row['day'])).fetchall()
        if len(quizzes)>1 or len(atts)>1:
            database.execute("UPDATE classroom_sessions SET state='conflict' WHERE id=?", (rid,))
        else:
            link_existing(database,classroom_id=rid,quiz_id=quizzes[0]['id'] if quizzes else None,attendance_id=atts[0]['id'] if atts else None)
    database.execute('UPDATE quizzes SET results_confirmed_at=? WHERE EXISTS(SELECT 1 FROM scores s WHERE s.quiz_id=quizzes.id)', (now,))
    for row in database.execute('SELECT s.*,q.total_score,q.scoring_mode FROM scores s JOIN quizzes q ON q.id=s.quiz_id').fetchall():
        answers = {d['number']:d['answer_status'] for d in database.execute('SELECT * FROM answer_details WHERE score_id=?',(row['id'],))}
        try:
            count=int(row['total_score'] or 0) if row['scoring_mode']=='negative_marking' else len(answers)
            status = submission_from_answers(answers,count)
        except ValueError:
            continue
        if status == 'submitted':
            database.execute("INSERT OR IGNORE INTO quiz_submissions(quiz_id,student_id,status,source,confirmed_at) VALUES(?,?,?,'migration',?)", (row['quiz_id'],row['student_id'],status,now))


def repair_legacy_total_submissions(database):
    """Migration 4: repair only missing statuses for valid nonzero, total-only results."""
    import math
    import time
    now=int(time.time())
    rows=database.execute('''SELECT s.quiz_id,s.student_id,s.score,q.total_score,q.results_confirmed_at
        FROM scores s JOIN quizzes q ON q.id=s.quiz_id
        WHERE NOT EXISTS(SELECT 1 FROM answer_details d WHERE d.score_id=s.id)
        AND NOT EXISTS(SELECT 1 FROM quiz_submissions sub WHERE sub.quiz_id=s.quiz_id AND sub.student_id=s.student_id)
        AND s.score<>0''').fetchall()
    for row in rows:
        value,maximum=row['score'],row['total_score']
        if maximum is None or not math.isfinite(value) or not math.isfinite(maximum) or maximum<=0 or not -maximum<=value<=maximum:
            continue
        database.execute("INSERT INTO quiz_submissions(quiz_id,student_id,status,source,confirmed_at) VALUES(?,?,'submitted','migration_total_only',?)",(row['quiz_id'],row['student_id'],row['results_confirmed_at'] or now))
        database.execute('UPDATE quizzes SET results_confirmed_at=COALESCE(results_confirmed_at,?) WHERE id=?',(now,row['quiz_id']))


def attendance_rows(database, session_id):
    rows = database.execute("""SELECT u.id AS student_id,u.username,u.name,r.status AS raw_status,r.signed_at,
        a.status AS adjustment_status,a.version AS adjustment_version,a.reason,a.changed_at
        FROM attendance_sessions s JOIN student_classes sc ON sc.class_id=s.class_id
        JOIN users u ON u.id=sc.student_id
        LEFT JOIN attendance_records r ON r.student_id=u.id AND r.session_id=s.id
        LEFT JOIN attendance_adjustments a ON a.student_id=u.id AND a.session_id=s.id
        WHERE s.id=? AND u.role='student' AND u.active=1 AND u.archived_at IS NULL
        AND (sc.status='active' OR r.id IS NOT NULL OR a.id IS NOT NULL) ORDER BY u.username""", (session_id,)).fetchall()
    from .attendance_state import effective_attendance
    result=[]
    for row in rows:
        row=dict(row)
        row['status']=effective_attendance(row['raw_status'],row['adjustment_status'])
        row['signed_text']=format_time(row['signed_at'])
        row['changed_text']=format_time(row['changed_at'])
        row['adjustment_version']=row['adjustment_version'] or 0
        result.append(row)
    return result


def format_time(ts):
    return datetime.datetime.fromtimestamp(ts,SHANGHAI_TIMEZONE).strftime('%Y-%m-%d %H:%M:%S') if ts is not None else ''


def classroom_rows(database, *, classroom_id, student_id=None):
    from .attendance_state import effective_attendance, session_state
    from .submissions import submission_label
    room=database.execute('SELECT * FROM classroom_sessions WHERE id=?',(classroom_id,)).fetchone()
    if room is None: raise ValueError('课堂不存在')
    quiz=database.execute('SELECT * FROM quizzes WHERE id=?',(room['quiz_id'],)).fetchone()
    att=database.execute('SELECT * FROM attendance_sessions WHERE id=?',(room['attendance_session_id'],)).fetchone()
    state=session_state(database,att) if att else None
    rows=database.execute("""SELECT u.id AS student_id,u.username,u.name,r.status AS raw_status,r.signed_at,
        a.status AS adjustment_status,a.version AS adjustment_version,a.reason,a.changed_at,
        sub.status AS submission_status,sub.import_batch_id,s.score,s.id AS score_id,
        (SELECT COUNT(*) FROM answer_details d WHERE d.score_id=s.id) AS answer_count
        FROM student_classes sc JOIN users u ON u.id=sc.student_id
        LEFT JOIN attendance_records r ON r.student_id=u.id AND r.session_id=?
        LEFT JOIN attendance_adjustments a ON a.student_id=u.id AND a.session_id=?
        LEFT JOIN quiz_submissions sub ON sub.student_id=u.id AND sub.quiz_id=?
        LEFT JOIN scores s ON s.student_id=u.id AND s.quiz_id=?
        WHERE sc.class_id=? AND u.role='student' AND u.active=1 AND u.archived_at IS NULL
        AND (sc.status='active' OR r.id IS NOT NULL OR a.id IS NOT NULL OR sub.id IS NOT NULL OR s.id IS NOT NULL)
        AND (? IS NULL OR u.id=?) ORDER BY u.username""",(room['attendance_session_id'],room['attendance_session_id'],room['quiz_id'],room['quiz_id'],room['class_id'],student_id,student_id)).fetchall()
    result=[]
    latest=database.execute('SELECT import_batch_id FROM quiz_submission_events WHERE quiz_id=? ORDER BY id DESC LIMIT 1',(room['quiz_id'],)).fetchone()
    for raw in rows:
        row=dict(raw)
        row['attendance_status']=effective_attendance(row['raw_status'],row['adjustment_status'])
        row['participation_label']='待关联签到' if not att or room['state']=='conflict' else ('待签到' if state=='scheduled' else ('参加' if row['attendance_status']!='absent' else '未参加'))
        row['review_note']=room['review_note'] or ('课堂已取消' if room['state']=='cancelled' else ('签到进行中' if state in ('open_normal','open_late') else ''))
        row['submission_label']=submission_label(row['submission_status'],results_confirmed=bool(quiz and quiz['results_confirmed_at']),legacy_zero=row['score']==0 and not row['answer_count'])
        row['retained']=bool(latest and row['import_batch_id'] and row['import_batch_id']!=latest['import_batch_id'])
        row['adjusted']=row['adjustment_status'] is not None
        row['adjustment_version']=row['adjustment_version'] or 0
        row['signed_text']=format_time(row['signed_at'])
        row['changed_text']=format_time(row['changed_at'])
        if student_id is not None:
            row.pop('reason',None)
            if not quiz or not quiz['published']:
                row.pop('score',None)
                row.pop('score_id',None)
                row.pop('answer_count',None)
        result.append(row)
    return result
