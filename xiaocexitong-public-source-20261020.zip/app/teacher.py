import csv
import datetime
import io
import json
import re
import secrets
import shutil
import time
import uuid
from pathlib import Path

from flask import Blueprint, Response, abort, current_app, flash, g, jsonify, redirect, render_template, request, send_file, url_for
from werkzeug.security import generate_password_hash

from . import attendance_qr
from .classroom import create_classroom_item, iso_date, attendance_rows, format_time, classroom_rows
from .attendance_state import server_now, session_state
from .timezone import SHANGHAI_TIMEZONE
from .db import get_db
from .importers import (
    commit_students,
    load_batch,
    parse_class_roster,
    parse_scores,
    parse_students,
    save_batch,
    validate_new_class,
    validate_results,
    validate_students,
)
from .security import role_required
from .stats import question_statistics, statistics_summary
from .submissions import apply_submission, result_snapshot, submission_from_answers

bp = Blueprint("teacher", __name__, url_prefix="/teacher")
RETENTION_MS = 30 * 24 * 60 * 60 * 1000


def _remove_files(relative_paths):
    upload_root = Path(current_app.config["UPLOAD_ROOT"])
    for relative in relative_paths:
        (upload_root / relative).unlink(missing_ok=True)


def _question_count_from_rows(rows):
    numbers = sorted({int(number) for row in rows for number in row.get("question_numbers", [])})
    if not numbers or numbers != list(range(1, numbers[-1] + 1)):
        return None
    return numbers[-1]


def _purge_student(user_id):
    database = get_db()
    student = database.execute(
        "SELECT id FROM users WHERE id=? AND role='student' AND archived_at IS NOT NULL AND archived_batch IS NULL",
        (user_id,),
    ).fetchone()
    if student is None:
        return False
    paths = [
        row["storage_name"]
        for row in database.execute(
            "SELECT i.storage_name FROM quiz_images i JOIN scores s ON s.id=i.score_id WHERE s.student_id=?",
            (user_id,),
        ).fetchall()
    ]
    database.execute("DELETE FROM users WHERE id=?", (user_id,))
    database.commit()
    _remove_files(paths)
    return True


def _purge_class(batch_id):
    database = get_db()
    item = database.execute("SELECT id,class_id,class_name FROM class_trash WHERE id=?", (batch_id,)).fetchone()
    if item is None:
        return False
    class_id = item["class_id"]
    if class_id is None:
        mapped = database.execute(
            "SELECT id FROM teaching_classes WHERE display_name=? ORDER BY id LIMIT 1", (item["class_name"],)
        ).fetchone()
        class_id = mapped["id"] if mapped else None
    if class_id is None:
        return False
    paths = [
        row["storage_name"]
        for row in database.execute(
            """
            SELECT DISTINCT i.storage_name
            FROM quiz_images i
            JOIN scores s ON s.id=i.score_id
            JOIN quizzes q ON q.id=s.quiz_id
            WHERE q.class_id=?
            """,
            (class_id,),
        ).fetchall()
    ]
    database.execute(
        "DELETE FROM record_trash WHERE (kind='quiz' AND ref_id IN (SELECT id FROM quizzes WHERE class_id=?)) "
        "OR (kind='attendance' AND ref_id IN (SELECT id FROM attendance_sessions WHERE class_id=?))",
        (class_id, class_id),
    )
    database.execute("DELETE FROM quizzes WHERE class_id=?", (class_id,))
    database.execute("DELETE FROM attendance_sessions WHERE class_id=?", (class_id,))
    database.execute("DELETE FROM class_trash WHERE id=?", (batch_id,))
    database.execute("DELETE FROM teaching_classes WHERE id=?", (class_id,))
    database.commit()
    _remove_files(paths)
    return True


def _move_record_to_trash(kind, ref_id):
    """把单次小测或单次签到移入回收站：仅打归档标记，30 天内可完整恢复。"""
    database = get_db()
    if kind == "quiz":
        row = database.execute(
            "SELECT * FROM quizzes WHERE id=? AND archived_batch IS NULL", (ref_id,)
        ).fetchone()
    else:
        row = database.execute(
            "SELECT * FROM attendance_sessions WHERE id=? AND archived_batch IS NULL", (ref_id,)
        ).fetchone()
    if row is None:
        return None
    now = int(time.time() * 1000)
    batch_id = uuid.uuid4().hex
    if kind == "quiz":
        score_count = database.execute("SELECT COUNT(*) AS n FROM scores WHERE quiz_id=?", (ref_id,)).fetchone()["n"]
        database.execute("UPDATE quizzes SET archived_batch=?,published=0 WHERE id=?", (batch_id, ref_id))
        detail = f"{score_count} 份成绩"
        title = row["name"]
    else:
        signed = database.execute("SELECT COUNT(*) AS n FROM attendance_records WHERE session_id=?", (ref_id,)).fetchone()["n"]
        database.execute("UPDATE attendance_sessions SET archived_batch=?,active=0 WHERE id=?", (batch_id, ref_id))
        detail = f"{signed} 条签到记录"
        title = row["title"]
    database.execute(
        "INSERT INTO record_trash(id,kind,ref_id,title,class_name,class_id,detail,deleted_at,purge_after) VALUES(?,?,?,?,?,?,?,?,?)",
        (batch_id, kind, ref_id, title, row["class_name"], row["class_id"], detail, now, now + RETENTION_MS),
    )
    database.commit()
    return batch_id


def _purge_record(batch_id):
    """彻底删除回收站里的单条记录，同时清掉小测的试卷图片文件。"""
    database = get_db()
    item = database.execute("SELECT * FROM record_trash WHERE id=?", (batch_id,)).fetchone()
    if item is None:
        return False
    paths = []
    if item["kind"] == "quiz":
        paths = [
            row["storage_name"]
            for row in database.execute(
                "SELECT i.storage_name FROM quiz_images i JOIN scores s ON s.id=i.score_id WHERE s.quiz_id=?",
                (item["ref_id"],),
            ).fetchall()
        ]
        database.execute("DELETE FROM quizzes WHERE id=?", (item["ref_id"],))
    else:
        database.execute("DELETE FROM attendance_sessions WHERE id=?", (item["ref_id"],))
    database.execute("DELETE FROM record_trash WHERE id=?", (batch_id,))
    database.commit()
    _remove_files(paths)
    return True


def _quiz_impact(quiz_id):
    return get_db().execute(
        """
        SELECT (SELECT COUNT(*) FROM scores WHERE quiz_id=?) AS score_count,
               (SELECT COUNT(*) FROM quiz_images i JOIN scores s ON s.id=i.score_id WHERE s.quiz_id=?) AS image_count
        """,
        (quiz_id, quiz_id),
    ).fetchone()


def _bulk_targets():
    """统计回收站里每个区块的待处理数量和影响面，供确认页显示。"""
    database = get_db()
    return {
        "classes": {
            "count": database.execute("SELECT COUNT(*) AS n FROM class_trash").fetchone()["n"],
            "students": database.execute("SELECT COUNT(DISTINCT sc.student_id) AS n FROM student_classes sc JOIN class_trash t ON t.class_id=sc.class_id").fetchone()["n"],
            "quizzes": database.execute("SELECT COUNT(*) AS n FROM quizzes WHERE archived_batch IS NOT NULL").fetchone()["n"],
            "attendances": database.execute("SELECT COUNT(*) AS n FROM attendance_sessions WHERE archived_batch IS NOT NULL").fetchone()["n"],
        },
        "students": {
            "count": database.execute(
                "SELECT COUNT(*) AS n FROM users WHERE role='student' AND archived_at IS NOT NULL AND archived_batch IS NULL"
            ).fetchone()["n"],
            "images": database.execute(
                "SELECT COUNT(*) AS n FROM quiz_images i JOIN scores s ON s.id=i.score_id JOIN users u ON u.id=s.student_id WHERE u.archived_at IS NOT NULL AND u.archived_batch IS NULL"
            ).fetchone()["n"],
        },
        "quizzes": {
            "count": database.execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='quiz'").fetchone()["n"],
            "scores": database.execute("SELECT COUNT(*) AS n FROM scores s JOIN record_trash t ON t.kind='quiz' AND t.ref_id=s.quiz_id").fetchone()["n"],
            "images": database.execute(
                "SELECT COUNT(*) AS n FROM quiz_images i JOIN scores s ON s.id=i.score_id JOIN record_trash t ON t.kind='quiz' AND t.ref_id=s.quiz_id"
            ).fetchone()["n"],
        },
        "attendances": {
            "count": database.execute("SELECT COUNT(*) AS n FROM record_trash WHERE kind='attendance'").fetchone()["n"],
            "records": database.execute(
                "SELECT COUNT(*) AS n FROM attendance_records r JOIN record_trash t ON t.kind='attendance' AND t.ref_id=r.session_id"
            ).fetchone()["n"],
        },
    }


def _purge_all_classes():
    batch_ids = [row["id"] for row in get_db().execute("SELECT id FROM class_trash").fetchall()]
    purged = 0
    for batch_id in batch_ids:
        if _purge_class(batch_id):
            purged += 1
    return purged


def _restore_all_classes():
    database = get_db()
    items = database.execute("SELECT id,purge_after FROM class_trash").fetchall()
    restored = purged = 0
    now = int(time.time() * 1000)
    for item in items:
        if item["purge_after"] <= now:
            _purge_class(item["id"])
            purged += 1
        else:
            database.execute(
                "UPDATE teaching_classes SET archived_at=NULL,purge_after=NULL,archived_batch=NULL WHERE archived_batch=?",
                (item["id"],),
            )
            database.execute(
                "UPDATE quizzes SET archived_batch=NULL,published=0 WHERE archived_batch=?", (item["id"],)
            )
            database.execute(
                "UPDATE attendance_sessions SET archived_batch=NULL,active=0 WHERE archived_batch=?",
                (item["id"],),
            )
            database.execute("DELETE FROM class_trash WHERE id=?", (item["id"],))
            restored += 1
    database.commit()
    return restored, purged


def _purge_all_students():
    user_ids = [
        row["id"]
        for row in get_db().execute(
            "SELECT id FROM users WHERE role='student' AND archived_at IS NOT NULL AND archived_batch IS NULL"
        ).fetchall()
    ]
    purged = 0
    for user_id in user_ids:
        if _purge_student(user_id):
            purged += 1
    return purged


def _restore_all_students():
    database = get_db()
    items = database.execute(
        "SELECT id,purge_after FROM users WHERE role='student' AND archived_at IS NOT NULL AND archived_batch IS NULL"
    ).fetchall()
    restored = purged = 0
    now = int(time.time() * 1000)
    for item in items:
        if item["purge_after"] <= now:
            _purge_student(item["id"])
            purged += 1
        else:
            database.execute(
                "UPDATE users SET archived_at=NULL,purge_after=NULL,archived_batch=NULL WHERE id=?",
                (item["id"],),
            )
            restored += 1
    database.commit()
    return restored, purged


def _purge_all_records(kind):
    items = get_db().execute(
        "SELECT id,ref_id FROM record_trash WHERE kind=?", (kind,)
    ).fetchall()
    purged = 0
    for item in items:
        if _purge_record(item["id"]):
            purged += 1
    return purged


def _restore_all_records(kind):
    database = get_db()
    items = database.execute(
        "SELECT id,ref_id,purge_after FROM record_trash WHERE kind=?", (kind,)
    ).fetchall()
    restored = purged = 0
    now = int(time.time() * 1000)
    for item in items:
        if item["purge_after"] <= now:
            _purge_record(item["id"])
            purged += 1
        else:
            if kind == "quiz":
                database.execute(
                    "UPDATE quizzes SET archived_batch=NULL,published=0 WHERE id=?", (item["ref_id"],)
                )
            else:
                database.execute(
                    "UPDATE attendance_sessions SET archived_batch=NULL,active=0 WHERE id=?",
                    (item["ref_id"],),
                )
            database.execute("DELETE FROM record_trash WHERE id=?", (item["id"],))
            restored += 1
    database.commit()
    return restored, purged


def _cleanup_expired():
    database = get_db()
    now = int(time.time() * 1000)
    student_ids = [
        row["id"]
        for row in database.execute(
            "SELECT id FROM users WHERE role='student' AND archived_batch IS NULL AND purge_after IS NOT NULL AND purge_after<=?",
            (now,),
        ).fetchall()
    ]
    batch_ids = [row["id"] for row in database.execute("SELECT id FROM class_trash WHERE purge_after<=?", (now,)).fetchall()]
    record_ids = [row["id"] for row in database.execute("SELECT id FROM record_trash WHERE purge_after<=?", (now,)).fetchall()]
    for user_id in student_ids:
        _purge_student(user_id)
    for batch_id in batch_ids:
        _purge_class(batch_id)
    for batch_id in record_ids:
        _purge_record(batch_id)


@bp.get("/dashboard")
@role_required("teacher", "admin")
def dashboard():
    _cleanup_expired()
    database = get_db()
    counts = {
        "students": database.execute("SELECT COUNT(*) AS n FROM users WHERE role='student' AND active=1 AND archived_at IS NULL").fetchone()["n"],
        "quizzes": database.execute("SELECT COUNT(*) AS n FROM quizzes WHERE archived_batch IS NULL").fetchone()["n"],
        "published": database.execute("SELECT COUNT(*) AS n FROM quizzes WHERE published=1 AND archived_batch IS NULL").fetchone()["n"],
        "attendance": sum(session_state(database,row) in ('open_normal','open_late') for row in database.execute('SELECT * FROM attendance_sessions')),
    }
    recent = database.execute(
        "SELECT q.*, COUNT(s.id) AS score_count FROM quizzes q LEFT JOIN scores s ON s.quiz_id=q.id WHERE q.archived_batch IS NULL GROUP BY q.id ORDER BY q.quiz_date DESC, q.id DESC LIMIT 8"
    ).fetchall()
    return render_template("teacher/dashboard.html", counts=counts, recent=recent)


@bp.get("/students")
@role_required("teacher", "admin")
def students():
    _cleanup_expired()
    database = get_db()
    selected_class = request.args.get("class_id", "").strip()
    search = request.args.get("search", "").strip()
    clauses = ["u.role='student'", "u.active=1", "u.archived_at IS NULL"]
    parameters = []
    if selected_class:
        try:
            selected_class = int(selected_class)
        except ValueError:
            selected_class = 0
        clauses.append("EXISTS (SELECT 1 FROM student_classes sc WHERE sc.student_id=u.id AND sc.class_id=? AND sc.status='active')")
        parameters.append(selected_class)
    if search:
        clauses.append("(u.username LIKE ? OR u.name LIKE ?)")
        parameters.extend((f"%{search}%", f"%{search}%"))
    rows = database.execute(
        f"""
        SELECT u.id,u.username,u.name,u.must_change_password,u.active,
               COALESCE(GROUP_CONCAT(tc.display_name, '、'),'未加入教学班') AS class_names
        FROM users u
        LEFT JOIN student_classes sc ON sc.student_id=u.id AND sc.status='active'
        LEFT JOIN teaching_classes tc ON tc.id=sc.class_id AND tc.archived_at IS NULL
        WHERE {' AND '.join(clauses)}
        GROUP BY u.id ORDER BY class_names,u.username
        """,
        parameters,
    ).fetchall()
    classes = [
        dict(row)
        for row in database.execute(
            "SELECT id,display_name FROM teaching_classes WHERE archived_at IS NULL ORDER BY school_year DESC,term,course_name,section_no,display_name"
        ).fetchall()
    ]
    return render_template("teacher/students.html", students=rows, classes=classes, selected_class=selected_class, search=search)


@bp.route("/students/<int:user_id>/edit", methods=("GET", "POST"))
@role_required("teacher", "admin")
def edit_student(user_id):
    database = get_db()
    student = database.execute(
        "SELECT * FROM users WHERE id=? AND role='student' AND archived_at IS NULL", (user_id,)
    ).fetchone()
    if student is None:
        abort(404)
    classes = database.execute(
        "SELECT id,display_name,school_year,term,course_name,section_no FROM teaching_classes "
        "WHERE archived_at IS NULL ORDER BY school_year DESC,term,course_name,section_no,display_name"
    ).fetchall()
    selected_ids = {
        row["class_id"]
        for row in database.execute(
                    "SELECT sc.class_id FROM student_classes sc JOIN teaching_classes tc ON tc.id=sc.class_id "
                    "WHERE sc.student_id=? AND sc.status='active' AND tc.archived_at IS NULL", (user_id,)
        ).fetchall()
    }
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        requested_ids = request.form.getlist("class_ids")
        try:
            class_ids = sorted({int(value) for value in requested_ids})
        except ValueError:
            class_ids = []
            requested_ids = ["invalid"]
        if not name or len(name) > 100 or any(not str(value).isdigit() for value in requested_ids):
            flash("请填写有效姓名，并只选择已有教学班。", "error")
        elif class_ids and database.execute(
            f"SELECT COUNT(*) AS n FROM teaching_classes WHERE archived_at IS NULL AND id IN ({','.join('?' for _ in class_ids)})",
            class_ids,
        ).fetchone()["n"] != len(class_ids):
            flash("所选教学班不存在或已归档。", "error")
        else:
            now = datetime.datetime.now().isoformat(timespec="seconds")
            database.execute("UPDATE users SET name=? WHERE id=?", (name, user_id))
            current_ids = {
                row["class_id"]
                for row in database.execute(
                    "SELECT sc.class_id FROM student_classes sc JOIN teaching_classes tc ON tc.id=sc.class_id "
                    "WHERE sc.student_id=? AND sc.status='active' AND tc.archived_at IS NULL", (user_id,)
                ).fetchall()
            }
            for class_id in current_ids - set(class_ids):
                database.execute(
                    "UPDATE student_classes SET status='removed',removed_at=? WHERE student_id=? AND class_id=?",
                    (now, user_id, class_id),
                )
            for class_id in class_ids:
                database.execute(
                    "INSERT INTO student_classes(student_id,class_id,status,removed_at) VALUES(?,?,'active',NULL) "
                    "ON CONFLICT(student_id,class_id) DO UPDATE SET status='active',removed_at=NULL",
                    (user_id, class_id),
                )
            fallback_name = database.execute(
                "SELECT tc.display_name FROM student_classes sc JOIN teaching_classes tc ON tc.id=sc.class_id "
                "WHERE sc.student_id=? AND sc.status='active' AND tc.archived_at IS NULL "
                "ORDER BY tc.school_year DESC,tc.display_name LIMIT 1",
                (user_id,),
            ).fetchone()
            database.execute(
                "UPDATE users SET class_name=? WHERE id=?",
                (fallback_name["display_name"] if fallback_name else None, user_id),
            )
            database.commit()
            flash("学生资料和选班关系已更新；移出教学班只停止后续导入，不删除历史成绩。", "success")
            return redirect(url_for("teacher.students"))
    return render_template("teacher/edit_student.html", student=student, classes=classes, selected_ids=selected_ids)


@bp.route("/students/<int:user_id>/archive", methods=("GET", "POST"))
@role_required("teacher", "admin")
def archive_student(user_id):
    database = get_db()
    student = database.execute(
        "SELECT * FROM users WHERE id=? AND role='student' AND archived_at IS NULL", (user_id,)
    ).fetchone()
    if student is None:
        abort(404)
    impacts = database.execute(
        """
        SELECT (SELECT GROUP_CONCAT(display_name,'、') FROM (
                   SELECT DISTINCT tc.display_name FROM student_classes sc
                   JOIN teaching_classes tc ON tc.id=sc.class_id WHERE sc.student_id=?
               )) AS class_names,
               (SELECT COUNT(*) FROM scores WHERE student_id=?) AS score_count,
               (SELECT COUNT(*) FROM attendance_records WHERE student_id=?) AS attendance_count
        """,
        (user_id, user_id, user_id),
    ).fetchone()
    if request.method == "GET":
        return render_template("teacher/archive_student.html", student=student, impacts=impacts)
    now = int(time.time() * 1000)
    database.execute(
        "UPDATE users SET archived_at=?,purge_after=?,archived_batch=NULL,session_version=session_version+1 WHERE id=?",
        (now, now + RETENTION_MS, user_id),
    )
    database.commit()
    flash(f"{student['name']} 账号已全局停用并移入回收站，30 天内可恢复；其所有教学班和历史记录受影响。", "success")
    return redirect(url_for("teacher.students"))


@bp.route("/students/import", defaults={"class_id": None}, methods=("GET", "POST"))
@bp.route("/classes/<int:class_id>/students/import", methods=("GET", "POST"))
@role_required("teacher", "admin")
def import_students(class_id):
    database = get_db()
    mode = "append" if class_id is not None else request.values.get("mode", "named")
    target_class = None
    if class_id is not None:
        target_class = database.execute(
            "SELECT * FROM teaching_classes WHERE id=? AND archived_at IS NULL", (class_id,)
        ).fetchone()
        if target_class is None:
            abort(404)
    if request.method == "POST":
        upload = request.files.get("student_file")
        if not upload or not upload.filename:
            flash("请选择学生名单文件。", "error")
            return redirect(request.url)
        try:
            if mode == "named":
                rows = parse_class_roster(upload)
                class_config = validate_new_class(database, request.form)
                rows = validate_students(rows, database, target_class_name=class_config["display_name"], mode="named")
            elif mode == "append":
                rows = parse_students(upload)
                class_config = None
                rows = validate_students(rows, database, target_class_id=class_id, target_class_name=target_class["display_name"], mode="append")
            elif mode == "legacy":
                if Path(upload.filename or "").suffix.lower() != ".xlsx":
                    raise ValueError("新建教学班的学生名单仅支持 .xlsx 文件。")
                rows = parse_students(upload)
                class_config = None
                rows = validate_students(rows, database, mode="legacy")
            else:
                raise ValueError("无效的导入方式")
        except (ValueError, UnicodeDecodeError) as error:
            flash(str(error), "error")
            return redirect(request.url)
        payload = {
            "rows": rows,
            "mode": mode,
            "class_config": class_config,
            "target_class_id": class_id,
            "target_class_name": target_class["display_name"] if target_class else (class_config or {}).get("display_name", ""),
        }
        batch_id = save_batch(database, g.user["id"], "students", payload)
        return redirect(url_for("teacher.preview_students", batch_id=batch_id))
    classes = database.execute(
        "SELECT id,display_name FROM teaching_classes WHERE archived_at IS NULL ORDER BY display_name"
    ).fetchall()
    return render_template("teacher/import_students.html", mode=mode, target_class=target_class, classes=classes)


@bp.get("/students/import/<batch_id>/preview")
@role_required("teacher", "admin")
def preview_students(batch_id):
    _batch, payload = load_batch(get_db(), batch_id, g.user["id"], "students")
    if payload is None:
        abort(404)
    error_count = sum(bool(row["errors"]) for row in payload["rows"]+payload.get("absent",[]))
    return render_template(
        "teacher/preview_students.html", rows=payload["rows"], batch_id=batch_id,
        error_count=error_count, mode=payload.get("mode"), target_class_name=payload.get("target_class_name", ""),
        payload_target_id=payload.get("target_class_id"),
    )


@bp.post("/students/import/<batch_id>/confirm")
@role_required("teacher", "admin")
def confirm_students(batch_id):
    database = get_db()
    batch, payload = load_batch(database, batch_id, g.user["id"], "students")
    if payload is None:
        abort(404)
    if any(row["errors"] for row in payload["rows"]):
        flash("名单仍有错误，不能导入。请修改文件后重新预览。", "error")
        return redirect(url_for("teacher.preview_students", batch_id=batch_id))
    try:
        database.execute("BEGIN IMMEDIATE")
        result = commit_students(
            payload["rows"], database, mode=payload.get("mode", "named"),
            class_config=payload.get("class_config"), target_class_id=payload.get("target_class_id"),
        )
        database.execute("DELETE FROM import_batches WHERE id=?", (batch["id"],))
        database.commit()
    except ValueError as error:
        database.rollback()
        flash(str(error), "error")
        return redirect(url_for("teacher.preview_students", batch_id=batch_id))
    except Exception:
        database.rollback()
        raise
    flash(
        f"已创建 {result['created_classes']} 个教学班，新增 {result['created_accounts']} 个学生账号，"
        f"新增 {result['added_memberships']} 条选班关系，跳过 {result['skipped']} 名已加入学生。新账号初始密码为学号后六位。",
        "success",
    )
    return redirect(url_for("teacher.classes"))


@bp.post("/students/<int:user_id>/reset-password")
@role_required("teacher", "admin")
def reset_password(user_id):
    database = get_db()
    student = database.execute(
        "SELECT * FROM users WHERE id=? AND role='student' AND archived_at IS NULL", (user_id,)
    ).fetchone()
    if student is None:
        abort(404)
    initial = student["username"][-6:]
    database.execute(
        "UPDATE users SET password_hash=?, must_change_password=1, session_version=session_version+1 WHERE id=?",
        (generate_password_hash(initial), user_id),
    )
    database.commit()
    flash(f"{student['name']} 的密码已重置为学号后六位。", "success")
    return redirect(url_for("teacher.students"))


@bp.get("/classes")
@role_required("teacher", "admin")
def classes():
    _cleanup_expired()
    database = get_db()
    selected_year = request.args.get("school_year", "").strip()
    selected_term = request.args.get("term", "").strip()
    search = request.args.get("search", "").strip()
    clauses = ["tc.archived_at IS NULL"]
    parameters = []
    if selected_year:
        clauses.append("tc.school_year=?")
        parameters.append(selected_year)
    if selected_term in {"春", "秋"}:
        clauses.append("tc.term=?")
        parameters.append(selected_term)
    if search:
        clauses.append("(tc.course_name LIKE ? OR tc.display_name LIKE ? OR tc.legacy_name LIKE ?)")
        parameters.extend((f"%{search}%", f"%{search}%", f"%{search}%"))
    rows = database.execute(
        f"""
        SELECT tc.*,
               (SELECT COUNT(DISTINCT u.id) FROM student_classes sc JOIN users u ON u.id=sc.student_id
                WHERE sc.class_id=tc.id AND sc.status='active' AND u.role='student' AND u.active=1 AND u.archived_at IS NULL) AS student_count,
               (SELECT COUNT(*) FROM quizzes q WHERE q.class_id=tc.id AND q.archived_batch IS NULL) AS quiz_count,
               (SELECT COUNT(*) FROM attendance_sessions a WHERE a.class_id=tc.id AND a.archived_batch IS NULL) AS attendance_count
        FROM teaching_classes tc WHERE {' AND '.join(clauses)}
        ORDER BY tc.school_year DESC,tc.term,tc.course_name,tc.section_no,tc.display_name,tc.id
        """,
        parameters,
    ).fetchall()
    years = [row["school_year"] for row in database.execute(
        "SELECT DISTINCT school_year FROM teaching_classes WHERE school_year IS NOT NULL ORDER BY school_year DESC"
    ).fetchall()]
    return render_template(
        "teacher/classes.html", classes=rows, years=years,
        selected_year=selected_year, selected_term=selected_term, search=search,
    )


@bp.route("/classes/<int:class_id>/archive", methods=("GET", "POST"))
@role_required("teacher", "admin")
def archive_class(class_id):
    database = get_db()
    teaching_class = database.execute(
        "SELECT * FROM teaching_classes WHERE id=? AND archived_at IS NULL", (class_id,)
    ).fetchone()
    if teaching_class is None:
        abort(404)
    class_name = teaching_class["display_name"]
    if database.execute("SELECT id FROM class_trash WHERE class_id=?", (class_id,)).fetchone():
        abort(409)
    counts = database.execute(
        """
        SELECT
          (SELECT COUNT(DISTINCT student_id) FROM student_classes WHERE class_id=? AND status='active') AS student_count,
          (SELECT COUNT(*) FROM quizzes WHERE archived_batch IS NULL AND class_id=?) AS quiz_count,
          (SELECT COUNT(*) FROM attendance_sessions WHERE archived_batch IS NULL AND class_id=?) AS attendance_count
        """,
        (class_id, class_id, class_id),
    ).fetchone()
    if request.method == "POST":
        if request.form.get("confirm_name", "").strip() != class_name:
            flash("输入的教学班名称不一致。", "error")
        else:
            database.execute("UPDATE attendance_schedule_rules SET enabled=0,revision=revision+1 WHERE class_id=?", (class_id,))
            now = int(time.time() * 1000)
            batch_id = uuid.uuid4().hex
            database.execute(
                "INSERT INTO class_trash(id,class_name,deleted_at,purge_after,class_id) VALUES(?,?,?,?,?)",
                (batch_id, class_name, now, now + RETENTION_MS, class_id),
            )
            database.execute(
                "UPDATE teaching_classes SET archived_at=?,purge_after=?,archived_batch=? WHERE id=?",
                (now, now + RETENTION_MS, batch_id, class_id),
            )
            database.execute(
                "UPDATE quizzes SET archived_batch=?,published=0 WHERE archived_batch IS NULL AND class_id=?",
                (batch_id, class_id),
            )
            database.execute(
                "UPDATE attendance_sessions SET archived_batch=?,active=0 WHERE archived_batch IS NULL AND class_id=?",
                (batch_id, class_id),
            )
            database.commit()
            flash(f"{class_name} 已归档。学生账号不受影响，小测恢复后需重新发布。", "success")
            return redirect(url_for("teacher.classes"))
    return render_template("teacher/archive_class.html", class_name=class_name, counts=counts)


@bp.get("/trash")
@role_required("teacher", "admin")
def trash():
    _cleanup_expired()
    database = get_db()
    now = int(time.time() * 1000)

    def _with_days(row):
        return dict(row) | {"remaining_days": max(0, (row["purge_after"] - now + 86_399_999) // 86_400_000)}

    student_rows = [
        _with_days(row)
        for row in database.execute(
            """
            SELECT u.id,u.username,u.name,u.purge_after,
                   (SELECT GROUP_CONCAT(display_name,'、') FROM (
                       SELECT DISTINCT tc.display_name FROM student_classes sc
                       JOIN teaching_classes tc ON tc.id=sc.class_id WHERE sc.student_id=u.id
                   )) AS class_names,
                   (SELECT COUNT(*) FROM scores WHERE student_id=u.id) AS score_count,
                   (SELECT COUNT(*) FROM attendance_records WHERE student_id=u.id) AS attendance_count
            FROM users u WHERE u.role='student' AND u.archived_at IS NOT NULL AND u.archived_batch IS NULL
            ORDER BY u.archived_at DESC
            """
        ).fetchall()
    ]
    class_rows = [
        _with_days(row)
        for row in database.execute(
            """
            SELECT t.*,
                   (SELECT COUNT(DISTINCT sc.student_id) FROM student_classes sc WHERE sc.class_id=t.class_id AND sc.status='active') AS student_count,
                   (SELECT COUNT(*) FROM quizzes q WHERE q.class_id=t.class_id) AS quiz_count,
                   (SELECT COUNT(*) FROM attendance_sessions a WHERE a.class_id=t.class_id) AS attendance_count
            FROM class_trash t ORDER BY t.deleted_at DESC
            """
        ).fetchall()
    ]
    quiz_rows = [
        _with_days(row)
        for row in database.execute(
            "SELECT * FROM record_trash WHERE kind='quiz' ORDER BY deleted_at DESC"
        ).fetchall()
    ]
    attendance_rows = [
        _with_days(row)
        for row in database.execute(
            "SELECT * FROM record_trash WHERE kind='attendance' ORDER BY deleted_at DESC"
        ).fetchall()
    ]
    return render_template(
        "teacher/trash.html",
        students=student_rows,
        classes=class_rows,
        records=quiz_rows,
        attendances=attendance_rows,
    )


@bp.post("/trash/students/<int:user_id>/restore")
@role_required("teacher", "admin")
def restore_student(user_id):
    database = get_db()
    student = database.execute(
        "SELECT * FROM users WHERE id=? AND role='student' AND archived_at IS NOT NULL AND archived_batch IS NULL",
        (user_id,),
    ).fetchone()
    if student is None:
        abort(404)
    if student["purge_after"] <= int(time.time() * 1000):
        _purge_student(user_id)
        flash("该学生已超过保留期并被永久删除。", "error")
    else:
        database.execute(
            "UPDATE users SET archived_at=NULL,purge_after=NULL,archived_batch=NULL WHERE id=?", (user_id,)
        )
        database.commit()
        flash(f"{student['name']} 已恢复，可以重新登录。", "success")
    return redirect(url_for("teacher.trash"))


@bp.post("/trash/students/<int:user_id>/purge")
@role_required("teacher", "admin")
def purge_student(user_id):
    if not _purge_student(user_id):
        abort(404)
    flash("学生账号、成绩记录和相关图片已永久删除。", "success")
    return redirect(url_for("teacher.trash"))


@bp.post("/trash/classes/<batch_id>/restore")
@role_required("teacher", "admin")
def restore_class(batch_id):
    database = get_db()
    item = database.execute("SELECT * FROM class_trash WHERE id=?", (batch_id,)).fetchone()
    if item is None:
        abort(404)
    if item["purge_after"] <= int(time.time() * 1000):
        _purge_class(batch_id)
        flash("该班级已超过保留期并被永久删除。", "error")
    else:
        database.execute(
            "UPDATE teaching_classes SET archived_at=NULL,purge_after=NULL,archived_batch=NULL WHERE archived_batch=?",
            (batch_id,),
        )
        database.execute("UPDATE quizzes SET archived_batch=NULL,published=0 WHERE archived_batch=?", (batch_id,))
        database.execute(
            "UPDATE attendance_sessions SET archived_batch=NULL,active=0 WHERE archived_batch=?", (batch_id,)
        )
        database.execute("DELETE FROM class_trash WHERE id=?", (batch_id,))
        database.commit()
        flash(f"{item['class_name']} 已恢复；学生账号未受影响，原小测保持未发布，签到保持关闭。", "success")
    return redirect(url_for("teacher.trash"))


@bp.post("/trash/classes/<batch_id>/purge")
@role_required("teacher", "admin")
def purge_class(batch_id):
    if not _purge_class(batch_id):
        abort(404)
    flash("教学班、选班关系、小测、成绩、签到和相关图片已永久删除；学生账号及其其他班级记录保留。", "success")
    return redirect(url_for("teacher.trash"))


@bp.post("/trash/records/<batch_id>/restore")
@role_required("teacher", "admin")
def restore_record(batch_id):
    database = get_db()
    item = database.execute("SELECT * FROM record_trash WHERE id=?", (batch_id,)).fetchone()
    if item is None:
        abort(404)
    if item["purge_after"] <= int(time.time() * 1000):
        _purge_record(batch_id)
        flash("该记录已超过保留期并被永久删除。", "error")
    else:
        if item["kind"] == "quiz":
            database.execute("UPDATE quizzes SET archived_batch=NULL,published=0 WHERE id=?", (item["ref_id"],))
            flash(f"小测《{item['title']}》已恢复，请核对后重新发布。", "success")
        else:
            database.execute(
                "UPDATE attendance_sessions SET archived_batch=NULL,active=0 WHERE id=?", (item["ref_id"],)
            )
            flash(f"签到《{item['title']}》已恢复。", "success")
        database.execute("DELETE FROM record_trash WHERE id=?", (batch_id,))
        database.commit()
    return redirect(url_for("teacher.trash"))


@bp.post("/trash/records/<batch_id>/purge")
@role_required("teacher", "admin")
def purge_record(batch_id):
    if not _purge_record(batch_id):
        abort(404)
    flash("该记录及其成绩、试卷图片已永久删除。", "success")
    return redirect(url_for("teacher.trash"))


_BULK_SECTIONS = {
    "classes": {
        "title": "班级",
        "items_label": "个班级",
        "action_purge": "永久删除全部班级",
        "action_restore": "全部恢复",
        "impact_template": "将一次性删除 {count} 个教学班、{students} 条选班关系、{quizzes} 次小测和 {attendances} 场签到，以及班内成绩、图片和考勤记录。学生账号及其其他教学班记录会保留。",
        "impact_restore_template": "将恢复 {count} 个教学班及其关联记录。学生账号不变；原小测保持未发布，签到保持关闭。",
    },
    "students": {
        "title": "学生",
        "items_label": "名学生",
        "action_purge": "永久删除全部学生",
        "action_restore": "全部恢复",
        "impact_template": "将一次性删除 {count} 名学生账号及其成绩、试卷图片，共 {images} 张图片文件，永久不可恢复。",
        "impact_restore_template": "将恢复 {count} 名学生的账号。这些学生可以重新登录使用。",
    },
    "quizzes": {
        "title": "小测",
        "items_label": "次小测",
        "action_purge": "永久删除全部小测",
        "action_restore": "全部恢复",
        "impact_template": "将一次性删除 {count} 次小测及其 {scores} 份成绩、{images} 张试卷图片，永久不可恢复。",
        "impact_restore_template": "将恢复 {count} 次小测。注意：恢复后所有小测统一保持未发布，请核对后重新发布。",
    },
    "attendances": {
        "title": "签到",
        "items_label": "场签到",
        "action_purge": "永久删除全部签到",
        "action_restore": "全部恢复",
        "impact_template": "将一次性删除 {count} 场签到及其 {records} 条考勤记录，永久不可恢复。",
        "impact_restore_template": "将恢复 {count} 场签到。恢复后默认为已结束状态，确认需要时可以再次手动结束或重新开放。",
    },
}


def _bulk_context(section):
    targets = _bulk_targets()[section]
    cfg = _BULK_SECTIONS[section]
    if not targets["count"]:
        return None
    return {
        "section": section,
        "count": targets["count"],
        "cfg": cfg,
        "targets": targets,
        "back_url": url_for("teacher.trash"),
    }


@bp.get("/trash/<section>/<action>")
@role_required("teacher", "admin")
def bulk_confirm(section, action):
    """展示批量恢复/删除的二次确认页。"""
    if section not in _BULK_SECTIONS or action not in ("restore", "purge"):
        abort(404)
    ctx = _bulk_context(section)
    if ctx is None:
        flash(_BULK_SECTIONS[section]["title"] + "区块没有待处理的内容。", "info")
        return redirect(url_for("teacher.trash"))
    cfg = ctx["cfg"]
    if action == "purge":
        confirm_phrase = "确认永久删除"
        prompt_text = f"请输入「{confirm_phrase}」以继续"
        impact_text = cfg["impact_template"].format(**{k: ctx["targets"].get(k, 0) for k in ("count", "students", "quizzes", "attendances", "scores", "images", "records")})
    else:
        confirm_phrase = "确认全部恢复"
        prompt_text = f"请输入「{confirm_phrase}」以继续"
        impact_text = cfg["impact_restore_template"].format(**{k: ctx["targets"].get(k, 0) for k in ("count", "students", "quizzes", "attendances", "scores", "images", "records")})
    return render_template(
        "teacher/bulk_confirm.html",
        section=ctx["section"],
        title=cfg["title"],
        action=action,
        action_label=cfg["action_purge"] if action == "purge" else cfg["action_restore"],
        count=ctx["count"],
        items_label=cfg["items_label"],
        impact_text=impact_text,
        confirm_phrase=confirm_phrase,
        prompt_text=prompt_text,
        back_url=ctx["back_url"],
    )


@bp.post("/trash/<section>/<action>")
@role_required("teacher", "admin")
def bulk_execute(section, action):
    """批量恢复/删除的真实执行：先校验确认短语，再做事。"""
    if section not in _BULK_SECTIONS or action not in ("restore", "purge"):
        abort(404)
    cfg = _BULK_SECTIONS[section]
    expected = "确认全部恢复" if action == "restore" else "确认永久删除"
    if (request.form.get("confirm_phrase", "") or "").strip() != expected:
        flash("确认短语输入错误，操作未执行。", "error")
        return redirect(url_for("teacher.bulk_confirm", section=section, action=action))
    ctx = _bulk_context(section)
    if ctx is None:
        flash(cfg["title"] + "区块没有待处理的内容。", "info")
        return redirect(url_for("teacher.trash"))
    if action == "purge":
        if section == "classes":
            n = _purge_all_classes()
        elif section == "students":
            n = _purge_all_students()
        elif section == "quizzes":
            n = _purge_all_records("quiz")
        else:
            n = _purge_all_records("attendance")
        flash(f"已永久删除 {n} {cfg['items_label']}及其关联数据。", "success")
    else:
        if section == "classes":
            restored, purged = _restore_all_classes()
        elif section == "students":
            restored, purged = _restore_all_students()
        elif section == "quizzes":
            restored, purged = _restore_all_records("quiz")
        else:
            restored, purged = _restore_all_records("attendance")
        flash(f"已恢复 {restored} {cfg['items_label']}，其中 {purged} 项因已过保留期被永久删除。", "success")
    return redirect(url_for("teacher.trash"))


@bp.get("/quizzes")
@role_required("teacher", "admin")
def quizzes():
    rows = get_db().execute(
        "SELECT q.*,COUNT(s.id) AS score_count FROM quizzes q LEFT JOIN scores s ON s.quiz_id=q.id WHERE q.archived_batch IS NULL GROUP BY q.id ORDER BY q.quiz_date DESC,q.id DESC"
    ).fetchall()
    return render_template("teacher/quizzes.html", quizzes=rows)


@bp.route("/quizzes/create", methods=("GET", "POST"))
@role_required("teacher", "admin")
def create_quiz():
    database = get_db()
    classes = database.execute(
        "SELECT id,display_name FROM teaching_classes WHERE archived_at IS NULL "
        "ORDER BY school_year DESC,term,course_name,section_no,display_name"
    ).fetchall()
    form_data = {"quiz_date": "", "class_id": ""}
    duplicate_exists = False
    if request.method == "POST":
        quiz_date = request.form.get("quiz_date", "").strip()
        class_text = request.form.get("class_id", "").strip()
        form_data = {"quiz_date": quiz_date, "class_id": class_text}
        try:
            quiz_class_id = int(class_text)
        except ValueError:
            quiz_class_id = 0
        teaching_class = database.execute(
            "SELECT id,display_name FROM teaching_classes WHERE id=? AND archived_at IS NULL",
            (quiz_class_id,),
        ).fetchone()
        try:
            parsed_date = datetime.datetime.strptime(quiz_date, "%Y-%m-%d").date()
            date_valid = parsed_date.isoformat() == quiz_date
        except ValueError:
            date_valid = False
        if not date_valid or teaching_class is None:
            flash("请填写真实有效的日期和已有教学班。", "error")
        else:
            try:
                database.execute("BEGIN IMMEDIATE")
                result = create_classroom_item(database, class_id=quiz_class_id, class_date=quiz_date, kind='quiz', actor_id=g.user['id'])
                database.commit()
            except ValueError as error:
                database.rollback()
                flash(str(error), 'error')
                return redirect(url_for('linkage.classroom_conflicts'))
            flash('小测已创建，可以导入成绩和逐题结果。' if result['created'] else '当天已有记录，请编辑或恢复原小测。', 'success')
            return redirect(url_for('teacher.quiz_detail', quiz_id=result['item_id']))
    return render_template(
        "teacher/create_quiz.html", classes=classes, form_data=form_data, duplicate_exists=duplicate_exists
    )


def _teacher_quiz(quiz_id):
    quiz = get_db().execute("SELECT * FROM quizzes WHERE id=? AND archived_batch IS NULL", (quiz_id,)).fetchone()
    if quiz is None:
        abort(404)
    return quiz


def _quiz_writable(quiz_id):
    room=get_db().execute('SELECT state FROM classroom_sessions WHERE quiz_id=?',(quiz_id,)).fetchone()
    if room and room['state']!='ready':
        abort(409,description='课堂已取消或有历史冲突，请先处理课堂记录')


@bp.get("/quizzes/<int:quiz_id>")
@role_required("teacher", "admin")
def quiz_detail(quiz_id):
    quiz = _teacher_quiz(quiz_id)
    database = get_db()
    scores = database.execute(
        """
        SELECT s.*,u.username,u.name,
               (SELECT COUNT(*) FROM answer_details d WHERE d.score_id=s.id) AS answer_count
        FROM scores s JOIN users u ON u.id=s.student_id
        WHERE s.quiz_id=? ORDER BY u.username
        """,
        (quiz_id,),
    ).fetchall()
    question_stats = question_statistics(database, quiz_id)
    # 本次概览：只统计有成绩的学生（缺考的不算在内）
    score_values = [row["score"] for row in scores if row["score"] is not None]
    summary = {
        "students": len(score_values),
        "average": (sum(score_values) / len(score_values)) if score_values else 0,
        "best": max(score_values) if score_values else 0,
        "worst": min(score_values) if score_values else 0,
    }
    # 缺考名单：本班在册、但这次没有成绩的学生（导入之前不显示，避免误报）
    absent_names = []
    if scores:
        scored_ids = {row["student_id"] for row in scores}
        absent_names = [
            f"{row['name']}（{row['username']}）"
            for row in database.execute(
                "SELECT u.id,u.name,u.username FROM users u JOIN student_classes sc ON sc.student_id=u.id "
                "WHERE u.role='student' AND u.active=1 AND u.archived_at IS NULL AND sc.class_id=? "
                "AND sc.status='active' ORDER BY u.username",
                (quiz["class_id"],),
            ).fetchall()
            if row["id"] not in scored_ids
        ]
    return render_template(
        "teacher/quiz_detail.html",
        quiz=quiz,
        scores=scores,
        summary=summary,
        absent_names=absent_names,
        question_stats=question_stats,
        stats_summary=statistics_summary(question_stats),
        classroom=database.execute('SELECT id FROM classroom_sessions WHERE quiz_id=?',(quiz_id,)).fetchone(),
    )


@bp.route("/quizzes/<int:quiz_id>/import", methods=("GET", "POST"))
@role_required("teacher", "admin")
def import_results(quiz_id):
    quiz = _teacher_quiz(quiz_id)
    _quiz_writable(quiz_id)
    database = get_db()
    if quiz["published"]:
        flash("请先撤回发布，再导入或更正数据。", "error")
        return redirect(url_for("teacher.quiz_detail", quiz_id=quiz_id))
    if request.method == "POST":
        score_file = request.files.get("score_file")
        if not score_file or not score_file.filename:
            flash("请选择成绩文件。", "error")
            return redirect(request.url)
        stage = Path(current_app.config["PENDING_ROOT"]) / uuid.uuid4().hex
        try:
            rows = parse_scores(score_file)
            question_count = _question_count_from_rows(rows)
            has_question_columns = any(row.get("question_numbers") for row in rows)
            effective_quiz = dict(quiz)
            if quiz["scoring_mode"] == "negative_marking":
                if quiz["total_score"] is None:
                    if question_count is not None:
                        effective_quiz["total_score"] = question_count
                    else:
                        rows[0]["errors"].append("成绩表须包含从第1题开始连续编号的逐题列，才能识别题数")
                elif has_question_columns and question_count is None:
                    rows[0]["errors"].append("逐题列须从第1题开始连续编号，无法识别题数")
                elif question_count is not None and float(quiz["total_score"]) != float(question_count):
                    rows[0]["errors"].append(
                        f"本文件识别到 {question_count} 题，与本次小测已确认的 {quiz['total_score']:g} 题不一致"
                    )
            rows, unsubmitted = validate_results(rows, effective_quiz, get_db())
        except (ValueError, UnicodeDecodeError) as error:
            shutil.rmtree(stage, ignore_errors=True)
            flash(str(error), "error")
            return redirect(request.url)
        included_ids = {row.get("student_db_id") for row in rows if row.get("student_db_id")}
        included_ids.update(row.get("student_db_id") for row in unsubmitted if row.get("student_db_id"))
        unsubmitted_ids = {row.get("student_db_id") for row in unsubmitted if row.get("student_db_id")}
        omitted_old = []
        for old in get_db().execute(
            "SELECT u.id AS student_id,u.username,u.name,s.id AS score_id,s.score,s.updated_at "
            "FROM users u LEFT JOIN scores s ON s.student_id=u.id AND s.quiz_id=? "
            "WHERE s.id IS NOT NULL OR EXISTS(SELECT 1 FROM quiz_submissions sub WHERE sub.student_id=u.id AND sub.quiz_id=?) ORDER BY u.username", (quiz_id,quiz_id)).fetchall():
            if old['student_id'] not in included_ids:
                omitted_old.append(dict(old) | {'reason':'文件缺失'})
        changes=[]
        for row in unsubmitted:
            before=result_snapshot(database,quiz_id,row['student_db_id'])
            if before['score'] or before['submission']:
                changes.append(dict(username=row['student_id'],name=row.get('student_name',''),old_score=before['score']['score'] if before['score'] else None))
        expected={str(sid):result_snapshot(database,quiz_id,sid) for sid in included_ids | {old['student_id'] for old in omitted_old}}
        payload = {
            "quiz_id": quiz_id,
            "rows": rows,
            "unsubmitted": unsubmitted,
            "omitted_old": omitted_old,
            "source_name": score_file.filename,
            "question_count": question_count,
            "expected": expected, "changes": changes,
        }
        batch_id = save_batch(get_db(), g.user["id"], "results", payload, stage)
        return redirect(url_for("teacher.preview_results", quiz_id=quiz_id, batch_id=batch_id))
    return render_template("teacher/import_results.html", quiz=quiz)


@bp.get("/quizzes/<int:quiz_id>/import/<batch_id>/preview")
@role_required("teacher", "admin")
def preview_results(quiz_id, batch_id):
    quiz = _teacher_quiz(quiz_id)
    _batch, payload = load_batch(get_db(), batch_id, g.user["id"], "results")
    if payload is None or payload["quiz_id"] != quiz_id:
        abort(404)
    error_count = sum(bool(row["errors"]) for row in payload["rows"]+payload.get("unsubmitted",[]))
    return render_template(
        "teacher/preview_results.html",
        quiz=quiz,
        rows=payload["rows"],
        unsubmitted=payload.get("unsubmitted", payload.get("absent", [])),
        omitted_old=payload.get("omitted_old", []),
        source_name=payload.get("source_name", ""),
        question_count=payload.get("question_count"),
        batch_id=batch_id,
        error_count=error_count,
        needs_old_score_choice=bool(payload.get("omitted_old")),
        changes=payload.get("changes",[]),
    )


@bp.post("/quizzes/<int:quiz_id>/import/<batch_id>/confirm")
@role_required("teacher", "admin")
def confirm_results(quiz_id, batch_id):
    quiz = _teacher_quiz(quiz_id)
    if quiz["published"]:
        abort(409)
    database = get_db()
    batch, payload = load_batch(database, batch_id, g.user["id"], "results")
    if payload is None or payload["quiz_id"] != quiz_id:
        abort(404)
    if any(row["errors"] for row in payload["rows"]):
        flash("预览中仍有错误，不能确认导入。", "error")
        return redirect(url_for("teacher.preview_results", quiz_id=quiz_id, batch_id=batch_id))

    omitted_old = payload.get("omitted_old", [])
    old_action = request.form.get("old_scores_action", "")
    if omitted_old and old_action not in {"keep", "remove"}:
        flash("请明确选择保留还是移除本次未包含的旧成绩。", "error")
        return redirect(url_for("teacher.preview_results", quiz_id=quiz_id, batch_id=batch_id))

    stage = Path(batch["storage_dir"])
    removed_files = []
    try:
        database.execute("BEGIN IMMEDIATE")
        current_quiz = database.execute(
            "SELECT * FROM quizzes WHERE id=? AND archived_batch IS NULL AND published=0", (quiz_id,)
        ).fetchone()
        if current_quiz is None:
            raise ValueError("小测已发布或已归档，请重新打开导入页面")
        room=database.execute('SELECT state FROM classroom_sessions WHERE quiz_id=?',(quiz_id,)).fetchone()
        if room and room['state']!='ready': raise ValueError('课堂已取消或状态变化，请先处理课堂记录')
        question_count = payload.get("question_count")
        effective_quiz = dict(current_quiz)
        if current_quiz["scoring_mode"] == "negative_marking":
            if current_quiz["total_score"] is None:
                if not isinstance(question_count, int) or question_count < 1:
                    raise ValueError("预览没有识别到有效题数，请重新选择成绩文件")
                effective_quiz["total_score"] = question_count
            elif question_count is not None and float(current_quiz["total_score"]) != float(question_count):
                raise ValueError("小测题数在预览后发生变化，请重新选择正确的成绩文件")
        # Re-read the batch under the write lock: simultaneous confirmations cannot replay it.
        locked_batch, locked_payload = load_batch(database,batch_id,g.user['id'],'results')
        if locked_payload is None: raise ValueError('该预览已经确认，请刷新')
        for sid, expected in payload.get('expected',{}).items():
            if result_snapshot(database,quiz_id,int(sid))!=expected:
                raise ValueError('成绩或交卷状态在预览后发生变化，请重新预览')
        rows_for_check = [dict(row, answers=dict(row.get('answers') or {}), errors=list(row.get('errors') or [])) for row in payload['rows']+payload.get('unsubmitted',payload.get('absent',[]))]
        checked_rows, checked_unsubmitted = validate_results(rows_for_check,effective_quiz,database)
        all_rows=checked_rows+checked_unsubmitted
        if any(row['errors'] for row in all_rows):
            raise ValueError('确认前复核发现名单或成绩约束已变化，请重新预览')
        if current_quiz['total_score'] is None:
            database.execute('UPDATE quizzes SET total_score=? WHERE id=?',(question_count,quiz_id))
        now=server_now()
        for row in all_rows:
            answers=row.get('answers') or {}
            count=int(effective_quiz['total_score']) if current_quiz['scoring_mode']=='negative_marking' else question_count
            status=submission_from_answers(answers,count) if answers and count else ('submitted' if row['score']!=0 else None)
            removed_files.extend(apply_submission(database,quiz_id=quiz_id,student_id=row['student_db_id'],status=status,record=row,batch_id=batch_id,actor_id=g.user['id'],now=now))
        if omitted_old and old_action=='remove':
            for old in omitted_old:
                removed_files.extend(apply_submission(database,quiz_id=quiz_id,student_id=old['student_id'],status=None,record={'remove':True},batch_id=batch_id,actor_id=g.user['id'],now=now))
        database.execute('UPDATE quizzes SET results_confirmed_at=? WHERE id=?',(now,quiz_id))
        database.execute("DELETE FROM import_batches WHERE id=?", (batch_id,))
        database.commit()
    except ValueError as error:
        database.rollback()
        flash(str(error), "error")
        return redirect(url_for("teacher.preview_results", quiz_id=quiz_id, batch_id=batch_id))
    except Exception:
        database.rollback()
        raise
    shutil.rmtree(stage, ignore_errors=True)
    _remove_files(removed_files)
    suffix = "；未包含的旧成绩已移除。" if old_action == "remove" and omitted_old else "；未包含的旧成绩已保留。" if omitted_old else "。"
    flash(f"已导入 {len(payload['rows'])} 名学生的成绩与逐题结果{suffix}", "success")
    return redirect(url_for("teacher.quiz_detail", quiz_id=quiz_id))


@bp.post("/quizzes/<int:quiz_id>/publish")
@role_required("teacher", "admin")
def publish_quiz(quiz_id):
    quiz = _teacher_quiz(quiz_id)
    _quiz_writable(quiz_id)
    database = get_db()
    score_count = database.execute("SELECT COUNT(*) AS n FROM scores WHERE quiz_id=?", (quiz_id,)).fetchone()["n"]
    if quiz["total_score"] is None:
        flash("尚未从成绩文件识别题数，不能发布。", "error")
    elif not score_count and not quiz["results_confirmed_at"]:
        flash("尚未导入成绩，不能发布。", "error")
    else:
        database.execute("UPDATE quizzes SET published=? WHERE id=?", (0 if quiz["published"] else 1, quiz_id))
        database.commit()
        flash("小测已撤回。" if quiz["published"] else "小测已发布，学生现在可以查看。", "success")
    return redirect(url_for("teacher.quiz_detail", quiz_id=quiz_id))


@bp.route("/quizzes/<int:quiz_id>/delete", methods=("GET", "POST"))
@role_required("teacher", "admin")
def delete_quiz(quiz_id):
    quiz = _teacher_quiz(quiz_id)
    counts = _quiz_impact(quiz_id)
    if request.method == "POST":
        _move_record_to_trash("quiz", quiz_id)
        flash(f"小测《{quiz['name']}》已移入回收站，30 天内可以恢复。", "success")
        return redirect(url_for("teacher.quizzes"))
    return render_template(
        "teacher/delete_record.html",
        back_url=url_for("teacher.quiz_detail", quiz_id=quiz_id),
        back_text="返回小测详情",
        heading="删除这次小测",
        subtitle="小测进入回收站后保留30天，期间学生看不到，成绩和试卷图片仍然保留。",
        target_title=quiz["name"],
        target_meta=f"{quiz['class_name']} · {quiz['quiz_date']} · 总分 {format(quiz['total_score'], 'g') if quiz['total_score'] is not None else '待识别'}",
        notes=[
            f"将移除 {counts['score_count']} 份成绩记录、{counts['image_count']} 张试卷图片，30 天内可在回收站原样恢复。",
            "小测当前" + ("已发布，删除后学生会立即无法查看。" if quiz["published"] else "未发布，学生本来就看不到。"),
            "恢复后需要重新核对并发布，学生才会再次看到成绩。",
        ],
        confirm_label="移入回收站",
    )


@bp.get("/attendance")
@role_required("teacher", "admin")
def attendance():
    database=get_db()
    rows=[dict(r) for r in database.execute('SELECT * FROM attendance_sessions WHERE archived_batch IS NULL ORDER BY starts_at DESC LIMIT 100')]
    for row in rows:
        row['state']=session_state(database,row)
        row['is_open']=row['state'] in ('open_normal','open_late')
        row['starts_text']=format_time(row['starts_at']); row['ends_text']=format_time(row['ends_at'])
        row['signed_count']=sum(r['status']!='absent' for r in attendance_rows(database,row['id']))
    return render_template('teacher/attendance.html',sessions=rows)


@bp.route("/attendance/create", methods=("GET", "POST"))
@role_required("teacher", "admin")
def create_attendance():
    database = get_db()
    classes = database.execute(
        "SELECT id,display_name FROM teaching_classes WHERE archived_at IS NULL ORDER BY display_name"
    ).fetchall()
    today = datetime.datetime.fromtimestamp(server_now(), SHANGHAI_TIMEZONE).date().isoformat()
    form_data = {"attendance_date": today, "class_id": ""}
    if request.method == 'POST':
        form_data = request.form
        try:
            class_id = int(request.form.get('class_id','0'))
            day = iso_date(request.form.get('attendance_date',''))
            now = server_now()
            mode = request.form.get('mode','immediate')
            if mode == 'single':
                from .attendance_schedule import single_occurrence
                options = single_occurrence(day.isoformat(),request.form.get('start',''),request.form.get('end',''),
                    None if request.form.get('late_disabled') else int(request.form.get('late_minutes','5')))
                if options['starts_at'] <= now: raise ValueError('单次预约必须尚未开始')
            else:
                if day.isoformat() != today: raise ValueError('立即签到只能选择北京时间今日；其他日期请设置单次预约')
                duration = int(request.form.get('duration_seconds','120'))
                late = int(request.form.get('late_seconds','30'))
                if not 1 <= duration <= 10800 or not 0 <= late <= duration: raise ValueError('签到时长需要为1—10800秒，迟到界限不能超过签到时长。')
                options = dict(starts_at=now,ends_at=now+duration,late_after=now+late)
            database.execute('BEGIN IMMEDIATE')
            result = create_classroom_item(database,class_id=class_id,class_date=day.isoformat(),kind='attendance',actor_id=g.user['id'],attendance_options=options)
            if mode == 'single':
                create_classroom_item(database,class_id=class_id,class_date=day.isoformat(),kind='quiz',actor_id=g.user['id'])
            database.commit()
            flash('签到已创建，请提前打开投屏页面。' if result['created'] else '当天已有记录，请编辑或恢复原签到。','success')
            return redirect(url_for('teacher.attendance_detail',session_id=result['item_id']))
        except (ValueError,KeyError) as error:
            database.rollback()
            flash(str(error),'error')
    return render_template('teacher/create_attendance.html',classes=classes,form_data=form_data)


def _attendance_session(session_id):
    row = get_db().execute(
        """
        SELECT *,datetime(starts_at,'unixepoch','+8 hours') AS starts_text,
                 datetime(late_after,'unixepoch','+8 hours') AS late_text,
                 datetime(ends_at,'unixepoch','+8 hours') AS ends_text
        FROM attendance_sessions WHERE id=? AND archived_batch IS NULL
        """,
        (session_id,),
    ).fetchone()
    if row is None:
        abort(404)
    result=dict(row)
    result.update(starts_text=format_time(row['starts_at']),late_text=format_time(row['late_after']),ends_text=format_time(row['ends_at']))
    return result


@bp.get("/attendance/<int:session_id>")
@role_required("teacher", "admin")
def attendance_detail(session_id):
    item = _attendance_session(session_id)
    students=attendance_rows(get_db(),session_id)
    summary=dict(total=len(students),normal=sum(r['status']=='normal' for r in students),late=sum(r['status']=='late' for r in students))
    summary['absent']=summary['total']-summary['normal']-summary['late']
    state=session_state(get_db(),item)
    room=get_db().execute('SELECT id FROM classroom_sessions WHERE attendance_session_id=?',(session_id,)).fetchone()
    events=get_db().execute('SELECT e.*,u.username FROM attendance_adjustment_events e JOIN users u ON u.id=e.student_id WHERE e.session_id=? ORDER BY e.id DESC',(session_id,)).fetchall()
    return render_template('teacher/attendance_detail.html',item=item,students=students,summary=summary,is_open=state in ('open_normal','open_late'),state=state,room=room,events=events)


@bp.post("/attendance/<int:session_id>/end")
@role_required("teacher", "admin")
def end_attendance(session_id):
    item = _attendance_session(session_id)
    get_db().execute('UPDATE attendance_sessions SET active=0,closed_at=? WHERE id=?',(server_now(),session_id))
    get_db().commit()
    flash("签到已结束。", "success")
    return redirect(url_for("teacher.attendance_detail", session_id=session_id))


@bp.route("/attendance/<int:session_id>/delete", methods=("GET", "POST"))
@role_required("teacher", "admin")
def delete_attendance(session_id):
    item = _attendance_session(session_id)
    signed = get_db().execute(
        "SELECT COUNT(*) AS n FROM attendance_records WHERE session_id=?", (session_id,)
    ).fetchone()["n"]
    if request.method == "POST":
        _move_record_to_trash("attendance", session_id)
        flash(f"签到《{item['title']}》已移入回收站，30 天内可以恢复。", "success")
        return redirect(url_for("teacher.attendance"))
    now = int(time.time())
    running = session_state(get_db(),item) in ("open_normal","open_late")
    return render_template(
        "teacher/delete_record.html",
        back_url=url_for("teacher.attendance_detail", session_id=session_id),
        back_text="返回签到详情",
        heading="删除这场签到",
        subtitle="签到进入回收站后保留30天，期间学生不能再扫码签到，考勤记录仍然保留。",
        target_title=item["title"],
        target_meta=f"{item['class_name']} · {item['starts_text']} 至 {item['ends_text']}",
        notes=[
            f"这场签到已有 {signed} 条签到记录，30 天内可在回收站原样恢复。",
            "这场签到" + ("正在进行，删除后学生会立即无法扫码签到。" if running else "已经结束，不影响其他签到。"),
            "删除前建议先导出 CSV 留档。",
        ],
        confirm_label="移入回收站",
    )


@bp.get("/attendance/<int:session_id>/qr")
@role_required("teacher", "admin")
def attendance_qr_code(session_id):
    """老师端轮询接口：返回当前二维码网址、剩余有效秒数和实时签到人数。"""
    item = _attendance_session(session_id)
    database = get_db()
    secret = item["qr_secret"]
    if not secret:
        secret = secrets.token_hex(16)
        database.execute("UPDATE attendance_sessions SET qr_secret=? WHERE id=?", (secret, session_id))
        database.commit()
    token = attendance_qr.make_token(secret, session_id, moment=server_now())
    path = url_for("student.scan_attendance", session_id=session_id, t=token)
    base = (current_app.config.get("PUBLIC_BASE_URL") or "").rstrip("/")
    url = f"{base}{path}" if base else url_for("student.scan_attendance", session_id=session_id, t=token, _external=True)
    now=server_now()
    state=session_state(database,item,now)
    rows=attendance_rows(database,session_id)
    return jsonify(dict(url=url if state in ('open_normal','open_late') else None,seconds_left=attendance_qr.seconds_left(now),window=attendance_qr.WINDOW_SECONDS,signed=sum(r['status']!='absent' for r in rows),total=len(rows),open=state in ('open_normal','open_late'),state=state,server_now=now,starts_at=item['starts_at'],ends_at=item['ends_at']))


@bp.get("/attendance/<int:session_id>/export")
@role_required("teacher", "admin")
def export_attendance(session_id):
    item = _attendance_session(session_id)
    room=get_db().execute('SELECT id FROM classroom_sessions WHERE attendance_session_id=?',(session_id,)).fetchone()
    if room:
        from .linkage_routes import export_classroom
        return export_classroom(room['id'])
    from .linkage_routes import csv_safe
    stream=io.StringIO(); writer=csv.writer(stream)
    writer.writerow(['学号','姓名','教学班','课堂日期','签到状态','扫码时间','更正时间','更正原因'])
    for r in attendance_rows(get_db(),session_id):
        writer.writerow([csv_safe(v) for v in (r['username'],r['name'],item['class_name'],item['attendance_date'] or '待确认日期',{'normal':'正常','late':'迟到','absent':'未签到'}[r['status']],r['signed_text'],r['changed_text'],r['reason'])])
    return Response('\ufeff'+stream.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="attendance_{session_id}.csv"'})


@bp.get("/statistics")
@role_required("teacher", "admin")
def statistics():
    database = get_db()
    classes = database.execute(
        "SELECT id,display_name,school_year,term,course_name FROM teaching_classes "
        "WHERE archived_at IS NULL ORDER BY school_year DESC,term,course_name,section_no,display_name"
    ).fetchall()
    try:
        selected_class = int(request.args.get("class_id", ""))
    except ValueError:
        selected_class = 0
    class_ids = {row["id"] for row in classes}
    if selected_class not in class_ids:
        selected_class = classes[0]["id"] if classes else 0
    quiz_rows = database.execute(
        """
        SELECT q.id,q.name,q.quiz_date,q.total_score,COUNT(s.id) AS score_count,
               AVG(s.score) AS average_score,MIN(s.score) AS minimum_score,MAX(s.score) AS maximum_score,
               SUM(CASE WHEN s.score>=q.total_score*0.6 THEN 1 ELSE 0 END) AS passed_count
        FROM quizzes q LEFT JOIN scores s ON s.quiz_id=q.id
        WHERE q.class_id=? AND q.published=1 AND q.archived_batch IS NULL
        GROUP BY q.id ORDER BY q.quiz_date,q.id
        """,
        (selected_class,),
    ).fetchall() if selected_class else []
    quizzes = []
    for row in quiz_rows:
        item = dict(row)
        buckets = [0, 0, 0, 0, 0]
        for score in database.execute("SELECT score FROM scores WHERE quiz_id=?", (row["id"],)).fetchall():
            percent = score["score"] / row["total_score"] * 100
            bucket = 0 if percent < 60 else 1 if percent < 70 else 2 if percent < 80 else 3 if percent < 90 else 4
            buckets[bucket] += 1
        item["buckets"] = buckets
        item["pass_rate"] = (row["passed_count"] or 0) / row["score_count"] * 100 if row["score_count"] else 0
        quizzes.append(item)
    students = database.execute(
        """
        SELECT u.username,u.name,COUNT(q.id) AS quiz_count,
               AVG(CASE WHEN q.id IS NOT NULL THEN s.score*100.0/q.total_score END) AS average_rate
        FROM student_classes sc
        JOIN users u ON u.id=sc.student_id
        LEFT JOIN scores s ON s.student_id=u.id
        LEFT JOIN quizzes q ON q.id=s.quiz_id AND q.published=1 AND q.archived_batch IS NULL AND q.class_id=?
        WHERE sc.class_id=? AND sc.status='active' AND u.role='student' AND u.active=1 AND u.archived_at IS NULL
        GROUP BY u.id ORDER BY u.username
        """,
        (selected_class, selected_class),
    ).fetchall() if selected_class else []
    return render_template(
        "teacher/statistics.html", classes=classes, selected_class=selected_class, quizzes=quizzes, students=students
    )
