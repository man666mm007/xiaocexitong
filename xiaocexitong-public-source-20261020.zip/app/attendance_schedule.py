"""Finite Shanghai schedule expansion; callers own transactions for all mutations."""
import datetime
import json
import re
from .timezone import SHANGHAI_TIMEZONE
from .classroom import iso_date, create_classroom_item


def single_occurrence(class_date,start,end,late_minutes):
    day=iso_date(class_date)
    def clock(value):
        if not isinstance(value,str) or not re.fullmatch(r'\d{2}:\d{2}',value): raise ValueError('时间须为 HH:MM')
        return datetime.time.fromisoformat(value)
    begins=datetime.datetime.combine(day,clock(start),tzinfo=SHANGHAI_TIMEZONE)
    ends=datetime.datetime.combine(day,clock(end),tzinfo=SHANGHAI_TIMEZONE)
    minutes=int((ends-begins).total_seconds()/60)
    if minutes<=0: raise ValueError('结束必须晚于开始，不支持跨日')
    if late_minutes is not None and (type(late_minutes)!=int or not 0<=late_minutes<=minutes): raise ValueError('迟到界限必须位于签到窗口内')
    return dict(class_date=class_date,starts_at=int(begins.timestamp()),ends_at=int(ends.timestamp()),late_after=int((begins+datetime.timedelta(minutes=late_minutes)).timestamp()) if late_minutes is not None else int(ends.timestamp()),late_enabled=late_minutes is not None)


def expand_schedule(*,start_date,end_date,week1_monday,slots,weeks,skip_dates):
    start,end,first=(iso_date(x) for x in (start_date,end_date,week1_monday))
    if end<start or (end-start).days>=366: raise ValueError('预约范围须为1—366天')
    if first.weekday()!=0: raise ValueError('第一周周一必须是星期一')
    if weeks is not None and (not isinstance(weeks,list) or not weeks or any(type(w)!=int or not 1<=w<=53 for w in weeks)): raise ValueError('指定周次须为1—53')
    if not isinstance(slots,list) or not 1<=len(slots)<=7: raise ValueError('请设置1—7个星期时间段')
    weekdays=set()
    for slot in slots:
        if not isinstance(slot,dict) or set(slot)!={'weekday','start','end','late_minutes'}: raise ValueError('时间段字段不完整')
        w=slot['weekday']
        if type(w)!=int or not 0<=w<=6 or w in weekdays: raise ValueError('同一星期只能设置一个时间段')
        weekdays.add(w)
        single_occurrence(start_date,slot['start'],slot['end'],slot['late_minutes'])
    if not isinstance(skip_dates,list) or len(skip_dates)>366: raise ValueError('跳过日期格式无效')
    skip={iso_date(d).isoformat() for d in skip_dates}
    result=[]; day=start
    while day<=end:
        week=(day-first).days//7+1
        if 1<=week<=53 and (weeks is None or week in weeks) and day.isoformat() not in skip:
            for slot in slots:
                if day.weekday()==slot['weekday']:
                    result.append(single_occurrence(day.isoformat(),slot['start'],slot['end'],slot['late_minutes']))
        day+=datetime.timedelta(days=1)
    return result


def preview_schedule(database, *, class_id,rule,now,ignore_room_ids=()):
    errors=[]; conflicts=[]; rows=[]; skipped=[]
    if not database.execute('SELECT 1 FROM teaching_classes WHERE id=? AND archived_at IS NULL',(class_id,)).fetchone(): errors.append('教学班不存在或已归档')
    try:
        if not isinstance(rule,dict): raise ValueError('规则格式无效')
        rows=expand_schedule(**rule)
    except (TypeError,ValueError,KeyError) as error:
        errors.append(str(error)); rows=[]
    future=[]
    for row in rows:
        if row['starts_at']<=now:
            skipped.append(row|{'reason':'已经开始或已过去'}); continue
        existing=database.execute('SELECT id FROM classroom_sessions WHERE class_id=? AND class_date=?',(class_id,row['class_date'])).fetchone()
        legacy=database.execute('SELECT 1 FROM quizzes q WHERE q.class_id=? AND q.quiz_date=? AND NOT EXISTS(SELECT 1 FROM classroom_sessions c WHERE c.quiz_id=q.id) UNION SELECT 1 FROM attendance_sessions a WHERE a.class_id=? AND a.attendance_date=? AND NOT EXISTS(SELECT 1 FROM classroom_sessions c WHERE c.attendance_session_id=a.id)',(class_id,row['class_date'],class_id,row['class_date'])).fetchone()
        if (existing and existing['id'] not in ignore_room_ids) or legacy:
            conflicts.append(row['class_date'])
        future.append(row)
    if database.execute('SELECT 1 FROM attendance_sessions WHERE class_id=? AND attendance_date IS NULL',(class_id,)).fetchone(): errors.append('该教学班有待确认日期的历史签到')
    if not future: errors.append('没有可生成的未来日期')
    return dict(occurrences=future,conflicts=conflicts,errors=errors,skipped=skipped)


def _save_rule(database,class_id,rule,actor_id,now):
    return database.execute('INSERT INTO attendance_schedule_rules(class_id,start_date,end_date,week1_monday,slots_json,weeks_json,skip_dates_json,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(class_id,rule['start_date'],rule['end_date'],rule['week1_monday'],json.dumps(rule['slots']),json.dumps(sorted(set(rule['weeks'])) if rule['weeks'] is not None else None),json.dumps(sorted(set(rule['skip_dates']))),actor_id,now)).lastrowid


def _create_occurrence(database,class_id,row,actor_id,rule_id,revision):
    opts=row|dict(schedule_rule_id=rule_id,schedule_revision=revision)
    result=create_classroom_item(database,class_id=class_id,class_date=row['class_date'],kind='attendance',actor_id=actor_id,attendance_options=opts)
    create_classroom_item(database,class_id=class_id,class_date=row['class_date'],kind='quiz',actor_id=actor_id)
    database.execute('UPDATE attendance_sessions SET schedule_origin_date=? WHERE id=?',(row['class_date'],result['item_id']))
    return result['classroom_id']


def confirm_schedule(database, *,preview_batch_id,actor_id,now):
    from .importers import load_batch
    _,payload=load_batch(database,preview_batch_id,actor_id,'attendance_schedule')
    if payload is None: raise ValueError('预约预览不存在或不属于你')
    if payload.get('consumed_at') is not None:
        return dict(rule_id=payload['rule_id'],classroom_ids=payload['classroom_ids'])
    preview=preview_schedule(database,class_id=payload['class_id'],rule=payload['rule'],now=now)
    if preview['errors'] or preview['conflicts']: raise ValueError('；'.join(preview['errors']+['日期冲突：'+d for d in preview['conflicts']]))
    rid=_save_rule(database,payload['class_id'],payload['rule'],actor_id,now)
    rooms=[_create_occurrence(database,payload['class_id'],r,actor_id,rid,1) for r in preview['occurrences']]
    payload.update(consumed_at=now,rule_id=rid,classroom_ids=rooms)
    database.execute('UPDATE import_batches SET payload=? WHERE id=?',(json.dumps(payload),preview_batch_id))
    return dict(rule_id=rid,classroom_ids=rooms)


def _unused(database,room):
    aid,qid=room['attendance_session_id'],room['quiz_id']
    for table,field,value in [('attendance_records','session_id',aid),('attendance_adjustments','session_id',aid),('attendance_adjustment_events','session_id',aid),('scores','quiz_id',qid),('quiz_submissions','quiz_id',qid),('quiz_submission_events','quiz_id',qid)]:
        if database.execute(f'SELECT 1 FROM {table} WHERE {field}=?',(value,)).fetchone(): return False
    q=database.execute('SELECT published,results_confirmed_at FROM quizzes WHERE id=?',(qid,)).fetchone()
    return not q or (not q['published'] and q['results_confirmed_at'] is None)


def _editable(database,room,now):
    att=database.execute('SELECT * FROM attendance_sessions WHERE id=?',(room['attendance_session_id'],)).fetchone()
    cls=database.execute('SELECT archived_at FROM teaching_classes WHERE id=?',(room['class_id'],)).fetchone()
    if not att or not cls or cls['archived_at'] is not None or att['archived_batch'] is not None or att['closed_at'] is not None or att['starts_at']<=now or not _unused(database,room):
        raise ValueError('只能调整尚未开始、未归档且无签到、更正、交卷或成绩的场次')
    return att


def edit_occurrence(database, *,classroom_id,changes,actor_id,now,expected_version):
    room=database.execute('SELECT * FROM classroom_sessions WHERE id=?',(classroom_id,)).fetchone()
    if not room or room['version']!=expected_version: raise ValueError('版本冲突，请刷新')
    if room['state']=='conflict': raise ValueError('请先解决历史冲突')
    att=_editable(database,room,now)
    if changes.get('cancel'):
        database.execute("UPDATE classroom_sessions SET state='cancelled',version=version+1 WHERE id=?",(classroom_id,))
        database.execute('UPDATE attendance_sessions SET cancelled_at=?,active=0,is_exception=1 WHERE id=?',(now,att['id']))
        return
    if changes.get('enable'):
        if room['state']!='cancelled' and att['active']: raise ValueError('该场次已启用')
        database.execute("UPDATE classroom_sessions SET state='ready',version=version+1 WHERE id=?",(classroom_id,))
        database.execute('UPDATE attendance_sessions SET cancelled_at=NULL,active=1,is_exception=1 WHERE id=?',(att['id'],))
        return
    if room['state']!='ready': raise ValueError('请先启用原课堂')
    row=single_occurrence(changes['class_date'],changes['start'],changes['end'],changes['late_minutes'])
    if row['starts_at']<=now: raise ValueError('调整后时间必须尚未开始')
    other=database.execute('SELECT 1 FROM classroom_sessions WHERE class_id=? AND class_date=? AND id<>?',(room['class_id'],row['class_date'],classroom_id)).fetchone()
    legacy=database.execute('SELECT 1 FROM quizzes WHERE class_id=? AND quiz_date=? AND id<>COALESCE(?,-1) UNION SELECT 1 FROM attendance_sessions WHERE class_id=? AND attendance_date=? AND id<>?',(room['class_id'],row['class_date'],room['quiz_id'],room['class_id'],row['class_date'],att['id'])).fetchone()
    if other or legacy: raise ValueError('改期目标日期已有课堂')
    _update_occurrence(database,room,row,exception=True)


def _update_occurrence(database,room,row,exception):
    day=iso_date(row['class_date'])
    database.execute('UPDATE classroom_sessions SET class_date=?,version=version+1 WHERE id=?',(row['class_date'],room['id']))
    database.execute('UPDATE attendance_sessions SET attendance_date=?,title=?,starts_at=?,late_after=?,ends_at=?,late_enabled=?,is_exception=? WHERE id=?',(row['class_date'],f'{day.month}月{day.day}日签到',row['starts_at'],row['late_after'],row['ends_at'],int(row['late_enabled']),int(exception),room['attendance_session_id']))
    database.execute('UPDATE quizzes SET quiz_date=?,name=? WHERE id=?',(row['class_date'],f'{day.month}月{day.day}日小测',room['quiz_id']))


def rule_dict(rule):
    return dict(start_date=rule['start_date'],end_date=rule['end_date'],week1_monday=rule['week1_monday'],slots=json.loads(rule['slots_json']),weeks=json.loads(rule['weeks_json']),skip_dates=json.loads(rule['skip_dates_json']))


def future_rooms(database,rule_id,now):
    return database.execute("SELECT c.*,a.is_exception,a.starts_at,a.archived_batch,a.cancelled_at,a.closed_at FROM classroom_sessions c JOIN attendance_sessions a ON a.id=c.attendance_session_id WHERE a.schedule_rule_id=? AND a.starts_at>? ORDER BY c.class_date",(rule_id,now)).fetchall()


def _revision_plan(database, *,rule_id,effective_date,changes,actor_id,now,expected_revision):
    iso_date(effective_date)
    rule=database.execute('SELECT * FROM attendance_schedule_rules WHERE id=?',(rule_id,)).fetchone()
    if not rule or rule['revision']!=expected_revision or not rule['enabled']: raise ValueError('规则已停用或版本冲突')
    if not database.execute('SELECT 1 FROM teaching_classes WHERE id=? AND archived_at IS NULL',(rule['class_id'],)).fetchone(): raise ValueError('教学班已归档')
    definition=rule_dict(rule)|changes
    all_rows=expand_schedule(**definition)
    targets=[]; protected=[]
    for room in future_rooms(database,rule_id,now):
        if room['class_date']<effective_date: continue
        if room['is_exception'] or room['state']!='ready' or room['archived_batch'] is not None or room['closed_at'] is not None or not _unused(database,room):
            protected.append(room); continue
        _editable(database,room,now); targets.append(room)
    # Dates occupied by a past/started same-rule classroom are never regenerated.
    frozen_dates={r['class_date'] for r in database.execute('SELECT c.class_date FROM classroom_sessions c JOIN attendance_sessions a ON a.id=c.attendance_session_id WHERE a.schedule_rule_id=? AND (a.starts_at<=? OR c.class_date<?)',(rule_id,now,effective_date))}
    origin_dates={r['schedule_origin_date'] for r in database.execute('SELECT schedule_origin_date FROM attendance_sessions WHERE schedule_rule_id=? AND (is_exception=1 OR cancelled_at IS NOT NULL)',(rule_id,)) if r['schedule_origin_date']}
    protected_dates={r['class_date'] for r in protected}|frozen_dates|origin_dates
    wanted=[r for r in all_rows if r['starts_at']>now and r['class_date']>=effective_date and r['class_date'] not in protected_dates]
    target_ids={r['id'] for r in targets}
    conflicts=[]
    for row in wanted:
        other=database.execute('SELECT id FROM classroom_sessions WHERE class_id=? AND class_date=?',(rule['class_id'],row['class_date'])).fetchone()
        legacy=database.execute('SELECT 1 FROM quizzes q WHERE q.class_id=? AND q.quiz_date=? AND NOT EXISTS(SELECT 1 FROM classroom_sessions c WHERE c.quiz_id=q.id) UNION SELECT 1 FROM attendance_sessions a WHERE a.class_id=? AND a.attendance_date=? AND NOT EXISTS(SELECT 1 FROM classroom_sessions c WHERE c.attendance_session_id=a.id)',(rule['class_id'],row['class_date'],rule['class_id'],row['class_date'])).fetchone()
        if (other and other['id'] not in target_ids) or legacy: conflicts.append(row['class_date'])
    return rule,definition,targets,wanted,protected,conflicts


def preview_revision(database, **kwargs):
    try:
        rule,definition,targets,wanted,protected,conflicts=_revision_plan(database,**kwargs)
        dates={r['class_date'] for r in wanted}
        return dict(occurrences=wanted,conflicts=conflicts,errors=[],skipped=[dict(class_date=r['class_date'],reason='保留单独修改、取消或有数据的场次') for r in protected],removed=[r['class_date'] for r in targets if r['class_date'] not in dates])
    except (TypeError,KeyError,ValueError) as error:
        return dict(occurrences=[],conflicts=[],errors=[str(error)],skipped=[],removed=[])


def revise_schedule(database, *,rule_id,effective_date,changes,actor_id,now,expected_revision):
    rule,definition,targets,wanted,protected,conflicts=_revision_plan(database,rule_id=rule_id,effective_date=effective_date,changes=changes,actor_id=actor_id,now=now,expected_revision=expected_revision)
    if conflicts: raise ValueError('规则修订日期冲突：'+ '、'.join(conflicts))
    by_date={r['class_date']:r for r in targets}
    wanted_dates={r['class_date'] for r in wanted}
    revision=rule['revision']+1
    for room in targets:
        if room['class_date'] not in wanted_dates:
            database.execute("UPDATE classroom_sessions SET state='cancelled',version=version+1 WHERE id=?",(room['id'],))
            database.execute('UPDATE attendance_sessions SET cancelled_at=?,active=0,schedule_revision=? WHERE id=?',(now,revision,room['attendance_session_id']))
    for row in wanted:
        if row['class_date'] in by_date:
            room=by_date[row['class_date']]; _update_occurrence(database,room,row,exception=False)
            database.execute('UPDATE attendance_sessions SET schedule_revision=? WHERE id=?',(revision,room['attendance_session_id']))
        else:
            _create_occurrence(database,rule['class_id'],row,actor_id,rule_id,revision)
    database.execute('UPDATE attendance_schedule_rules SET start_date=?,end_date=?,week1_monday=?,slots_json=?,weeks_json=?,skip_dates_json=?,revision=? WHERE id=?',(definition['start_date'],definition['end_date'],definition['week1_monday'],json.dumps(definition['slots']),json.dumps(sorted(set(definition['weeks'])) if definition['weeks'] is not None else None),json.dumps(definition['skip_dates']),revision,rule_id))


def disable_schedule(database, *,rule_id,expected_revision,now):
    rule=database.execute('SELECT * FROM attendance_schedule_rules WHERE id=?',(rule_id,)).fetchone()
    if not rule or rule['revision']!=expected_revision: raise ValueError('版本冲突，请刷新')
    for room in future_rooms(database,rule_id,now):
        if not room['is_exception'] and room['state']=='ready' and room['archived_batch'] is None and _unused(database,room):
            database.execute("UPDATE classroom_sessions SET state='cancelled',version=version+1 WHERE id=?",(room['id'],))
            database.execute('UPDATE attendance_sessions SET active=0,cancelled_at=? WHERE id=?',(now,room['attendance_session_id']))
    database.execute('UPDATE attendance_schedule_rules SET enabled=0,revision=revision+1 WHERE id=?',(rule_id,))
