import hmac
import re
import secrets
from functools import wraps

from flask import abort, flash, g, redirect, request, session, url_for, render_template

# 出错时的处理原则：不给用户看任何错误页面，
# 而是把人送回一个正常页面，并在顶部给一句人话提示。


def _home_url():
    """根据当前身份决定"回家"的地址。"""
    if g.get("user") is None:
        return url_for("auth.login")
    if g.user["role"] == "student":
        return url_for("student.dashboard")
    return url_for("teacher.dashboard")


def _back_or_home():
    """优先回到上一页（仅限本站地址），否则回到首页。"""
    referrer = request.referrer or ""
    if referrer.startswith(request.host_url):
        return referrer
    return _home_url()


def _clean_path():
    """去掉子路径前缀（例如 /quiz），只留下应用内部的路径。"""
    path = request.path or "/"
    root = request.script_root or ""
    if root and path.startswith(root):
        path = path[len(root):] or "/"
    return path


def _explain(code):
    """把错误翻译成一句用户看得懂的话，并给出"去哪"的建议。

    返回 (提示语, 目标地址)；目标地址为 None 时表示回上一页或首页。
    """
    if code == 400:
        return "页面停留时间有点久，安全校验已过期，请重新操作一次。", None
    if code == 403:
        return "你没有权限访问刚才那个页面，已经带你回到自己的主页。", _home_url()
    if code == 405:
        return "刚才那个操作方式不被支持，已经带你回到主页。", _home_url()
    if code == 409:
        return "该内容当前的状态不允许这个操作，请刷新页面后重试。", None
    if code == 413:
        return "上传的文件太大，请压缩后重试。", None
    if code == 500:
        return "系统刚刚出现了一点小问题，请重试一次。", _home_url()
    if code == 404 and g.get("user") is not None:
        try:
            from .db import get_db

            database = get_db()
            path = _clean_path()
            role = g.user["role"]
            if role in ("teacher", "admin"):
                match = re.fullmatch(r"/teacher/quizzes/(\d+)", path)
                if match:
                    row = database.execute(
                        "SELECT name FROM quizzes WHERE id=? AND archived_batch IS NOT NULL",
                        (int(match.group(1)),),
                    ).fetchone()
                    if row is not None:
                        return (
                            f"小测《{row['name']}》已经被移入回收站，可以在左侧「回收站」里恢复。",
                            url_for("teacher.quizzes"),
                        )
                match = re.fullmatch(r"/teacher/attendance/(\d+)", path)
                if match:
                    row = database.execute(
                        "SELECT title FROM attendance_sessions WHERE id=? AND archived_batch IS NOT NULL",
                        (int(match.group(1)),),
                    ).fetchone()
                    if row is not None:
                        return (
                            f"签到《{row['title']}》已经被移入回收站，可以在左侧「回收站」里恢复。",
                            url_for("teacher.attendance"),
                        )
            if role == "student":
                match = re.fullmatch(r"/student/quizzes/(\d+)", path)
                if match:
                    row = database.execute(
                        "SELECT published,archived_batch FROM quizzes WHERE id=?", (int(match.group(1)),)
                    ).fetchone()
                    if row is not None:
                        if row["archived_batch"]:
                            return "这次小测已经下架了，老师重新发布后你就能看到。", url_for("student.quizzes")
                        if not row["published"]:
                            return "这次小测老师还没有发布，发布后你就能看到。", url_for("student.quizzes")
        except Exception:
            pass
    return "刚才那个页面不存在，可能是内容已经被删除，或者网址输错了。", None


def init_security(app):
    @app.before_request
    def verify_csrf():
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
            expected = session.get("csrf_token", "")
            if not expected or not sent or not hmac.compare_digest(str(sent), str(expected)):
                abort(400, description="请求校验失败，请刷新页面后重试。")

    @app.context_processor
    def csrf_context():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_urlsafe(32)
        return {"csrf_token": session["csrf_token"]}

    @app.after_request
    def add_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["Cache-Control"] = "no-store"
        return response

    def _handle(code):
        message, target = _explain(code)
        if (request.endpoint or '').startswith('linkage.') and code in (400,403,409):
            return render_template('teacher/linkage_problem.html',message=message),code
        flash(message, "error")
        return redirect(target or _back_or_home())

    def _make_handler(code):
        def handler(_error):
            return _handle(code)

        handler.__name__ = f"error_handler_{code}"
        return handler

    # 出错时一律不显示错误页面：把人送回一个正常页面，并在顶部给一句提示
    for _code in (400, 403, 404, 405, 409, 413):
        app.register_error_handler(_code, _make_handler(_code))

    @app.errorhandler(500)
    def internal_error(error):
        # 给用户看的是一句轻描淡写的提示，但真实错误要记进控制台方便我们排查
        original = getattr(error, "original_exception", None) or error
        app.logger.error("服务器内部错误: %r", original, exc_info=original)
        return _handle(500)


def _next_target():
    """登录后需要跳回的站内地址。

    扫码签到链接形如 /student/attendance/scan/3?t=xxxx，查询串里的令牌必须保留，
    否则学生登录回来就丢了令牌。request.full_path 会带上 "?" 与查询串。
    """
    return request.full_path if request.query_string else request.path


def login_required(view):
    @wraps(view)
    def wrapped(**kwargs):
        if g.user is None:
            return redirect(url_for("auth.login", next=_next_target()))
        if g.user["must_change_password"] and request.endpoint != "auth.change_password":
            return redirect(url_for("auth.change_password", next=_next_target()))
        return view(**kwargs)

    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(**kwargs):
            if g.user["role"] not in roles:
                abort(403)
            return view(**kwargs)

        return wrapped

    return decorator
