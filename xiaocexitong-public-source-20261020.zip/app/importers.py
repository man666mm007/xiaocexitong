import csv
import io
import json
import math
import re
import uuid
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
from werkzeug.security import generate_password_hash

STUDENT_HEADERS = {
    "student_id": {"student_id", "学号", "账号"},
    "name": {"name", "姓名"},
    "class_name": {"class_name", "班级"},
}
CLASS_ROSTER_HEADERS = {
    "student_id": {"学号"},
    "name": {"姓名"},
    "administrative_class": {"行政班级"},
    "gender": {"性别"},
    "study_type": {"修读性质"},
    "minor_mark": {"辅修标记"},
    "roster_notes": {"备注"},
}
SCORE_HEADERS = {
    "student_id": {"student_id", "学号", "账号"},
    "name": {"name", "姓名", "学生姓名"},
    "score": {"score", "成绩", "得分", "判断题得分"},
    "detail": {"detail", "详情", "逐题详情"},
}
QUESTION_COLUMN_RE = re.compile(r"^(?:判断题|选择题|填空题|题|第|[Qq])?\s*0*(\d+)\s*(?:题)?$")
CORRECT_VALUES = {"1", "1.0", "t", "true", "√", "对", "正确", "y", "yes", "是", "答对"}
WRONG_VALUES = {"-1", "-1.0", "f", "false", "×", "x", "错", "错误", "n", "no", "否", "答错"}
BLANK_VALUES = {"", "-", "—", "n/a", "缺考", "未作答", "未答", "null", "0", "0.0"}
def _header_map(headers, expected):
    normalized = {str(value).strip().lower(): index for index, value in enumerate(headers) if value is not None}
    result = {}
    for target, aliases in expected.items():
        match = next((normalized[a.lower()] for a in aliases if a.lower() in normalized), None)
        if match is not None:
            result[target] = match
    return result


def _question_column_map(headers):
    columns = {}
    for index, value in enumerate(headers):
        if value is None:
            continue
        match = QUESTION_COLUMN_RE.fullmatch(str(value).strip())
        if match:
            columns[index] = int(match.group(1))
    return columns


def _column_index(letters):
    index = 0
    for char in letters:
        index = index * 26 + (ord(char.upper()) - 64)
    return index


_XML_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _read_xlsx_rows(stream):
    """Read XLSX XML directly so malformed dimensions and missing drawings remain supported."""
    try:
        archive = zipfile.ZipFile(stream)
    except zipfile.BadZipFile as exc:
        raise ValueError("Excel 文件无法读取，请确认是有效的 .xlsx 文件") from exc
    with archive:
        names = archive.namelist()
        shared = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            for item in root.findall(_XML_NS + "si"):
                shared.append("".join(node.text or "" for node in item.iter(_XML_NS + "t")))
        sheets = sorted(
            (name for name in names if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", name)),
            key=lambda name: int(re.search(r"(\d+)", name).group(1)),
        )
        if not sheets:
            raise ValueError("Excel 文件里没有找到工作表")
        grid = {}
        for row in ET.fromstring(archive.read(sheets[0])).iter(_XML_NS + "row"):
            cells = {}
            for cell in row.findall(_XML_NS + "c"):
                letters = re.match(r"[A-Z]+", cell.get("r") or "")
                if not letters:
                    continue
                value_node = cell.find(_XML_NS + "v")
                text = ""
                if cell.get("t") == "s" and value_node is not None and value_node.text is not None:
                    shared_index = int(value_node.text)
                    text = shared[shared_index] if 0 <= shared_index < len(shared) else ""
                elif cell.get("t") == "inlineStr":
                    inline = cell.find(_XML_NS + "is")
                    text = "" if inline is None else "".join(node.text or "" for node in inline.iter(_XML_NS + "t"))
                elif value_node is not None and value_node.text is not None:
                    text = value_node.text
                text = text.strip()
                if text:
                    cells[_column_index(letters.group(0))] = text
            if cells:
                grid[int(row.get("r") or 0)] = cells
        if not grid:
            return []
        width = max(max(cells) for cells in grid.values())
        table = []
        for row_number in sorted(grid):
            line = [""] * width
            for index, text in grid[row_number].items():
                line[index - 1] = text
            table.append(line)
        return table


def _read_table(file_storage):
    suffix = Path(file_storage.filename or "").suffix.lower()
    if suffix == ".xlsx":
        return _read_xlsx_rows(file_storage.stream)
    if suffix in (".csv", ".txt"):
        raw = file_storage.stream.read()
        text = None
        for encoding in ("utf-8-sig", "gb18030"):
            try:
                text = raw.decode(encoding)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            raise ValueError("CSV 文件编码无法识别，请在 Excel 里另存为 UTF-8 后重试")
        return [list(row) for row in csv.reader(io.StringIO(text))]
    raise ValueError("仅支持 XLSX 或 CSV 格式的文件")


def _answer_status(value):
    text = str(value).strip().lower()
    if text in BLANK_VALUES:
        return "blank"
    if text in CORRECT_VALUES:
        return "correct"
    if text in WRONG_VALUES:
        return "wrong"
    return None


def parse_students(file_storage):
    values = _read_table(file_storage)
    if not values:
        raise ValueError("学生名单为空")
    mapping = _header_map(values[0], STUDENT_HEADERS)
    if not {"student_id", "name", "class_name"}.issubset(mapping):
        raise ValueError("学生名单需要包含学号、姓名、班级三列")
    rows = []
    for line, raw in enumerate(values[1:], 2):
        def cell(key):
            index = mapping[key]
            return "" if index >= len(raw) or raw[index] is None else str(raw[index]).strip()

        student_id, name, class_name = cell("student_id"), cell("name"), cell("class_name")
        if not student_id and not name and not class_name:
            continue
        errors = []
        if not re.fullmatch(r"\d{5,30}", student_id):
            errors.append("学号应为 5—30 位数字")
        if not name:
            errors.append("姓名为空")
        if not class_name:
            errors.append("名单原始班级为空")
        rows.append(
            {
                "line": line,
                "student_id": student_id,
                "name": name,
                "class_name": class_name,
                "errors": errors,
                "parse_errors": list(errors),
            }
        )
    if not rows:
        raise ValueError("名单中没有学生数据")
    return rows


def _roster_cell_text(cell):
    value = cell.value
    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int, float)):
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        text = str(value)
        number_format = str(cell.number_format or "").split(";", 1)[0]
        if re.fullmatch(r"0{2,}", number_format):
            text = text.zfill(len(number_format))
        return text.strip()
    return str(value).strip()


def _roster_header_map(top, sub=None):
    mapping = {}
    width = max(len(top), len(sub or []))
    for index in range(width):
        first = top[index] if index < len(top) else ""
        second = sub[index] if sub and index < len(sub) else ""
        first = re.sub(r"\s+", "", str(first or "")).lower()
        second = re.sub(r"\s+", "", str(second or "")).lower()
        label = first if not second or first == second else first + second
        for field, aliases in CLASS_ROSTER_HEADERS.items():
            normalized_aliases = {re.sub(r"\s+", "", alias).lower() for alias in aliases}
            if label in normalized_aliases or first in normalized_aliases:
                mapping.setdefault(field, index)
    return mapping


def _roster_has_two_level_header(top, sub):
    for first, second in zip(top, sub):
        first = re.sub(r"\s+", "", str(first or ""))
        second = re.sub(r"\s+", "", str(second or ""))
        if (first, second) in {("修读", "性质"), ("辅修", "标记")}:
            return True
    return False


def parse_class_roster(file_storage):
    """Read a class-creation roster by its headers, independent of sheet name or title rows."""
    if Path(file_storage.filename or "").suffix.lower() != ".xlsx":
        raise ValueError("新建教学班的学生名单仅支持 .xlsx 文件。")
    try:
        workbook = load_workbook(file_storage.stream, read_only=False, data_only=False)
    except (InvalidFileException, zipfile.BadZipFile, OSError, KeyError) as exc:
        raise ValueError("学生名单文件无法读取，请确认它是有效的 .xlsx 工作簿。") from exc

    try:
        candidates = []
        fallback_candidates = []
        for sheet in workbook.worksheets:
            for header_row in range(1, sheet.max_row):
                top = [_roster_cell_text(cell) for cell in sheet[header_row]]
                sub = [_roster_cell_text(cell) for cell in sheet[header_row + 1]]
                direct = _roster_header_map(top)
                combined = _roster_header_map(top, sub)
                if {"student_id", "name"}.issubset(direct):
                    header_end = header_row + 1 if _roster_has_two_level_header(top, sub) else header_row
                    mapping = combined if header_end > header_row else direct
                    candidates.append((sheet, header_end, mapping))
                elif {"student_id", "name"}.issubset(combined):
                    # Keep a two-row fallback for templates that split the required headers too.
                    fallback_candidates.append((sheet, header_row + 1, combined))

        if not candidates:
            candidates = fallback_candidates

        if not candidates:
            raise ValueError("无法识别学生表表头：请确认工作表中包含“学号”和“姓名”列。")
        if len(candidates) > 1:
            raise ValueError("工作簿中识别到多个学生表，请仅保留一个学生名单工作表后重试。")

        sheet, header_end, mapping = candidates[0]
        rows = []
        for line in range(header_end + 1, sheet.max_row + 1):
            cells = sheet[line]

            def cell(field):
                index = mapping.get(field)
                return _roster_cell_text(cells[index]) if index is not None and index < len(cells) else ""

            student_id = cell("student_id")
            name = cell("name")
            administrative_class = cell("administrative_class")
            gender = cell("gender")
            study_type = cell("study_type")
            minor_mark = cell("minor_mark")
            roster_notes = cell("roster_notes")

            # Serial numbers and the date/week attendance grid are not student identifiers.
            if not any((student_id, name, administrative_class, gender, study_type, minor_mark, roster_notes)):
                continue

            errors = []
            if not student_id:
                errors.append("学号为空")
            elif not re.fullmatch(r"\d{5,30}", student_id):
                errors.append("学号应为 5—30 位数字")
            if not name:
                errors.append("姓名为空")
            rows.append({
                "line": line,
                "student_id": student_id,
                "name": name,
                "class_name": administrative_class,
                "administrative_class": administrative_class,
                "gender": gender,
                "study_type": study_type,
                "minor_mark": minor_mark,
                "roster_notes": roster_notes,
                "errors": errors,
                "parse_errors": list(errors),
            })

        if not rows:
            raise ValueError("学生名单中没有可导入的学生数据。")
        return rows
    finally:
        workbook.close()


def _target_for_row(row, mode, target_class_name):
    return row["class_name"] if mode == "legacy" else target_class_name


def validate_students(rows, database, target_class_id=None, target_class_name="", mode="named"):
    seen_counts = {}
    for row in rows:
        row["errors"] = list(row.get("parse_errors", row.get("errors", [])))
        sid = row["student_id"]
        if sid:
            seen_counts[sid] = seen_counts.get(sid, 0) + 1

    existing = {
        row["username"]: dict(row)
        for row in database.execute(
            "SELECT id,username,name,role,active,archived_at FROM users WHERE username IN ("
            + ",".join("?" for sid in seen_counts)
            + ")",
            tuple(seen_counts),
        ).fetchall()
    } if seen_counts else {}
    trashed_names = {
        row["display_name"]
        for row in database.execute("SELECT display_name FROM teaching_classes WHERE archived_at IS NOT NULL").fetchall()
    }

    for row in rows:
        sid = row["student_id"]
        target_name = _target_for_row(row, mode, target_class_name)
        row["target_class_name"] = target_name
        row["target_class_id"] = target_class_id
        row["import_status"] = "new_account"
        if sid and seen_counts.get(sid, 0) > 1:
            row["errors"].append("名单内学号重复")
        if mode == "append":
            if not target_class_id:
                row["errors"].append("未选择有效目标教学班")
            else:
                relation = database.execute(
                    "SELECT status FROM student_classes WHERE student_id=(SELECT id FROM users WHERE username=?) AND class_id=?",
                    (sid, target_class_id),
                ).fetchone()
                if relation and relation["status"] == "active":
                    row["import_status"] = "already_joined"
                elif sid in existing:
                    row["import_status"] = "add_existing"
        elif mode == "legacy" and target_name:
            matches = database.execute(
                "SELECT id FROM teaching_classes WHERE display_name=? AND archived_at IS NULL ORDER BY id",
                (target_name,),
            ).fetchall()
            if len(matches) > 1:
                row["errors"].append("同名教学班不唯一，请从已有教学班选择“追加导入”")
            elif matches:
                row["target_class_id"] = matches[0]["id"]
                relation = database.execute(
                    "SELECT status FROM student_classes WHERE student_id=(SELECT id FROM users WHERE username=?) AND class_id=?",
                    (sid, matches[0]["id"]),
                ).fetchone()
                if relation and relation["status"] == "active":
                    row["import_status"] = "already_joined"
                elif sid in existing:
                    row["import_status"] = "add_existing"
            elif target_name in trashed_names:
                row["errors"].append("同名教学班仍在回收站，请先恢复")

        account = existing.get(sid)
        if account:
            if account["role"] != "student":
                row["errors"].append("该学号已被教师账号占用")
            elif account["archived_at"] is not None or not account["active"]:
                row["errors"].append("该学生账号在全局回收站或已停用，请先恢复账号")
            elif account["name"] != row["name"]:
                row["errors"].append(f"姓名与已有账号不一致（系统为「{account['name']}」），请核对")
            elif row["import_status"] != "already_joined":
                row["import_status"] = "add_existing"
        else:
            row["import_status"] = "new_account"
    return rows


def validate_new_class(database, class_config):
    year = str(class_config.get("school_year", "")).strip()
    term = str(class_config.get("term", "")).strip()
    course = str(class_config.get("course_name", "")).strip()
    section_text = str(class_config.get("section_no", "")).strip()
    if not re.fullmatch(r"\d{2}-\d{2}", year):
        raise ValueError("学年请按 25-26 格式填写")
    start, end = (int(part) for part in year.split("-"))
    if (start + 1) % 100 != end:
        raise ValueError("学年必须由相邻的两个年份组成")
    if term not in {"春", "秋"}:
        raise ValueError("学期请选择春或秋")
    if not course or len(course) > 100:
        raise ValueError("课程名称需为 1—100 个字符")
    if not re.fullmatch(r"[1-9]\d*", section_text):
        raise ValueError("班序号必须为正整数")
    section = int(section_text)
    display_name = f"{year}{term}{course}{section}班"
    exists = database.execute(
        "SELECT id FROM teaching_classes WHERE school_year=? AND term=? AND course_name=? AND section_no=?",
        (year, term, course, section),
    ).fetchone()
    if exists:
        raise ValueError("该学年、学期、课程和班序号已存在，请使用“追加导入”")
    return {
        "school_year": year,
        "term": term,
        "course_name": course,
        "section_no": section,
        "display_name": display_name,
    }


def commit_students(rows, database, mode="named", class_config=None, target_class_id=None):
    """Commit account and membership writes in the caller's transaction."""
    if mode == "named":
        class_config = validate_new_class(database, class_config or {})
        class_id = database.execute(
            """
            INSERT INTO teaching_classes(school_year,term,course_name,section_no,display_name)
            VALUES(?,?,?,?,?)
            """,
            (
                class_config["school_year"],
                class_config["term"],
                class_config["course_name"],
                class_config["section_no"],
                class_config["display_name"],
            ),
        ).lastrowid
        target_ids = {class_config["display_name"]: class_id}
    elif mode == "append":
        item = database.execute(
            "SELECT id FROM teaching_classes WHERE id=? AND archived_at IS NULL", (target_class_id,)
        ).fetchone()
        if item is None:
            raise ValueError("目标教学班已不存在或已归档，请重新预览")
        target_ids = {}
        class_id = item["id"]
    else:
        target_ids = {}
        class_id = None
    legacy_created = 0

    checked = validate_students(
        rows,
        database,
        target_class_id=target_class_id,
        target_class_name=(class_config or {}).get("display_name", ""),
        mode=mode,
    )
    errors = [f"第{row['line']}行：{'；'.join(row['errors'])}" for row in checked if row["errors"]]
    if errors:
        raise ValueError("名单在确认时发生变化，请重新预览。 " + "；".join(errors[:8]))

    if mode == "legacy":
        names = sorted({row["target_class_name"] for row in checked})
        for name in names:
            matches = database.execute(
                "SELECT id FROM teaching_classes WHERE display_name=? AND archived_at IS NULL ORDER BY id",
                (name,),
            ).fetchall()
            if len(matches) > 1:
                raise ValueError(f"名为“{name}”的教学班不唯一，请指定已有教学班")
            if matches:
                target_ids[name] = matches[0]["id"]
            else:
                target_ids[name] = database.execute(
                    "INSERT INTO teaching_classes(display_name,legacy_name) VALUES(?,?)",
                    (name, name),
                ).lastrowid
                legacy_created += 1

    created_accounts = added_memberships = skipped = created_classes = 0
    if mode == "named":
        created_classes = 1
    elif mode == "legacy":
        created_classes = legacy_created

    for row in checked:
        target_id = class_id if mode == "append" else target_ids.get(row["target_class_name"])
        if target_id is None:
            raise ValueError(f"第{row['line']}行的目标教学班不存在")
        user = database.execute(
            "SELECT id,role,name FROM users WHERE username=?", (row["student_id"],)
        ).fetchone()
        if user is None:
            initial = row["student_id"][-6:]
            user_id = database.execute(
                """
                INSERT INTO users(username,name,password_hash,role,class_name,must_change_password,
                                  administrative_class,gender,study_type,minor_mark,roster_notes)
                VALUES(?,?,?,?,?,1,?,?,?,?,?)
                """,
                (
                    row["student_id"],
                    row["name"],
                    generate_password_hash(initial),
                    "student",
                    row["target_class_name"],
                    row.get("administrative_class") or None,
                    row.get("gender") or None,
                    row.get("study_type") or None,
                    row.get("minor_mark") or None,
                    row.get("roster_notes") or None,
                ),
            ).lastrowid
            created_accounts += 1
        else:
            user_id = user["id"]
            if mode == "named":
                database.execute(
                    """
                    UPDATE users SET
                        administrative_class=COALESCE(NULLIF(?,''),administrative_class),
                        gender=COALESCE(NULLIF(?,''),gender),
                        study_type=COALESCE(NULLIF(?,''),study_type),
                        minor_mark=COALESCE(NULLIF(?,''),minor_mark),
                        roster_notes=COALESCE(NULLIF(?,''),roster_notes)
                    WHERE id=?
                    """,
                    (
                        row.get("administrative_class", ""),
                        row.get("gender", ""),
                        row.get("study_type", ""),
                        row.get("minor_mark", ""),
                        row.get("roster_notes", ""),
                        user_id,
                    ),
                )
        relation = database.execute(
            "SELECT status FROM student_classes WHERE student_id=? AND class_id=?",
            (user_id, target_id),
        ).fetchone()
        if relation and relation["status"] == "active":
            skipped += 1
            continue
        database.execute(
            """
            INSERT INTO student_classes(student_id,class_id,status,removed_at) VALUES(?,?,'active',NULL)
            ON CONFLICT(student_id,class_id) DO UPDATE SET status='active',removed_at=NULL
            """,
            (user_id, target_id),
        )
        added_memberships += 1
    return {
        "created_accounts": created_accounts,
        "added_memberships": added_memberships,
        "skipped": skipped,
        "created_classes": created_classes,
    }


def parse_scores(file_storage):
    values = _read_table(file_storage)
    if not values:
        raise ValueError("成绩文件为空")
    header = [str(value).strip() for value in values[0]]
    mapping = _header_map(header, SCORE_HEADERS)
    question_columns = _question_column_map(header)
    if "student_id" not in mapping:
        raise ValueError("成绩文件需要包含学号列（学号 或 student_id）")
    if "score" not in mapping:
        for index, text in enumerate(header):
            if index in question_columns:
                continue
            if any(keyword in text for keyword in ("得分", "总分", "总成绩", "score")):
                mapping["score"] = index
                break
    if "score" not in mapping and not question_columns:
        raise ValueError("成绩文件既没有总分列，也没有逐题列")
    question_numbers = list(question_columns.values())
    duplicate_questions = sorted({number for number in question_numbers if question_numbers.count(number) > 1})
    if not values[1:]:
        raise ValueError("成绩文件没有学生数据")

    rows = []
    for line, raw in enumerate(values[1:], 2):
        raw = ["" if value is None else str(value).strip() for value in raw]

        def cell(key):
            index = mapping.get(key)
            return raw[index] if index is not None and index < len(raw) else ""

        sid, name, score_text, detail = cell("student_id"), cell("name"), cell("score"), cell("detail")
        if not sid and not name and not any((raw[index] if index < len(raw) else "") for index in question_columns):
            continue
        errors = []
        score = None
        if score_text:
            try:
                number = float(score_text)
                if not math.isfinite(number):
                    errors.append(f"第{line}行：总成绩必须是有限数字")
                elif not number.is_integer():
                    errors.append(f"第{line}行：总成绩必须是整数")
                else:
                    score = int(number)
            except (ValueError, OverflowError):
                errors.append(f"第{line}行：总成绩不是有效数字")
        answers = {}
        for index, number in question_columns.items():
            value = raw[index] if index < len(raw) else ""
            if number in duplicate_questions:
                errors.append(f"第{line}行 第{number}题：表头题号重复")
                continue
            status = _answer_status(value)
            if status is None:
                errors.append(f"第{line}行 第{number}题：非法值「{value}」，应为 1、-1、0 或允许的文字别名")
                continue
            answers[number] = status
        correct = sum(status == "correct" for status in answers.values())
        wrong = sum(status == "wrong" for status in answers.values())
        answer_score = correct - wrong
        if answers and score is None:
            score = answer_score
        unsubmitted = bool(answers) and len(answers) == len(question_columns) and all(
            status == "blank" for status in answers.values()
        )
        rows.append(
            {
                "line": line,
                "student_id": sid,
                "name": name,
                "score": score,
                "detail": detail,
                "errors": errors,
                "images": [],
                "answers": answers,
                "unsubmitted": unsubmitted,
                "question_numbers": sorted(set(question_numbers)),
                "duplicate_questions": duplicate_questions,
            }
        )
    if not rows:
        raise ValueError("成绩文件没有有效学生行")
    return rows


def validate_results(rows, quiz, database):
    students = {
        row["username"]: dict(row)
        for row in database.execute(
            """
            SELECT u.id,u.username,u.name,u.role
            FROM users u
            WHERE u.role='student' AND u.active=1 AND u.archived_at IS NULL
            """
        ).fetchall()
    }
    seen = set()
    unsubmitted = []
    kept = []
    is_new_rules = quiz["scoring_mode"] == "negative_marking"
    n = quiz["total_score"]
    valid_n = isinstance(n, (int, float)) and math.isfinite(float(n)) and float(n).is_integer() and n > 0
    expected_numbers = set(range(1, int(n) + 1)) if valid_n and is_new_rules else None

    for row in rows:
        row["errors"] = list(row.get("errors", []))
        sid = row["student_id"]
        student = students.get(sid)
        if not sid:
            row["errors"].append("学号为空")
        if not student:
            row["errors"].append("学号不存在或不是有效学生账号")
        else:
            membership = database.execute(
                "SELECT 1 FROM student_classes WHERE student_id=? AND class_id=? AND status='active'",
                (student["id"], quiz["class_id"]),
            ).fetchone()
            if not membership:
                row["errors"].append("学生未加入本次小测的教学班")
            if row.get("name") and row["name"] != student["name"]:
                row["errors"].append(f"姓名与系统不一致（文件里是「{row['name']}」）")
            row["student_db_id"] = student["id"]
            row["student_name"] = student["name"]
        if sid in seen:
            row["errors"].append("成绩文件内学号重复")
        seen.add(sid)

        score = row.get("score")
        if score is not None:
            try:
                finite = math.isfinite(float(score))
            except (TypeError, ValueError, OverflowError):
                finite = False
            if not finite or not float(score).is_integer():
                row["errors"].append("总成绩必须为有限整数")
            elif valid_n and not -int(n) <= int(score) <= int(n):
                row["errors"].append(f"总成绩越界（应为 {-int(n)} 至 {int(n)}）")
        answers = row.get("answers") or {}
        if answers:
            correct = sum(status == "correct" for status in answers.values())
            wrong = sum(status == "wrong" for status in answers.values())
            computed = correct - wrong
            if score is None:
                row["score"] = computed
                score = computed
            elif int(score) != computed:
                row["errors"].append(f"总成绩 {score} 与逐题合计 {computed} 不一致")
            if is_new_rules:
                if not valid_n:
                    row["errors"].append("本次小测题目数量无效")
                else:
                    file_numbers = set(row.get("question_numbers") or answers.keys())
                    answer_numbers = set(int(number) for number in answers)
                    if file_numbers != expected_numbers:
                        missing = sorted(expected_numbers - file_numbers)
                        extra = sorted(file_numbers - expected_numbers)
                        detail = []
                        if missing:
                            detail.append("缺少题号 " + "、".join(map(str, missing)))
                        if extra:
                            detail.append("超出题号 " + "、".join(map(str, extra)))
                        row["errors"].append("逐题列须完整对应 1 至 N：" + "；".join(detail))
                    if answer_numbers != expected_numbers:
                        missing = sorted(expected_numbers - answer_numbers)
                        extra = sorted(answer_numbers - expected_numbers)
                        detail = []
                        if missing:
                            detail.append("缺少题号 " + "、".join(map(str, missing)))
                        if extra:
                            detail.append("题号无效 " + "、".join(map(str, extra)))
                        row["errors"].append("逐题数据不完整：" + "；".join(detail))
        elif score is None:
            row["errors"].append("这一行既没有总分，也没有逐题结果")

        if is_new_rules and quiz["total_score"] is None and not answers:
            row["errors"].append("首次导入需要完整逐题数据")
        if answers:
            from .submissions import submission_from_answers
            try:
                count=int(n or 0) if is_new_rules else len(row.get('question_numbers') or answers)
                row['submission_status'] = submission_from_answers(answers,count)
            except ValueError:
                if is_new_rules: row['errors'].append('逐题数据不完整或非法')
        else:
            row['submission_status'] = None
        if (row.get("unsubmitted") or row.get("absent")) and not row["errors"]:
            unsubmitted.append(row)
        else:
            kept.append(row)
    return kept, unsubmitted


def save_batch(database, teacher_id, kind, payload, storage_dir=None):
    batch_id = uuid.uuid4().hex
    database.execute(
        "INSERT INTO import_batches(id,teacher_id,kind,payload,storage_dir) VALUES(?,?,?,?,?)",
        (batch_id, teacher_id, kind, json.dumps(payload, ensure_ascii=False), str(storage_dir) if storage_dir else None),
    )
    database.commit()
    return batch_id


def load_batch(database, batch_id, teacher_id, kind):
    row = database.execute(
        "SELECT * FROM import_batches WHERE id=? AND teacher_id=? AND kind=?", (batch_id, teacher_id, kind)
    ).fetchone()
    if row is None:
        return None, None
    return row, json.loads(row["payload"])

