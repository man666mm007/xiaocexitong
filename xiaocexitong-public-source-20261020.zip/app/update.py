"""Teacher-facing fixed-operation page for the local updater agent."""

from __future__ import annotations

from flask import Blueprint, current_app, flash, redirect, render_template, url_for

from .security import role_required
from .updater_client import UpdaterClientError


bp = Blueprint("system_update", __name__)


@bp.get("/teacher/system-update")
@role_required("teacher", "admin")
def page():
    client = current_app.extensions.get("updater_client")
    updater_status = None
    updater_error = ""
    if client is None:
        updater_error = "更新助手尚未安装或尚未配置，请联系管理员。"
    else:
        try:
            updater_status = client.status()
        except UpdaterClientError as exc:
            updater_error = exc.public_message
    return render_template(
        "teacher/system_update.html",
        current_version=current_app.config.get("APP_VERSION", "未知"),
        updater_status=updater_status or {},
        updater_error=updater_error,
    )


@bp.post("/teacher/system-update/check")
@role_required("teacher", "admin")
def check():
    client = current_app.extensions.get("updater_client")
    if client is None:
        flash("更新助手尚未安装或尚未配置，请联系管理员。", "error")
        return redirect(url_for("system_update.page"))
    try:
        client.check()
        flash("已开始检查更新，请稍后刷新页面查看结果。", "success")
    except UpdaterClientError as exc:
        flash(exc.public_message, "error")
    return redirect(url_for("system_update.page"))


@bp.post("/teacher/system-update/install")
@role_required("teacher", "admin")
def install():
    client = current_app.extensions.get("updater_client")
    if client is None:
        flash("更新助手尚未安装或尚未配置，请联系管理员。", "error")
        return redirect(url_for("system_update.page"))
    try:
        client.install()
        flash("更新已开始，网站会短暂不可访问；恢复后请刷新页面查看结果。", "success")
    except UpdaterClientError as exc:
        flash(exc.public_message, "error")
    return redirect(url_for("system_update.page"))
