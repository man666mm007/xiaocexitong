"""Submission classification and auditable, transactional result replacement."""
import json


def submission_from_answers(answers, question_count):
    try:
        normalized = {int(k):v for k,v in answers.items()}
    except (TypeError,ValueError):
        raise ValueError('逐题数据无效')
    if question_count < 1 or len(normalized)!=len(answers) or set(normalized)!=set(range(1,question_count+1)) or any(v not in ('correct','wrong','blank') for v in normalized.values()):
        raise ValueError('逐题数据必须完整、合法且连续')
    return 'unsubmitted' if all(v=='blank' for v in normalized.values()) else 'submitted'


def submission_label(status, *, results_confirmed, legacy_zero=False):
    if status in ('submitted','unsubmitted'):
        return {'submitted':'已交','unsubmitted':'未交'}[status]
    if legacy_zero:
        return '待核查'
    return '无成绩记录' if results_confirmed else '待导入'


def result_snapshot(database, quiz_id, student_id):
    sub = database.execute('SELECT * FROM quiz_submissions WHERE quiz_id=? AND student_id=?',(quiz_id,student_id)).fetchone()
    score = database.execute('SELECT * FROM scores WHERE quiz_id=? AND student_id=?',(quiz_id,student_id)).fetchone()
    return dict(submission=dict(sub) if sub else None,score=dict(score) if score else None,
                answers=[dict(r) for r in database.execute('SELECT * FROM answer_details WHERE score_id=?',(score['id'],))] if score else [],
                images=[dict(r) for r in database.execute('SELECT * FROM quiz_images WHERE score_id=?',(score['id'],))] if score else [])


def apply_submission(database, *, quiz_id, student_id, status, record, batch_id, actor_id, now):
    before = result_snapshot(database,quiz_id,student_id)
    if status is None:
        database.execute('DELETE FROM quiz_submissions WHERE quiz_id=? AND student_id=?',(quiz_id,student_id))
    else:
        database.execute("INSERT INTO quiz_submissions(quiz_id,student_id,status,source,import_batch_id,confirmed_at) VALUES(?,?,?,'import',?,?) ON CONFLICT(quiz_id,student_id) DO UPDATE SET status=excluded.status,source=excluded.source,import_batch_id=excluded.import_batch_id,confirmed_at=excluded.confirmed_at",(quiz_id,student_id,status,batch_id,now))
    current = before['score']
    remove = status == 'unsubmitted' or record.get('remove',False)
    if remove:
        database.execute('DELETE FROM scores WHERE quiz_id=? AND student_id=?',(quiz_id,student_id))
    else:
        if current:
            score_id=current['id']
            database.execute('UPDATE scores SET score=?,detail=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(record['score'],record.get('detail') or None,score_id))
        else:
            score_id=database.execute('INSERT INTO scores(quiz_id,student_id,score,detail) VALUES(?,?,?,?)',(quiz_id,student_id,record['score'],record.get('detail') or None)).lastrowid
        database.execute('DELETE FROM answer_details WHERE score_id=?',(score_id,))
        for number,value in (record.get('answers') or {}).items():
            database.execute('INSERT INTO answer_details(score_id,number,is_correct,answer_status) VALUES(?,?,?,?)',(score_id,int(number),int(value=='correct'),value))
    after = result_snapshot(database,quiz_id,student_id)
    after['imported_answers'] = record.get('answers',{})
    actor = database.execute('SELECT name FROM users WHERE id=?',(actor_id,)).fetchone()
    database.execute('INSERT INTO quiz_submission_events(quiz_id,student_id,actor_id,actor_name,changed_at,import_batch_id,before_json,after_json) VALUES(?,?,?,?,?,?,?,?)',(quiz_id,student_id,actor_id,actor['name'],now,batch_id,json.dumps(before,ensure_ascii=False),json.dumps(after,ensure_ascii=False)))
    return [i['storage_name'] for i in before['images']] if remove else []
