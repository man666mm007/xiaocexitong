"""小测的逐题作答统计。

只统计有成绩记录的学生——未交（完整逐题结果全零）的学生不计入分母，
这样得到的数字和机改系统导出的"判断题得分统计表"完全一致。
"""


def question_statistics(database, quiz_id):
    """返回每道题的：错误作答数 / 未作答数 / 正确作答数 / 总计。"""
    return database.execute(
        """
        SELECT d.number,
               SUM(CASE WHEN d.answer_status = 'wrong' THEN 1 ELSE 0 END) AS wrong_count,
               SUM(CASE WHEN d.answer_status = 'blank' THEN 1 ELSE 0 END) AS blank_count,
               SUM(CASE WHEN d.answer_status = 'correct' THEN 1 ELSE 0 END) AS correct_count,
               COUNT(*) AS total
        FROM answer_details d
        JOIN scores s ON s.id = d.score_id
        WHERE s.quiz_id = ?
        GROUP BY d.number
        ORDER BY d.number
        """,
        (quiz_id,),
    ).fetchall()


def statistics_summary(rows):
    """把逐题统计汇总成一个总览（供页面顶部显示）。"""
    if not rows:
        return None
    return {
        "questions": len(rows),
        "students": max(row["total"] for row in rows),
        "wrong": sum(row["wrong_count"] for row in rows),
        "blank": sum(row["blank_count"] for row in rows),
        "correct": sum(row["correct_count"] for row in rows),
    }
