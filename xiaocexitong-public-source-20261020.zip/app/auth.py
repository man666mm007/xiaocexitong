import datetime
import hashlib
import time

from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from .db import get_db
from .timezone import SHANGHAI_TIMEZONE

bp = Blueprint("auth", __name__)

PENDING_SIGNIN_KEY = "pending_signin"


def _clear_session():
    """清空会话，但保留扫码签到的登记记录。

    学生扫完码可能还要登录、甚至先改初始密码；如果这里把登记一起清掉，
    他回来时二维码早已过期，就会陷入"扫码→登录→过期→再扫码"的死循环。
    """
    pending = session.get(PENDING_SIGNIN_KEY)
    session.clear()
    if pending:
        session[PENDING_SIGNIN_KEY] = pending


def _attempt_key(username):
    remote = request.remote_addr or "unknown"
    return hashlib.sha256(f"{remote}|{username}".encode()).hexdigest()


def _safe_next(target):
    """登录后跳回的站内地址。只接受以单个 / 开头的相对路径，避免开放重定向。"""
    if not target:
        return None
    if not target.startswith("/") or target.startswith("//") or "\\" in target:
        return None
    return target


def _login_url(target):
    return url_for("auth.login", next=target) if target else url_for("auth.login")


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get("user_id")
    g.user = None if user_id is None else get_db().execute(
        "SELECT * FROM users WHERE id = ? AND active = 1 AND archived_at IS NULL", (user_id,)
    ).fetchone()
    if user_id is not None and (g.user is None or session.get("session_version") != g.user["session_version"]):
        session.clear()
        g.user = None


@bp.route("/", methods=("GET", "POST"))
@bp.route("/login", methods=("GET", "POST"))
def login():
    target = _safe_next(request.values.get("next"))
    if g.user is not None:
        endpoint = "student.dashboard" if g.user["role"] == "student" else "teacher.dashboard"
        return redirect(target or url_for(endpoint))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        database = get_db()
        now = int(time.time())
        key = _attempt_key(username)
        attempt = database.execute("SELECT * FROM login_attempts WHERE attempt_key = ?", (key,)).fetchone()
        if attempt and attempt["blocked_until"] > now:
            flash("登录尝试次数过多，请稍后再试。", "error")
            return render_template("auth/login.html", next=target or ""), 429

        user = database.execute("SELECT * FROM users WHERE username = ? AND active = 1 AND archived_at IS NULL", (username,)).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            failures = (attempt["failures"] if attempt and attempt["updated_at"] > now - 900 else 0) + 1
            blocked_until = now + 900 if failures >= 8 else 0
            database.execute(
                "INSERT INTO login_attempts(attempt_key, failures, blocked_until, updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(attempt_key) DO UPDATE SET failures=excluded.failures, blocked_until=excluded.blocked_until, updated_at=excluded.updated_at",
                (key, failures, blocked_until, now),
            )
            database.commit()
            flash("账号或密码错误。", "error")
        else:
            login_date = datetime.datetime.now(SHANGHAI_TIMEZONE).date().isoformat()
            database.execute("BEGIN IMMEDIATE")
            database.execute("DELETE FROM login_attempts WHERE attempt_key = ?", (key,))
            database.execute(
                "INSERT INTO login_daily_counts(login_date,count) VALUES(?,1) "
                "ON CONFLICT(login_date) DO UPDATE SET count=login_daily_counts.count+1",
                (login_date,),
            )
            database.commit()
            _clear_session()
            session["user_id"] = user["id"]
            session["session_version"] = user["session_version"]
            session.permanent = True
            endpoint = "student.dashboard" if user["role"] == "student" else "teacher.dashboard"
            if user["must_change_password"]:
                return redirect(url_for("auth.change_password", next=target) if target else url_for("auth.change_password"))
            return redirect(target or url_for(endpoint))
    return render_template("auth/login.html", next=target or "")


@bp.route("/change-password", methods=("GET", "POST"))
def change_password():
    target = _safe_next(request.values.get("next"))
    if g.user is None:
        return redirect(_login_url(target))
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        if not check_password_hash(g.user["password_hash"], current):
            flash("原密码错误。", "error")
        elif len(new) < 8 or len(new) > 128:
            flash("新密码需要为 8—128 个字符。", "error")
        elif new != confirm:
            flash("两次输入的新密码不一致。", "error")
        elif new == current:
            flash("新密码不能与原密码相同。", "error")
        else:
            database = get_db()
            database.execute(
                "UPDATE users SET password_hash = ?, must_change_password = 0, session_version=session_version+1 WHERE id = ?",
                (generate_password_hash(new), g.user["id"]),
            )
            database.commit()
            _clear_session()
            flash("密码已修改，请重新登录。", "success")
            return redirect(_login_url(target))
    return render_template("auth/change_password.html", next=target or "")


@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
