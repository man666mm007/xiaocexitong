import time

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from . import attendance_qr
from .db import get_db
from .attendance_state import server_now, session_state
from .classroom import classroom_rows
from .submissions import submission_label
from .security import role_required
from .stats import question_statistics, statistics_summary

bp = Blueprint("student", __name__, url_prefix="/student")

@bp.get("/dashboard")
@role_required("student")
def dashboard():
    database = get_db()
    class_names = database.execute(
        "SELECT tc.display_name FROM student_classes sc JOIN teaching_classes tc ON tc.id=sc.class_id "
        "WHERE sc.student_id=? AND sc.status='active' AND tc.archived_at IS NULL "
        "ORDER BY tc.school_year DESC,tc.display_name",
        (g.user["id"],),
    ).fetchall()
    recent = [r for r in _my_quizzes() if r['published']][:5]
    open_attendance=sum(session_state(database,r) in ('open_normal','open_late') for r in database.execute("SELECT a.* FROM attendance_sessions a WHERE EXISTS(SELECT 1 FROM student_classes sc WHERE sc.student_id=? AND sc.class_id=a.class_id AND sc.status='active')",(g.user['id'],)))
    return render_template("student/dashboard.html", recent=recent, open_attendance=open_attendance, class_names=class_names)


def _my_quizzes(quiz_id=None):
    db=get_db()
    rows=db.execute("""SELECT q.*,s.id AS score_id,s.score,s.detail,
        (SELECT COUNT(*) FROM answer_details d WHERE d.score_id=s.id) AS question_count,
        sub.status AS submission_status,c.id AS classroom_id
        FROM quizzes q JOIN teaching_classes tc ON tc.id=q.class_id AND tc.archived_at IS NULL
        LEFT JOIN scores s ON s.quiz_id=q.id AND s.student_id=? AND q.published=1
        LEFT JOIN quiz_submissions sub ON sub.quiz_id=q.id AND sub.student_id=?
        LEFT JOIN classroom_sessions c ON c.quiz_id=q.id
        WHERE q.archived_batch IS NULL AND (c.id IS NULL OR c.state='ready')
        AND EXISTS(SELECT 1 FROM student_classes sc WHERE sc.class_id=q.class_id AND sc.student_id=?)
        AND (? IS NULL OR q.id=?) ORDER BY q.quiz_date DESC,q.id DESC""",(g.user['id'],g.user['id'],g.user['id'],quiz_id,quiz_id)).fetchall()
    result=[]
    for raw in rows:
        row=dict(raw)
        own=classroom_rows(db,classroom_id=row['classroom_id'],student_id=g.user['id']) if row['classroom_id'] else []
        row['participation_label']=own[0]['participation_label'] if own else '待关联签到'
        row['submission_label']=own[0]['submission_label'] if own else submission_label(row['submission_status'],results_confirmed=bool(row['results_confirmed_at']),legacy_zero=row['score']==0 and not row['question_count'])
        if not row['published']:
            row['score']=None; row['detail']=None; row['question_count']=0; row['score_id']=None
        result.append(row)
    return result


@bp.get('/quizzes')
@role_required('student')
def quizzes():
    return render_template('student/quizzes.html',quizzes=_my_quizzes())


@bp.get('/quizzes/<int:quiz_id>')
@role_required('student')
def quiz_detail(quiz_id):
    rows=_my_quizzes(quiz_id)
    if not rows: abort(404)
    score=rows[0]
    answers=get_db().execute('SELECT number,answer_status FROM answer_details WHERE score_id=? ORDER BY number',(score['score_id'],)).fetchall() if score['published'] and score['score_id'] else []
    counts={key:sum(a['answer_status']==key for a in answers) for key in ('correct','wrong','blank')}
    rate=score['score']*100.0/score['total_score'] if score['score'] is not None and score['total_score'] else None
    correct=counts['correct']*100.0/score['total_score'] if answers and score['total_score'] else None
    return render_template('student/quiz_detail.html',score=score,my_answers=answers,my_counts=counts,score_rate=rate,correct_rate=correct)


@bp.get("/quizzes/<int:quiz_id>/statistics")
@role_required("student")
def quiz_statistics(quiz_id):
    """每题作答统计：小测发布后，本班所有学生都能看到（不含机改系统的内部编号）。"""
    database = get_db()
    quiz = database.execute(
        "SELECT q.* FROM quizzes q WHERE q.id=? AND q.published=1 AND q.archived_batch IS NULL "
        "AND EXISTS (SELECT 1 FROM student_classes sc WHERE sc.student_id=? AND sc.class_id=q.class_id)",
        (quiz_id, g.user["id"]),
    ).fetchone()
    if quiz is None:
        abort(404)
    rows = question_statistics(database, quiz_id)
    # 这名学生自己的逐题结果，方便和全班统计对照
    my_results = {
        item["number"]: item["answer_status"]
        for item in database.execute(
            "SELECT d.number, d.answer_status FROM answer_details d JOIN scores s ON s.id=d.score_id "
            "WHERE s.quiz_id=? AND s.student_id=?",
            (quiz_id, g.user["id"]),
        ).fetchall()
    }
    return render_template(
        "student/quiz_statistics.html",
        quiz=quiz,
        rows=rows,
        my_results=my_results,
        summary=statistics_summary(rows),
    )


@bp.get("/attendance")
@role_required("student")
def attendance():
    from .classroom import format_time
    rows=get_db().execute("""SELECT a.*,tc.display_name AS class_name,r.signed_at,
        COALESCE(ad.status,r.status,'absent') AS status
        FROM attendance_sessions a JOIN teaching_classes tc ON tc.id=a.class_id AND tc.archived_at IS NULL
        LEFT JOIN attendance_records r ON r.session_id=a.id AND r.student_id=?
        LEFT JOIN attendance_adjustments ad ON ad.session_id=a.id AND ad.student_id=?
        WHERE a.archived_batch IS NULL AND EXISTS(SELECT 1 FROM student_classes sc WHERE sc.student_id=? AND sc.class_id=a.class_id)
        ORDER BY a.starts_at DESC LIMIT 100""",(g.user['id'],g.user['id'],g.user['id'])).fetchall()
    result=[]
    for raw in rows:
        row=dict(raw); row['state']=session_state(get_db(),row); row['is_open']=row['state'] in ('open_normal','open_late')
        row['starts_text']=format_time(row['starts_at']); row['ends_text']=format_time(row['ends_at'])
        result.append(row)
    return render_template('student/attendance.html',sessions=result)


@bp.get("/attendance/scan/<int:session_id>")
def scan_attendance(session_id):
    """扫码签到入口：链接形如 /student/attendance/scan/3?t=<令牌>。"""
    item = get_db().execute(
        "SELECT * FROM attendance_sessions WHERE id=? AND archived_batch IS NULL", (session_id,)
    ).fetchone()
    if item is None:
        abort(404)
    if session_state(get_db(),item) not in ('open_normal','open_late'):
        flash('本场签到尚未开始或已经结束。','error')
        return redirect(url_for('student.attendance'))
    token = request.args.get("t", "").strip()
    if not attendance_qr.verify_token(item["qr_secret"], session_id, token, moment=server_now()):
        flash("二维码已刷新或已过期，请重新扫描屏幕上的当前二维码。", "error")
        return redirect(url_for("student.attendance"))
    return _finish_scan(item, session_id)


def _finish_scan(item, session_id):
    if g.user is None:
        return redirect(url_for("auth.login", next=request.full_path))
    if g.user["role"] != "student":
        abort(403)
    if g.user["must_change_password"]:
        return redirect(url_for("auth.change_password", next=request.full_path))
    membership = get_db().execute(
        "SELECT 1 FROM student_classes sc JOIN teaching_classes tc ON tc.id=sc.class_id "
        "WHERE sc.student_id=? AND sc.class_id=? AND sc.status='active' AND tc.archived_at IS NULL",
        (g.user["id"], item["class_id"]),
    ).fetchone()
    if not membership:
        abort(404)
    category, message = _record_attendance(item)
    flash(message, category)
    return redirect(url_for("student.attendance"))


def _record_attendance(item):
    """校验并写入扫码签到记录，返回 (flash 类别, 提示语)。"""
    database = get_db()
    database.execute('BEGIN IMMEDIATE')
    try:
        fresh=database.execute('SELECT * FROM attendance_sessions WHERE id=?',(item['id'],)).fetchone()
        state=session_state(database,fresh)
        if state not in ('open_normal','open_late'):
            database.rollback(); return 'error','本场签到尚未开始或已经结束。'
        membership=database.execute("SELECT 1 FROM student_classes WHERE student_id=? AND class_id=? AND status='active'",(g.user['id'],fresh['class_id'])).fetchone()
        if not membership:
            database.rollback(); return 'error','你未加入该教学班。'
        override=database.execute('SELECT status FROM attendance_adjustments WHERE session_id=? AND student_id=?',(item['id'],g.user['id'])).fetchone()
        if override:
            database.rollback(); return 'info','教师已更正你的签到状态：'+{'normal':'正常','late':'迟到','absent':'未签到'}[override['status']]
        existing=database.execute('SELECT id FROM attendance_records WHERE session_id=? AND student_id=?',(item['id'],g.user['id'])).fetchone()
        if existing:
            database.rollback(); return 'error','你已经完成本场签到，不能重复提交。'
        status='late' if state=='open_late' else 'normal'
        database.execute("INSERT INTO attendance_records(session_id,student_id,signed_at,status,source) VALUES(?,?,?,?,'qr')",(item['id'],g.user['id'],server_now(),status))
        database.commit()
        return 'success',('签到成功。' if status=='normal' else '签到成功，系统记录为迟到。')
    except Exception:
        database.rollback(); raise


@bp.get("/statistics")
@role_required("student")
def statistics():
    database = get_db()
    classes = database.execute(
        "SELECT DISTINCT tc.id,tc.display_name FROM student_classes sc JOIN teaching_classes tc ON tc.id=sc.class_id "
        "WHERE sc.student_id=? AND tc.archived_at IS NULL ORDER BY tc.school_year DESC,tc.display_name",
        (g.user["id"],),
    ).fetchall()
    class_ids = {row["id"] for row in classes}
    try:
        selected_class_id = int(request.args.get("class_id", ""))
    except ValueError:
        selected_class_id = 0
    if selected_class_id not in class_ids:
        selected_class_id = next(iter(class_ids), 0)
    rows = database.execute(
        """
        SELECT q.id,q.name,q.quiz_date,q.total_score,q.class_id,tc.display_name AS class_name,
               s.score,s.score*100.0/q.total_score AS rate
        FROM scores s JOIN quizzes q ON q.id=s.quiz_id
        JOIN teaching_classes tc ON tc.id=q.class_id
        WHERE s.student_id=? AND q.class_id=? AND q.published=1 AND q.archived_batch IS NULL
        ORDER BY q.quiz_date,q.id
        """,
        (g.user["id"], selected_class_id),
    ).fetchall()
    rates = [row["rate"] for row in rows]
    summary = {
        "count": len(rates),
        "average": sum(rates) / len(rates) if rates else 0,
        "best": max(rates) if rates else 0,
    }
    points = []
    for index, row in enumerate(rows):
        x = 50 if len(rows) == 1 else 8 + index * 84 / (len(rows) - 1)
        # Keep the plotted value within the displayed 0%–100% axis. The
        # original rate remains available for the summary, table, and tooltip.
        plotted_rate = max(0, min(100, row["rate"]))
        y = 27 - plotted_rate * 0.24
        points.append({"x": round(x, 2), "y": round(y, 2), "rate": row["rate"], "name": row["name"]})
    return render_template(
        "student/statistics.html", scores=rows, summary=summary, points=points, classes=classes,
        selected_class_id=selected_class_id,
        polyline=" ".join(f"{point['x']},{point['y']}" for point in points),
    )
