"""Teacher classroom and schedule request handlers."""
import csv
import io
import json
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for, Response
from .db import get_db
from .security import role_required
from .classroom import classroom_rows, iso_date, ensure_classroom, link_existing
from .attendance_state import adjust_attendance, server_now

bp=Blueprint('linkage',__name__,url_prefix='/teacher')


def _room(rid):
    row=get_db().execute('SELECT c.*,tc.display_name AS class_name,tc.archived_at FROM classroom_sessions c JOIN teaching_classes tc ON tc.id=c.class_id WHERE c.id=?',(rid,)).fetchone()
    if not row: abort(404)
    return row


def _problem(message,status=409):
    return render_template('teacher/linkage_problem.html',message=message),status


@bp.get('/classrooms')
@role_required('teacher','admin')
def classrooms():
    db=get_db()
    rooms=db.execute('SELECT c.*,tc.display_name AS class_name FROM classroom_sessions c JOIN teaching_classes tc ON tc.id=c.class_id WHERE tc.archived_at IS NULL AND (?=\'\' OR CAST(c.class_id AS TEXT)=?) AND (?=\'\' OR c.class_date=?) ORDER BY c.class_date DESC,c.id DESC',(request.args.get('class_id',''),request.args.get('class_id',''),request.args.get('date',''),request.args.get('date',''))).fetchall()
    rooms=[dict(r) for r in rooms]
    for r in rooms:
        rows=classroom_rows(db,classroom_id=r['id'])
        r['total']=len(rows)
        for key,label,column in [('present','参加','participation_label'),('absent','未参加','participation_label'),('submitted','已交','submission_label'),('unsubmitted','未交','submission_label'),('review','待核查','submission_label')]:
            r[key]=sum(row[column]==label for row in rows)
    classes=db.execute('SELECT * FROM teaching_classes WHERE archived_at IS NULL ORDER BY display_name').fetchall()
    return render_template('teacher/classrooms.html',rooms=rooms,classes=classes)


@bp.get('/classrooms/<int:rid>')
@role_required('teacher','admin')
def classroom_detail(rid):
    room=_room(rid)
    rows=classroom_rows(get_db(),classroom_id=rid)
    filt=request.args.get('filter','')
    if filt=='present_unsubmitted': rows=[r for r in rows if r['participation_label']=='参加' and r['submission_label']=='未交']
    elif filt=='absent_submitted': rows=[r for r in rows if r['participation_label']=='未参加' and r['submission_label']=='已交']
    elif filt=='unknown': rows=[r for r in rows if r['submission_label'] in ('待导入','无成绩记录','待核查')]
    events=get_db().execute('SELECT e.*,u.username FROM attendance_adjustment_events e JOIN users u ON u.id=e.student_id WHERE e.session_id=? ORDER BY e.id DESC',(room['attendance_session_id'],)).fetchall()
    return render_template('teacher/classroom_detail.html',room=room,rows=rows,events=events)


def csv_safe(value):
    text='' if value is None else str(value)
    return "'"+text if text.lstrip().startswith(('=','+','-','@','\t','\r')) else text


@bp.get('/classrooms/<int:rid>/export')
@role_required('teacher','admin')
def export_classroom(rid):
    room=_room(rid)
    stream=io.StringIO(); writer=csv.writer(stream)
    writer.writerow(['教学班','课堂日期','学号','姓名','签到状态','参与情况','交卷情况','成绩','补签标记','扫码时间','更正时间','更正原因','说明'])
    for r in classroom_rows(get_db(),classroom_id=rid):
        vals=[room['class_name'],room['class_date'],r['username'],r['name'],{'normal':'正常','late':'迟到','absent':'未签到'}[r['attendance_status']],r['participation_label'],r['submission_label'],r['score'],'教师更正' if r['adjusted'] else '',r['signed_text'],r['changed_text'],r['reason'],r['review_note']]
        writer.writerow([v if i==7 and isinstance(v,(int,float)) else csv_safe(v) for i,v in enumerate(vals)])
    return Response('\ufeff'+stream.getvalue(),mimetype='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="classroom_{rid}.csv"'})


@bp.post('/attendance/<int:session_id>/students/<int:student_id>/adjust')
@role_required('teacher','admin')
def adjust(session_id,student_id):
    db=get_db()
    try:
        db.execute('BEGIN IMMEDIATE')
        adjust_attendance(db,session_id=session_id,student_id=student_id,status=request.form.get('status',''),reason=request.form.get('reason',''),expected_version=int(request.form.get('version','-1')),actor_id=g.user['id'],now=server_now())
        db.commit()
    except ValueError as error:
        db.rollback(); return _problem(str(error))
    return redirect(url_for('teacher.attendance_detail',session_id=session_id))


@bp.post('/classrooms/<int:rid>/review')
@role_required('teacher','admin')
def review_classroom(rid):
    _room(rid)
    note=request.form.get('note','').strip()
    if not note: return _problem('请填写服务中断或停课说明',400)
    db=get_db()
    changed=db.execute('UPDATE classroom_sessions SET needs_review=?,review_note=?,version=version+1 WHERE id=? AND version=?',(int(request.form.get('needs_review','1')=='1'),note,rid,request.form.get('version','-1')))
    if changed.rowcount!=1:
        db.rollback(); return _problem('版本冲突，请刷新')
    db.commit()
    return redirect(url_for('linkage.classroom_detail',rid=rid))


@bp.get('/classrooms/conflicts')
@role_required('teacher','admin')
def classroom_conflicts():
    db=get_db()
    rooms=[dict(r) for r in db.execute("SELECT c.*,tc.display_name AS class_name FROM classroom_sessions c JOIN teaching_classes tc ON tc.id=c.class_id WHERE c.state='conflict'")]
    for r in rooms:
        r['quizzes']=db.execute('SELECT q.*,(SELECT COUNT(*) FROM scores s WHERE s.quiz_id=q.id) AS n FROM quizzes q WHERE class_id=? AND quiz_date=?',(r['class_id'],r['class_date'])).fetchall()
        r['attendances']=db.execute('SELECT a.*,(SELECT COUNT(*) FROM attendance_records ar WHERE ar.session_id=a.id) AS n FROM attendance_sessions a WHERE class_id=? AND attendance_date=?',(r['class_id'],r['class_date'])).fetchall()
    unknown=db.execute('SELECT a.*,tc.display_name AS class_name FROM attendance_sessions a JOIN teaching_classes tc ON tc.id=a.class_id WHERE attendance_date IS NULL').fetchall()
    return render_template('teacher/classroom_conflicts.html',rooms=rooms,unknown=unknown)


@bp.post('/classrooms/<int:rid>/resolve')
@role_required('teacher','admin')
def resolve(rid):
    db=get_db()
    try:
        db.execute('BEGIN IMMEDIATE')
        room=_room(rid)
        if room['state']!='conflict' or int(request.form.get('version','-1'))!=room['version']: raise ValueError('课堂状态已变化，请刷新')
        quiz=int(request.form.get('quiz_id','0')) or None
        att=int(request.form.get('attendance_id','0')) or None
        for table,field,value in [('quizzes','quiz_date',quiz),('attendance_sessions','attendance_date',att)]:
            candidates=db.execute(f'SELECT id FROM {table} WHERE class_id=? AND {field}=?',(room['class_id'],room['class_date'])).fetchall()
            if candidates and value not in {r['id'] for r in candidates}: raise ValueError('请选择正式记录')
        db.execute('UPDATE classroom_sessions SET quiz_id=NULL,attendance_session_id=NULL WHERE id=?',(rid,))
        link_existing(db,classroom_id=rid,quiz_id=quiz,attendance_id=att,actor_id=g.user['id'])
        db.execute("UPDATE classroom_sessions SET state='ready',version=version+1 WHERE id=?",(rid,))
        db.commit()
    except ValueError as error:
        db.rollback(); return _problem(str(error))
    return redirect(url_for('linkage.classroom_detail',rid=rid))


@bp.post('/attendance/<int:sid>/confirm-date')
@role_required('teacher','admin')
def confirm_date(sid):
    db=get_db()
    try:
        date=request.form.get('date',''); iso_date(date)
        db.execute('BEGIN IMMEDIATE')
        att=db.execute('SELECT * FROM attendance_sessions WHERE id=? AND attendance_date IS NULL',(sid,)).fetchone()
        if not att: raise ValueError('日期已确认或记录不存在')
        db.execute('UPDATE attendance_sessions SET attendance_date=? WHERE id=?',(date,sid))
        rid=ensure_classroom(db,class_id=att['class_id'],class_date=date,actor_id=g.user['id'])
        room=_room(rid)
        count=db.execute('SELECT COUNT(*) FROM attendance_sessions WHERE class_id=? AND attendance_date=?',(att['class_id'],date)).fetchone()[0]
        if count>1 or room['attendance_session_id']:
            db.execute("UPDATE classroom_sessions SET state='conflict',version=version+1 WHERE id=?",(rid,))
        else:
            link_existing(db,classroom_id=rid,attendance_id=sid,actor_id=g.user['id'])
        db.commit()
    except ValueError as error:
        db.rollback(); return _problem(str(error),400)
    return redirect(url_for('linkage.classroom_conflicts'))


def _classes():
    return get_db().execute('SELECT * FROM teaching_classes WHERE archived_at IS NULL ORDER BY display_name').fetchall()


def _form_rule():
    if request.form.get('rule_json'):
        return json.loads(request.form['rule_json'])
    mode=request.form.get('week_mode','all')
    weeks=None
    if mode in ('odd','even'): weeks=list(range(1 if mode=='odd' else 2,54,2))
    elif mode=='specified': weeks=sorted({int(n) for n in request.form.get('weeks','').replace('，',',').split(',') if n.strip()})
    slots=[]
    for day in range(7):
        if request.form.get(f'day_{day}'):
            slots.append(dict(weekday=day,start=request.form.get(f'start_{day}',''),end=request.form.get(f'end_{day}',''),late_minutes=None if request.form.get(f'no_late_{day}') else int(request.form.get(f'late_{day}','5'))))
    return dict(start_date=request.form.get('start_date',''),end_date=request.form.get('end_date',''),week1_monday=request.form.get('week1_monday',''),slots=slots,weeks=weeks,skip_dates=[d.strip() for d in request.form.get('skip_dates','').replace('，',',').replace('\n',',').split(',') if d.strip()])


@bp.get('/attendance/schedules')
@role_required('teacher','admin')
def schedules():
    rules=get_db().execute('SELECT r.*,tc.display_name AS class_name FROM attendance_schedule_rules r JOIN teaching_classes tc ON tc.id=r.class_id ORDER BY r.id DESC').fetchall()
    return render_template('teacher/attendance_schedules.html',rules=rules)


@bp.route('/attendance/schedules/create',methods=['GET','POST'])
@role_required('teacher','admin')
def schedule_create():
    from .attendance_schedule import preview_schedule
    from .importers import save_batch
    if request.method=='POST':
        try:
            class_id=int(request.form.get('class_id','0')); rule=_form_rule()
            preview=preview_schedule(get_db(),class_id=class_id,rule=rule,now=server_now())
            if preview['errors']: raise ValueError('；'.join(preview['errors']))
            bid=save_batch(get_db(),g.user['id'],'attendance_schedule',dict(class_id=class_id,rule=rule))
            return redirect(url_for('linkage.schedule_preview',batch_id=bid))
        except (TypeError,ValueError) as error:
            flash(str(error),'error')
    return render_template('teacher/attendance_schedule_form.html',classes=_classes(),rule=None,slots={},schedule=None)


@bp.get('/attendance/schedules/preview/<batch_id>')
@role_required('teacher','admin')
def schedule_preview(batch_id):
    from .attendance_schedule import preview_schedule, future_rooms
    from .importers import load_batch
    _,payload=load_batch(get_db(),batch_id,g.user['id'],'attendance_schedule')
    if payload is None: abort(404)
    if payload.get('operation')=='revise':
        from .attendance_schedule import preview_revision
        preview=preview_revision(get_db(),rule_id=payload['rule_id'],effective_date=payload['effective_date'],changes=payload['rule'],actor_id=g.user['id'],now=server_now(),expected_revision=payload['revision'])
    else:
        preview=preview_schedule(get_db(),class_id=payload['class_id'],rule=payload['rule'],now=server_now())
    return render_template('teacher/attendance_schedule_preview.html',batch_id=batch_id,payload=payload,preview=preview,teaching_class=get_db().execute('SELECT display_name FROM teaching_classes WHERE id=?',(payload['class_id'],)).fetchone())


@bp.post('/attendance/schedules/confirm/<batch_id>')
@role_required('teacher','admin')
def schedule_confirm(batch_id):
    from .attendance_schedule import confirm_schedule, revise_schedule
    from .importers import load_batch
    db=get_db()
    try:
        db.execute('BEGIN IMMEDIATE')
        _,payload=load_batch(db,batch_id,g.user['id'],'attendance_schedule')
        if payload is None: raise ValueError('预览不存在或不属于你')
        if payload.get('operation')=='revise' and payload.get('consumed_at') is None:
            revise_schedule(db,rule_id=payload['rule_id'],effective_date=payload['effective_date'],changes=payload['rule'],actor_id=g.user['id'],now=server_now(),expected_revision=payload['revision'])
            payload['consumed_at']=server_now()
            db.execute('UPDATE import_batches SET payload=? WHERE id=?',(json.dumps(payload),batch_id))
        elif payload.get('operation')!='revise':
            confirm_schedule(db,preview_batch_id=batch_id,actor_id=g.user['id'],now=server_now())
        db.commit()
    except (TypeError,ValueError,KeyError) as error:
        db.rollback(); return _problem(str(error))
    flash('预约已保存，签到与小测草稿已关联。','success')
    return redirect(url_for('linkage.schedules'))


@bp.route('/attendance/schedules/<int:rule_id>/revise',methods=['GET','POST'])
@role_required('teacher','admin')
def schedule_revise(rule_id):
    from .attendance_schedule import rule_dict, expand_schedule
    from .importers import save_batch
    rule=get_db().execute('SELECT * FROM attendance_schedule_rules WHERE id=?',(rule_id,)).fetchone()
    if not rule: abort(404)
    definition=rule_dict(rule)
    if request.method=='POST':
        try:
            definition=_form_rule(); expand_schedule(**definition)
            effective=request.form.get('effective_date',''); iso_date(effective)
            bid=save_batch(get_db(),g.user['id'],'attendance_schedule',dict(class_id=rule['class_id'],rule=definition,operation='revise',rule_id=rule_id,effective_date=effective,revision=int(request.form.get('revision','-1'))))
            return redirect(url_for('linkage.schedule_preview',batch_id=bid))
        except (TypeError,ValueError) as error:
            return _problem(str(error),400)
    return render_template('teacher/attendance_schedule_form.html',classes=_classes(),rule=definition,slots={s['weekday']:s for s in definition['slots']},schedule=rule)


@bp.route('/attendance/schedules/<int:rule_id>/disable',methods=['GET','POST'])
@role_required('teacher','admin')
def schedule_disable(rule_id):
    from .attendance_schedule import disable_schedule, future_rooms, _unused
    db=get_db(); rule=db.execute('SELECT * FROM attendance_schedule_rules WHERE id=?',(rule_id,)).fetchone()
    if not rule: abort(404)
    if request.method=='POST':
        try:
            db.execute('BEGIN IMMEDIATE')
            disable_schedule(db,rule_id=rule_id,expected_revision=int(request.form.get('revision','-1')),now=server_now())
            db.commit()
        except ValueError as error:
            db.rollback(); return _problem(str(error))
        return redirect(url_for('linkage.schedules'))
    rows=[dict(r) for r in future_rooms(db,rule_id,server_now())]
    for r in rows: r['will_cancel']=not r['is_exception'] and r['state']=='ready' and not r['archived_batch'] and _unused(db,r)
    return render_template('teacher/attendance_schedule_disable.html',schedule=rule,rows=rows)


@bp.get('/classrooms/<int:rid>/reschedule')
@role_required('teacher','admin')
def occurrence_edit(rid):
    from .timezone import SHANGHAI_TIMEZONE
    import datetime
    room=_room(rid)
    att=get_db().execute('SELECT * FROM attendance_sessions WHERE id=?',(room['attendance_session_id'],)).fetchone()
    if not att: abort(404)
    def time_text(t): return datetime.datetime.fromtimestamp(t,SHANGHAI_TIMEZONE).strftime('%H:%M')
    return render_template('teacher/attendance_occurrence_edit.html',room=room,att=att,start=time_text(att['starts_at']),end=time_text(att['ends_at']),late_minutes=(att['late_after']-att['starts_at'])//60)


@bp.post('/classrooms/<int:rid>/reschedule')
@bp.post('/classrooms/<int:rid>/cancel',defaults={'operation':'cancel'})
@bp.post('/classrooms/<int:rid>/enable',defaults={'operation':'enable'})
@role_required('teacher','admin')
def occurrence_update(rid,operation='edit'):
    from .attendance_schedule import edit_occurrence
    db=get_db()
    try:
        changes={operation:True} if operation!='edit' else dict(class_date=request.form.get('class_date',''),start=request.form.get('start',''),end=request.form.get('end',''),late_minutes=None if request.form.get('late_disabled') else int(request.form.get('late_minutes','5')))
        db.execute('BEGIN IMMEDIATE')
        edit_occurrence(db,classroom_id=rid,changes=changes,actor_id=g.user['id'],now=server_now(),expected_version=int(request.form.get('version','-1')))
        db.commit()
    except (ValueError,KeyError) as error:
        db.rollback(); return _problem(str(error))
    return redirect(url_for('linkage.classroom_detail',rid=rid))
