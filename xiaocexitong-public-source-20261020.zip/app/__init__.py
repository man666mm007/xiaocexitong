import datetime
import os
import secrets
from datetime import timedelta
from pathlib import Path

from flask import Flask
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.middleware.proxy_fix import ProxyFix

from . import db
from .timezone import SHANGHAI_TIMEZONE
from .auth import bp as auth_bp
from .student import bp as student_bp
from .teacher import bp as teacher_bp
from .health import bp as updater_health_bp
from .update import bp as system_update_bp


def _normalize_prefix(raw):
    """把 QUIZ_URL_PREFIX 规范成 "" 或 "/xxx" 形式。"""
    prefix = (raw or "").strip()
    if not prefix or prefix == "/":
        return ""
    if not prefix.startswith("/"):
        prefix = "/" + prefix
    return prefix.rstrip("/")


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    # 默认把数据放在 instance/；设置 QUIZ_INSTANCE_DIR 可以换到别的目录
    # （交付版用它实现"试用模式"：演示数据放在 instance_demo/，不碰正式数据）
    instance_dir = Path(os.environ.get("QUIZ_INSTANCE_DIR") or app.instance_path)
    secret_key = (test_config or {}).get("SECRET_KEY") or os.environ.get("QUIZ_SECRET_KEY")
    if not secret_key and test_config and test_config.get("TESTING"):
        secret_key = secrets.token_hex(32)
    if not secret_key:
        raise RuntimeError("Set QUIZ_SECRET_KEY before starting the application.")
    app.config.from_mapping(
        SECRET_KEY=secret_key,
        DATABASE=str(instance_dir / "quiz.sqlite3"),
        UPLOAD_ROOT=str(instance_dir / "uploads"),
        PENDING_ROOT=str(instance_dir / "pending"),
        MAX_CONTENT_LENGTH=220 * 1024 * 1024,
        COURSEWARE_URL=os.environ.get("COURSEWARE_URL", ""),
        PUBLIC_BASE_URL=os.environ.get("PUBLIC_BASE_URL", ""),
        URL_PREFIX=_normalize_prefix(os.environ.get("QUIZ_URL_PREFIX", "")),
        APP_VERSION="0.0.0",
        SESSION_COOKIE_NAME="quiz_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("QUIZ_HTTPS", "0") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(days=int(os.environ.get("QUIZ_SESSION_DAYS", "7") or 7)),
    )
    if test_config:
        app.config.update(test_config)
    else:
        try:
            version_text = (Path(__file__).resolve().parents[1] / "VERSION").read_text(encoding="ascii").strip()
            if version_text:
                app.config["APP_VERSION"] = version_text
        except (OSError, UnicodeError):
            pass

    Path(instance_dir).mkdir(parents=True, exist_ok=True)
    Path(app.config["UPLOAD_ROOT"]).mkdir(parents=True, exist_ok=True)
    Path(app.config["PENDING_ROOT"]).mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    with app.app_context():
        db.migrate_db()
    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(teacher_bp)
    app.register_blueprint(updater_health_bp)
    app.register_blueprint(system_update_bp)
    from .linkage_routes import bp as linkage_bp
    app.register_blueprint(linkage_bp)
    from .classroom import format_time
    app.jinja_env.filters["beijing_time"] = format_time

    @app.context_processor
    def inject_login_counts():
        today = datetime.datetime.now(SHANGHAI_TIMEZONE).date().isoformat()
        counts = db.get_db().execute(
            "SELECT COALESCE(SUM(count),0) AS total, "
            "COALESCE(MAX(CASE WHEN login_date=? THEN count END),0) AS today "
            "FROM login_daily_counts",
            (today,),
        ).fetchone()
        return {"login_count_total": counts["total"], "login_count_today": counts["today"]}

    from .security import init_security
    from .updater_client import UpdaterClient

    app.extensions["updater_client"] = UpdaterClient.from_environment()

    init_security(app)

    # 部署在学校现有站点下时的支持：
    # 1) ProxyFix 读取反向代理传来的 X-Forwarded-For / Proto / Host / Prefix（没有代理时无影响）；
    # 2) 设置 QUIZ_URL_PREFIX=/quiz 后，同一份应用会同时挂在 / 和 /quiz/ 下，
    #    生成的链接、静态资源和签到二维码都会自动带上 /quiz 前缀。
    app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {app.config["URL_PREFIX"]: app.wsgi_app}) if app.config["URL_PREFIX"] else app.wsgi_app
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
    return app
