from __future__ import annotations

import base64
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote

from updater.manifest import ManifestError, UpdateManifest, parse_version
from updater.package_builder import PackageBuildError, PackageDigest, build_program_zip
from updater.signatures import SignatureError, _load_private_key, sign_manifest


class ReleaseBuildError(ValueError):
    """Raised when release assets cannot be constructed safely."""


@dataclass(frozen=True, slots=True)
class ReleaseAssets:
    package_path: Path
    manifest_path: Path
    signature_path: Path
    package_digest: PackageDigest


def _is_within(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def _read_project_version(project_root: Path) -> str:
    try:
        raw = (project_root / "VERSION").read_bytes()
        text = raw.decode("ascii")
    except (OSError, UnicodeDecodeError) as exc:
        raise ReleaseBuildError("project VERSION file is missing or invalid") from exc
    lines = text.splitlines()
    if len(lines) != 1 or not lines[0]:
        raise ReleaseBuildError("VERSION must contain exactly one version line")
    try:
        parse_version(lines[0])
    except ManifestError as exc:
        raise ReleaseBuildError("project VERSION is not a supported semantic version") from exc
    return lines[0]


def _validate_build_inputs(
    project_root: Path,
    repository: str,
    tag: str,
    notes: str,
    min_version: str,
    max_version: str,
    required_schema_version: int,
    key_id: str,
    private_key_path: Path,
) -> tuple[str, bytes]:
    project_root = project_root.resolve(strict=True)
    version = _read_project_version(project_root)
    if tag != f"v{version}":
        raise ReleaseBuildError("release tag must be v<project VERSION>")
    try:
        parse_version(min_version)
        parse_version(max_version)
        if parse_version(min_version) > parse_version(max_version):
            raise ReleaseBuildError("compatible version range is inverted")
        if (
            isinstance(required_schema_version, bool)
            or not isinstance(required_schema_version, int)
            or required_schema_version <= 0
        ):
            raise ReleaseBuildError("schema version must be a positive integer")
        if not isinstance(notes, str) or len(notes) > 10000:
            raise ReleaseBuildError("release notes must contain at most 10000 characters")
        if not isinstance(repository, str) or repository.count("/") != 1:
            raise ReleaseBuildError("repository must use owner/name format")

        # Let the same strict parser used by the updater enforce the release
        # contract before any assets are written.
        sample = {
            "version": version,
            "compatible_min": min_version,
            "compatible_max": max_version,
            "notes": notes,
            "tag": tag,
            "repository": repository,
            "package_url": (
                f"https://github.com/{repository}/releases/download/"
                f"{tag}/quiz-program-v{version}.zip"
            ),
            "package_size": 1,
            "package_sha256": "0" * 64,
            "requirements_sha256": "0" * 64,
            "required_schema_version": required_schema_version,
            "key_id": key_id,
        }
        UpdateManifest.from_bytes(
            (json.dumps(sample, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"),
            repository,
            tag,
        )
    except ManifestError as exc:
        raise ReleaseBuildError(f"invalid release metadata: {exc}") from exc

    project_root = project_root.resolve(strict=True)
    try:
        key_path = private_key_path.resolve(strict=True)
    except OSError as exc:
        raise ReleaseBuildError("private key file is missing") from exc
    if _is_within(key_path, project_root):
        raise ReleaseBuildError("private key must be stored outside the project tree")
    try:
        private_pem = key_path.read_bytes()
        _load_private_key(private_pem)
    except (OSError, SignatureError) as exc:
        raise ReleaseBuildError("private key must be a readable RSA-3072-or-stronger PEM") from exc
    return version, private_pem


def _stable_manifest_bytes(
    *,
    version: str,
    repository: str,
    tag: str,
    notes: str,
    min_version: str,
    max_version: str,
    required_schema_version: int,
    key_id: str,
    package_size: int,
    package_sha256: str,
    requirements_sha256: str,
) -> bytes:
    payload = {
        "version": version,
        "compatible_min": min_version,
        "compatible_max": max_version,
        "notes": notes,
        "tag": tag,
        "repository": repository,
        "package_url": (
            f"https://github.com/{repository}/releases/download/"
            f"{quote(tag, safe='.-')}/quiz-program-v{version}.zip"
        ),
        "package_size": package_size,
        "package_sha256": package_sha256,
        "requirements_sha256": requirements_sha256,
        "required_schema_version": required_schema_version,
        "key_id": key_id,
    }
    return (json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True) + "\n").encode("utf-8")


def build_release(
    project_root: Path,
    repository: str,
    tag: str,
    notes: str,
    min_version: str,
    max_version: str,
    required_schema_version: int,
    key_id: str,
    private_key_path: Path,
    output_dir: Path,
) -> ReleaseAssets:
    project_root = Path(project_root).resolve(strict=True)
    version, private_pem = _validate_build_inputs(
        project_root,
        repository,
        tag,
        notes,
        min_version,
        max_version,
        required_schema_version,
        key_id,
        Path(private_key_path),
    )
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    package_name = f"quiz-program-v{version}.zip"
    package_path = output_dir / package_name
    manifest_path = output_dir / "update-manifest.json"
    signature_path = output_dir / "update-manifest.json.sig"

    stage_dir = Path(tempfile.mkdtemp(prefix=".quiz-release-", dir=output_dir))
    try:
        staged_package = stage_dir / package_name
        package_digest = build_program_zip(project_root, staged_package)
        raw_manifest = _stable_manifest_bytes(
            version=version,
            repository=repository,
            tag=tag,
            notes=notes,
            min_version=min_version,
            max_version=max_version,
            required_schema_version=required_schema_version,
            key_id=key_id,
            package_size=package_digest.size,
            package_sha256=package_digest.sha256,
            requirements_sha256=package_digest.requirements_sha256,
        )
        UpdateManifest.from_bytes(raw_manifest, repository, tag)
        signature = sign_manifest(raw_manifest, private_pem)
        (stage_dir / "update-manifest.json").write_bytes(raw_manifest)
        (stage_dir / "update-manifest.json.sig").write_bytes(base64.b64encode(signature) + b"\n")

        os.replace(staged_package, package_path)
        os.replace(stage_dir / "update-manifest.json", manifest_path)
        os.replace(stage_dir / "update-manifest.json.sig", signature_path)
    except (OSError, PackageBuildError, ManifestError, SignatureError) as exc:
        raise ReleaseBuildError("failed to build signed release assets") from exc
    finally:
        try:
            for child in stage_dir.iterdir():
                child.unlink(missing_ok=True)
            stage_dir.rmdir()
        except OSError:
            pass

    return ReleaseAssets(
        package_path=package_path,
        manifest_path=manifest_path,
        signature_path=signature_path,
        package_digest=package_digest,
    )
