"""Manage the Waitress site as a child process of the external agent."""

from __future__ import annotations

import os
import secrets
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Callable, Sequence


class SiteProcessError(RuntimeError):
    pass


class SiteProcessManager:
    def __init__(self, config, command_factory: Callable[[Path], Sequence[str]] | None = None):
        self.config = config
        self._command_factory = command_factory or self._site_command
        self._process: subprocess.Popen | None = None
        self._lock = threading.RLock()
        self.health_token = ""

    def _site_command(self, version_dir: Path) -> Sequence[str]:
        return [str(self.config.python_executable), str(version_dir / "scripts" / "start_server.py")]

    def _child_environment(self) -> dict[str, str]:
        inherited = {
            key: value
            for key, value in os.environ.items()
            if key.upper() in {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "COMSPEC"}
        }
        try:
            secret = Path(self.config.secret_key_path).read_text(encoding="utf-8").strip()
        except (OSError, UnicodeError) as exc:
            raise SiteProcessError("site secret key file cannot be read") from exc
        if not secret:
            raise SiteProcessError("site secret key file is empty")

        inherited.update(dict(self.config.website_environment))
        inherited.update(
            {
                "QUIZ_INSTANCE_DIR": str(self.config.data_root),
                "QUIZ_SECRET_KEY": secret,
                "QUIZ_UPDATER_AGENT_URL": f"http://127.0.0.1:{self.config.agent_port}",
                "QUIZ_UPDATER_AGENT_TOKEN_FILE": str(self.config.agent_token_path),
                "QUIZ_UPDATE_HEALTH_TOKEN": self.health_token,
                "QUIZ_MANAGED_SERVICE": "1",
            }
        )
        return inherited

    @property
    def pid(self) -> int | None:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                return None
            return self._process.pid

    def start(self, version_dir: Path) -> None:
        version_dir = Path(version_dir).resolve(strict=True)
        if not version_dir.is_dir():
            raise SiteProcessError("selected program version directory is missing")
        entry = version_dir / "scripts" / "start_server.py"
        if not entry.is_file():
            raise SiteProcessError("selected program version has no server entry point")
        with self._lock:
            if self._process is not None and self._process.poll() is None:
                raise SiteProcessError("website process is already running")
            self.health_token = secrets.token_urlsafe(32)
            command = list(self._command_factory(version_dir))
            try:
                self._process = subprocess.Popen(
                    command,
                    cwd=str(version_dir),
                    env=self._child_environment(),
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                    close_fds=True,
                )
            except (OSError, ValueError) as exc:
                self._process = None
                raise SiteProcessError("website process could not be started") from exc

    def stop(self, timeout_seconds: int = 30) -> None:
        if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, int) or timeout_seconds < 0:
            raise ValueError("timeout_seconds must be a non-negative integer")
        with self._lock:
            process = self._process
            if process is None or process.poll() is not None:
                self._process = None
                return
            try:
                if os.name == "nt" and hasattr(signal, "CTRL_BREAK_EVENT"):
                    process.send_signal(signal.CTRL_BREAK_EVENT)
                else:
                    process.terminate()
                process.wait(timeout=timeout_seconds)
            except (OSError, subprocess.TimeoutExpired):
                if process.poll() is None:
                    self._terminate_tree(process)
                try:
                    process.wait(timeout=max(5, timeout_seconds))
                except subprocess.TimeoutExpired as exc:
                    raise SiteProcessError("website process did not stop") from exc
            finally:
                if process.poll() is not None:
                    self._process = None

    @staticmethod
    def _terminate_tree(process: subprocess.Popen) -> None:
        if os.name == "nt":
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=10,
                    check=False,
                )
                return
            except (OSError, subprocess.TimeoutExpired):
                pass
        try:
            process.kill()
        except OSError:
            pass

