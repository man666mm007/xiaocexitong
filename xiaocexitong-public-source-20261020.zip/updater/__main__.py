"""Command-line entry point for the standalone updater agent."""

from __future__ import annotations

import argparse
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

from .agent_server import AgentServer
from .config import UpdaterConfig
from .engine import UpdateEngine, read_active_version
from .process_manager import SiteProcessManager
from .release_client import ReleaseClient


SITE_URL = "http://127.0.0.1:5000/quiz/"
READY_TIMEOUT_SECONDS = 45


def _validate_token_acl(path: Path) -> None:
    if sys.platform != "win32":
        return
    try:
        result = subprocess.run(
            ["icacls", str(path)],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError("agent token permissions could not be checked") from exc
    if result.returncode != 0:
        raise RuntimeError("agent token permissions could not be checked")
    permitted = {
        "system": {"system", "nt authority\\system", "s-1-5-18", "*s-1-5-18"},
        "administrators": {"administrators", "builtin\\administrators", "s-1-5-32-544", "*s-1-5-32-544"},
        "network_service": {"network service", "nt authority\\network service", "s-1-5-20", "*s-1-5-20"},
    }
    seen = set()
    for line in result.stdout.splitlines():
        marker = line.rfind(":(")
        if marker < 0:
            continue
        principal_text = line[:marker].strip()
        path_text = str(path)
        if principal_text.casefold().startswith(path_text.casefold()):
            principal_text = principal_text[len(path_text) :].strip().lstrip(":").strip()
        principal = principal_text.casefold()
        category = next((name for name, aliases in permitted.items() if principal in aliases), None)
        if category is None:
            raise RuntimeError("agent token file is accessible to an untrusted principal")
        rights = re.findall(r"\(([^()]*)\)", line[marker + 1 :])
        effective = [right.upper() for right in rights if right.upper() not in {"I", "OI", "CI", "IO", "NP"}]
        if not effective:
            raise RuntimeError("agent token file permissions could not be verified")
        if category == "network_service" and effective[-1] != "R":
            raise RuntimeError("agent token file grants more than read access to the website service")
        if category in {"system", "administrators"} and effective[-1] != "F":
            raise RuntimeError("agent token file administrator permissions are incomplete")
        seen.add(category)
    if seen != set(permitted):
        raise RuntimeError("agent token file permissions could not be verified")


def _open_site() -> int:
    deadline = time.monotonic() + READY_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(SITE_URL, timeout=1) as response:
                if response.status < 500:
                    webbrowser.open(SITE_URL, new=2)
                    return 0
        except urllib.error.HTTPError as exc:
            if exc.code < 500:
                webbrowser.open(SITE_URL, new=2)
                return 0
        except (OSError, urllib.error.URLError):
            pass
        time.sleep(0.5)
    print("本机网站尚未就绪，请确认更新助手已启动。", file=sys.stderr)
    return 1


def _run_agent(config_path: Path) -> int:
    config = UpdaterConfig.load(config_path)
    _validate_token_acl(config.agent_token_path)
    token = config.agent_token_path.read_text(encoding="utf-8").strip()
    public_key = config.public_key_path.read_bytes()
    process_manager = SiteProcessManager(config)
    release_client = ReleaseClient(config.repository, config.key_id, public_key)
    engine = UpdateEngine(config, process_manager, release_client)
    pointer = read_active_version(config.work_root)
    active_dir = Path(config.versions_root) / str(pointer["version"])
    server = AgentServer(
        config.agent_port,
        token,
        status=engine.status,
        check=engine.check,
        install=engine.install,
    )
    server_thread = server.start_in_thread()
    try:
        process_manager.start(active_dir)
        engine._wait_for_health(str(pointer["version"]), int(pointer["required_schema_version"]))
    except Exception:
        try:
            process_manager.stop(timeout_seconds=10)
        except Exception:
            pass
        server.close()
        server_thread.join(timeout=2)
        print("更新助手无法启动网站健康检查。", file=sys.stderr)
        return 1

    stopping = threading.Event()

    def request_stop(_signum, _frame):
        stopping.set()

    previous = {}
    for signum in (signal.SIGINT, getattr(signal, "SIGTERM", signal.SIGINT)):
        try:
            previous[signum] = signal.signal(signum, request_stop)
        except (ValueError, OSError):
            pass
    try:
        stopping.wait()
    finally:
        server.close()
        server_thread.join(timeout=3)
        try:
            process_manager.stop(timeout_seconds=30)
        except Exception:
            print("更新助手停止网站时遇到错误。", file=sys.stderr)
        for signum, handler in previous.items():
            try:
                signal.signal(signum, handler)
            except (ValueError, OSError):
                pass
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Probability Quiz Windows update helper")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--agent", action="store_true", help="run the background update agent")
    mode.add_argument("--open-site", action="store_true", help="wait for the fixed local site and open it")
    parser.add_argument("--config", type=Path, help="absolute path to the protected agent configuration")
    args = parser.parse_args(argv)
    if args.open_site:
        if args.config is not None:
            parser.error("--open-site does not accept or read --config")
        return _open_site()
    if args.agent:
        if args.config is None or not args.config.is_absolute():
            parser.error("--agent requires an absolute --config path")
        return _run_agent(args.config)
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
