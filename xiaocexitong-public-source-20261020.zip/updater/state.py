"""Atomic, secret-free update state stored outside the application database."""

from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path


_PHASES = {
    "idle",
    "checking",
    "checked",
    "downloading",
    "verifying",
    "verified",
    "installing",
    "starting",
    "health_check",
    "succeeded",
    "failed",
    "rolling_back",
    "recovered",
    "recovery_failed",
}
_FIELDS = {
    "phase",
    "current_version",
    "available_version",
    "update_notes",
    "last_checked_at",
    "operation_started_at",
    "last_success_version",
    "last_success_at",
    "message",
}
_WINDOWS_PATH = re.compile(r"(?i)\b[A-Z]:\\[^\s\"']+")
_UNIX_PATH = re.compile(r"(?<!\w)/(?:[^\s/]+/)+[^\s]+")
_BEARER = re.compile(r"(?i)\bbearer\s+\S+")
_SECRET = re.compile(r"(?i)(?:token|secret|private\s*key)\s*[:=]\s*\S+")


@dataclass(frozen=True)
class UpdateState:
    phase: str = "idle"
    current_version: str = ""
    available_version: str = ""
    update_notes: str = ""
    last_checked_at: str = ""
    operation_started_at: str = ""
    last_success_version: str = ""
    last_success_at: str = ""
    message: str = ""

    @classmethod
    def from_mapping(cls, value: object) -> "UpdateState":
        if not isinstance(value, dict) or set(value) - _FIELDS:
            raise ValueError("invalid state schema")
        normalized = {}
        for name in _FIELDS:
            item = value.get(name, "idle" if name == "phase" else "")
            if not isinstance(item, str) or len(item) > 2000:
                raise ValueError("invalid state value")
            normalized[name] = _sanitize(item)
        if normalized["phase"] not in _PHASES:
            raise ValueError("invalid state phase")
        return cls(**normalized)


def _sanitize(value: str) -> str:
    value = _BEARER.sub("Bearer [redacted]", value)
    value = _SECRET.sub("[redacted]", value)
    value = _WINDOWS_PATH.sub("[local path]", value)
    value = _UNIX_PATH.sub("[local path]", value)
    return value[:2000]


def read_state(path: Path) -> UpdateState:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
        return UpdateState.from_mapping(value)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError, TypeError):
        return UpdateState()


def write_state(path: Path, state: UpdateState) -> None:
    if not isinstance(state, UpdateState):
        raise TypeError("state must be UpdateState")
    safe = UpdateState.from_mapping(asdict(state))
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            prefix=f".{target.name}.",
            suffix=".tmp",
            dir=target.parent,
            delete=False,
        ) as handle:
            temp_path = Path(handle.name)
            json.dump(asdict(safe), handle, ensure_ascii=False, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, target)
    except BaseException:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
        raise
