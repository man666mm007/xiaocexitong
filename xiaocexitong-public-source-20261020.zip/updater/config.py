"""Strict, read-only configuration for the Windows update agent."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Mapping
from urllib.parse import urlsplit


_FIELDS = {
    "program_root",
    "data_root",
    "versions_root",
    "work_root",
    "python_executable",
    "repository",
    "public_key_path",
    "key_id",
    "secret_key_path",
    "website_environment",
    "site_url",
    "health_url",
    "agent_port",
    "agent_token_path",
    "backup_retention",
}
_ENV_KEYS = {
    "QUIZ_URL_PREFIX",
    "QUIZ_SESSION_DAYS",
    "QUIZ_HTTPS",
    "PUBLIC_BASE_URL",
    "COURSEWARE_URL",
}
_REPOSITORY = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
_KEY_ID = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")


def _pairs_without_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("configuration contains duplicate JSON keys")
        result[key] = value
    return result


def _absolute_path(value: object, name: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be an absolute path")
    path = Path(value)
    if not path.is_absolute():
        raise ValueError(f"{name} must be an absolute path")
    return path.resolve(strict=False)


def _inside(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def _require_file(path: Path, name: str) -> None:
    if not path.is_file() or path.stat().st_size == 0:
        raise ValueError(f"{name} must name a non-empty file")


@dataclass(frozen=True)
class UpdaterConfig:
    program_root: Path
    data_root: Path
    versions_root: Path
    work_root: Path
    python_executable: Path
    repository: str
    public_key_path: Path
    key_id: str
    secret_key_path: Path
    website_environment: Mapping[str, str]
    site_url: str
    health_url: str
    agent_port: int
    agent_token_path: Path
    backup_retention: int

    @property
    def assistant_root(self) -> Path:
        return self.versions_root.parent

    @property
    def backup_root(self) -> Path:
        return self.assistant_root / "backups"

    @classmethod
    def load(cls, path: Path) -> "UpdaterConfig":
        try:
            raw = json.loads(
                Path(path).read_text(encoding="utf-8"),
                object_pairs_hook=_pairs_without_duplicates,
            )
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError("configuration file is unreadable or invalid JSON") from exc
        if not isinstance(raw, dict) or set(raw) != _FIELDS:
            raise ValueError("configuration fields do not match the supported schema")

        paths = {
            name: _absolute_path(raw[name], name)
            for name in (
                "program_root",
                "data_root",
                "versions_root",
                "work_root",
                "python_executable",
                "public_key_path",
                "secret_key_path",
                "agent_token_path",
            )
        }
        program_root = paths["program_root"]
        data_root = paths["data_root"]
        versions_root = paths["versions_root"]
        work_root = paths["work_root"]
        assistant_root = versions_root.parent

        for name in ("program_root", "data_root"):
            if not paths[name].is_dir():
                raise ValueError(f"{name} must be an existing directory")
        _require_file(paths["python_executable"], "python_executable")
        _require_file(paths["public_key_path"], "public_key_path")
        _require_file(paths["secret_key_path"], "secret_key_path")
        _require_file(paths["agent_token_path"], "agent_token_path")

        if program_root == data_root:
            raise ValueError("program_root and data_root must be different directories")
        if versions_root == assistant_root or work_root == assistant_root:
            raise ValueError("versions_root and work_root must be child directories")
        if not _inside(work_root, assistant_root):
            raise ValueError("work_root must be inside the assistant directory")
        for managed_path in (assistant_root, versions_root, work_root):
            if _inside(managed_path, program_root) or _inside(managed_path, data_root):
                raise ValueError("assistant paths must be outside program and data directories")
            if _inside(program_root, managed_path) or _inside(data_root, managed_path):
                raise ValueError("assistant paths may not contain program or data directories")
        for name in ("public_key_path", "agent_token_path"):
            if not _inside(paths[name], assistant_root):
                raise ValueError(f"{name} must be stored inside the assistant directory")

        repository = raw["repository"]
        if not isinstance(repository, str) or not _REPOSITORY.fullmatch(repository):
            raise ValueError("repository must use GitHub owner/name format")
        key_id = raw["key_id"]
        if not isinstance(key_id, str) or not _KEY_ID.fullmatch(key_id):
            raise ValueError("key_id has an invalid format")

        port = raw["agent_port"]
        if isinstance(port, bool) or not isinstance(port, int) or not 1024 < port <= 65535:
            raise ValueError("agent_port must be between 1025 and 65535")
        retention = raw["backup_retention"]
        if isinstance(retention, bool) or not isinstance(retention, int) or not 1 <= retention <= 20:
            raise ValueError("backup_retention must be between 1 and 20")

        environment = raw["website_environment"]
        if not isinstance(environment, dict) or set(environment) - _ENV_KEYS:
            raise ValueError("website_environment contains unsupported keys")
        if any(not isinstance(k, str) or not isinstance(v, str) for k, v in environment.items()):
            raise ValueError("website_environment values must be strings")

        prefix = environment.get("QUIZ_URL_PREFIX", "/quiz")
        if prefix != "/quiz":
            raise ValueError("the managed website currently requires /quiz")
        site_url = raw["site_url"]
        health_url = raw["health_url"]
        expected_site = "http://127.0.0.1:5000/quiz/"
        expected_health = "http://127.0.0.1:5000/quiz/__updater_health"
        if site_url != expected_site or health_url != expected_health:
            raise ValueError("site_url and health_url must use the fixed local site addresses")
        for value in (site_url, health_url):
            parsed = urlsplit(value)
            if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.port != 5000:
                raise ValueError("health endpoints must use loopback HTTP on port 5000")

        return cls(
            **paths,
            repository=repository,
            key_id=key_id,
            website_environment=MappingProxyType(dict(environment)),
            site_url=site_url,
            health_url=health_url,
            agent_port=port,
            backup_retention=retention,
        )
