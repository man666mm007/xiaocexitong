"""Loopback-only, fixed-operation HTTP API for the Windows update helper."""

from __future__ import annotations

import hmac
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable


_STATUS_FIELDS = {
    "phase",
    "current_version",
    "available_version",
    "update_notes",
    "last_checked_at",
    "operation_started_at",
    "last_success_version",
    "last_success_at",
    "message",
}


class _OperationRunner:
    def __init__(self):
        self._lock = threading.Lock()

    @property
    def busy(self) -> bool:
        return self._lock.locked()

    def schedule(self, operation: Callable[[], object]) -> bool:
        if not self._lock.acquire(blocking=False):
            return False

        def run():
            try:
                operation()
            except Exception:
                # The durable state callback records a sanitized failure reason.
                pass
            finally:
                self._lock.release()

        threading.Thread(target=run, name="quiz-update-operation", daemon=True).start()
        return True


class AgentServer:
    def __init__(
        self,
        port: int,
        token: str,
        status: Callable[[], object],
        check: Callable[[], object],
        install: Callable[[], object],
    ):
        if not token or "\r" in token or "\n" in token:
            raise ValueError("agent token is invalid")
        self.token = token
        self.status_callback = status
        self.check_callback = check
        self.install_callback = install
        self.operations = _OperationRunner()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "QuizUpdaterAgent"
            sys_version = ""

            def log_message(self, format, *args):
                return

            def _json(self, status_code: int, payload: dict):
                raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                self.wfile.write(raw)

            def _authorized(self) -> bool:
                if self.client_address[0] not in {"127.0.0.1", "::1"}:
                    self._json(403, {"error": "local access only"})
                    return False
                header = self.headers.get("Authorization", "")
                if not header.startswith("Bearer ") or not hmac.compare_digest(header[7:], owner.token):
                    self._json(401, {"error": "unauthorized"})
                    return False
                return True

            def do_GET(self):
                if self.path != "/v1/status":
                    self._json(404, {"error": "not found"})
                    return
                if not self._authorized():
                    return
                try:
                    raw = owner.status_callback()
                    if hasattr(raw, "__dataclass_fields__"):
                        from dataclasses import asdict

                        raw = asdict(raw)
                    if not isinstance(raw, dict):
                        raw = {}
                    payload = {key: value for key, value in raw.items() if key in _STATUS_FIELDS and isinstance(value, (str, int, float, bool, type(None)))}
                    payload["operation_busy"] = owner.operations.busy
                    self._json(200, payload)
                except Exception:
                    self._json(503, {"error": "status unavailable"})

            def do_POST(self):
                try:
                    size = int(self.headers.get("Content-Length", "-1"))
                except ValueError:
                    size = -1
                if size < 0 or size > 4096:
                    self.close_connection = True
                    self._json(400, {"error": "invalid request body"})
                    return
                try:
                    body = self.rfile.read(size)
                    if len(body) != size:
                        raise OSError("request body was truncated")
                except OSError:
                    self.close_connection = True
                    self._json(400, {"error": "invalid request body"})
                    return

                routes = {"/v1/check": owner.check_callback, "/v1/install": owner.install_callback}
                operation = routes.get(self.path)
                if operation is None:
                    self._json(404, {"error": "not found"})
                    return
                if not self._authorized():
                    return
                content_type = self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if content_type != "application/json":
                    self._json(415, {"error": "JSON body required"})
                    return
                try:
                    data = json.loads(body.decode("utf-8"))
                except (UnicodeError, json.JSONDecodeError, OSError):
                    self._json(400, {"error": "invalid request body"})
                    return
                if not isinstance(data, dict) or data:
                    self._json(400, {"error": "only an empty JSON object is accepted"})
                    return
                if not owner.operations.schedule(operation):
                    self._json(409, {"error": "an update operation is already running"})
                    return
                self._json(202, {"accepted": True, "operation": self.path.rsplit("/", 1)[-1]})

            def do_PUT(self):
                self._json(405, {"error": "method not allowed"})

            def do_DELETE(self):
                self._json(405, {"error": "method not allowed"})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
        self.httpd.daemon_threads = True
        self.httpd.allow_reuse_address = False

    @property
    def address(self):
        return self.httpd.server_address

    def serve_forever(self):
        self.httpd.serve_forever(poll_interval=0.25)

    def start_in_thread(self) -> threading.Thread:
        thread = threading.Thread(target=self.serve_forever, name="quiz-update-agent-http", daemon=True)
        thread.start()
        return thread

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
