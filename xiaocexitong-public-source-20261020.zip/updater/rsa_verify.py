"""Small standard-library RSA-PSS/SHA-256 verifier for the updater runtime."""

from __future__ import annotations

import base64
import hashlib
import hmac
import re


class SignatureVerificationError(ValueError):
    pass


def _tlv(data: bytes, offset: int = 0) -> tuple[int, bytes, int]:
    if offset + 2 > len(data):
        raise SignatureVerificationError("truncated DER public key")
    tag = data[offset]
    first_length = data[offset + 1]
    cursor = offset + 2
    if first_length < 0x80:
        length = first_length
    else:
        count = first_length & 0x7F
        if count == 0 or count > 4 or cursor + count > len(data):
            raise SignatureVerificationError("invalid DER length")
        if data[cursor] == 0:
            raise SignatureVerificationError("non-canonical DER length")
        length = int.from_bytes(data[cursor : cursor + count], "big")
        if length < 0x80:
            raise SignatureVerificationError("non-canonical DER length")
        cursor += count
    end = cursor + length
    if end > len(data):
        raise SignatureVerificationError("truncated DER public key")
    return tag, data[cursor:end], end


def _positive_integer(data: bytes) -> int:
    tag, value, end = _tlv(data)
    if tag != 0x02 or end != len(data) or not value or value[0] & 0x80:
        raise SignatureVerificationError("invalid RSA integer")
    if len(value) > 1 and value[0] == 0 and not value[1] & 0x80:
        raise SignatureVerificationError("non-canonical RSA integer")
    return int.from_bytes(value, "big")


def _parse_public_key(pem: bytes) -> tuple[int, int]:
    try:
        text = pem.decode("ascii")
    except UnicodeDecodeError as exc:
        raise SignatureVerificationError("public key must be ASCII PEM") from exc
    match = re.fullmatch(
        r"\s*-----BEGIN (PUBLIC KEY|RSA PUBLIC KEY)-----\s*([A-Za-z0-9+/=\r\n]+)\s*-----END \1-----\s*",
        text,
    )
    if match is None:
        raise SignatureVerificationError("public key must be a supported PEM")
    try:
        der = base64.b64decode(re.sub(r"\s+", "", match.group(2)), validate=True)
    except (ValueError, base64.binascii.Error) as exc:
        raise SignatureVerificationError("public key PEM is invalid") from exc

    outer_tag, outer, outer_end = _tlv(der)
    if outer_tag != 0x30 or outer_end != len(der):
        raise SignatureVerificationError("public key DER is invalid")
    if match.group(1) == "RSA PUBLIC KEY":
        rsa_der = outer
    else:
        algorithm_tag, algorithm, cursor = _tlv(outer)
        bit_tag, bit_string, end = _tlv(outer, cursor)
        if algorithm_tag != 0x30 or bit_tag != 0x03 or end != len(outer):
            raise SignatureVerificationError("public key is not RSA SubjectPublicKeyInfo")
        # rsaEncryption OID followed by an optional DER NULL.
        rsa_oid = bytes.fromhex("06092a864886f70d010101")
        if not algorithm.startswith(rsa_oid):
            raise SignatureVerificationError("public key is not RSA")
        if algorithm[len(rsa_oid) :] not in (b"", b"\x05\x00"):
            raise SignatureVerificationError("public key algorithm parameters are invalid")
        if not bit_string or bit_string[0] != 0:
            raise SignatureVerificationError("public key bit string is invalid")
        rsa_der = bit_string[1:]

    rsa_tag, rsa_sequence, rsa_end = _tlv(rsa_der)
    if rsa_tag != 0x30 or rsa_end != len(rsa_der):
        raise SignatureVerificationError("RSA public key is malformed")
    n_tag, n_data, cursor = _tlv(rsa_sequence)
    e_tag, e_data, end = _tlv(rsa_sequence, cursor)
    if n_tag != 0x02 or e_tag != 0x02 or end != len(rsa_sequence):
        raise SignatureVerificationError("RSA public key is malformed")
    n = _positive_integer(_encode_tlv(n_tag, n_data))
    e = _positive_integer(_encode_tlv(e_tag, e_data))
    if n.bit_length() < 3072 or e < 3 or e % 2 == 0:
        raise SignatureVerificationError("public key must be RSA-3072 or stronger")
    return n, e


def _encode_tlv(tag: int, value: bytes) -> bytes:
    size = len(value)
    if size < 0x80:
        prefix = bytes((tag, size))
    else:
        encoded = size.to_bytes((size.bit_length() + 7) // 8, "big")
        prefix = bytes((tag, 0x80 | len(encoded))) + encoded
    return prefix + value


def _mgf1(seed: bytes, length: int) -> bytes:
    output = bytearray()
    for counter in range((length + 31) // 32):
        output.extend(hashlib.sha256(seed + counter.to_bytes(4, "big")).digest())
    return bytes(output[:length])


def verify_rsa_pss_sha256(message: bytes, signature: bytes, public_key_pem: bytes) -> None:
    """Verify RSA-PSS with SHA-256 and the protocol's fixed 32-byte salt."""
    if not isinstance(message, bytes) or not message:
        raise SignatureVerificationError("signed message must be non-empty bytes")
    if not isinstance(signature, bytes) or not signature:
        raise SignatureVerificationError("signature must be non-empty bytes")
    n, e = _parse_public_key(public_key_pem)
    modulus_bits = n.bit_length()
    modulus_bytes = (modulus_bits + 7) // 8
    if len(signature) != modulus_bytes:
        raise SignatureVerificationError("signature has an invalid length")
    signature_int = int.from_bytes(signature, "big")
    if signature_int >= n:
        raise SignatureVerificationError("signature is outside the RSA modulus")

    encoded_message = pow(signature_int, e, n).to_bytes(modulus_bytes, "big")
    em_bits = modulus_bits - 1
    em_len = (em_bits + 7) // 8
    if em_len < 32 + 32 + 2 or len(encoded_message) < em_len:
        raise SignatureVerificationError("RSA modulus is too short for PSS")
    encoded_message = encoded_message[-em_len:]
    masked_db = encoded_message[: em_len - 32 - 1]
    h_value = encoded_message[em_len - 32 - 1 : -1]
    if encoded_message[-1] != 0xBC:
        raise SignatureVerificationError("PSS trailer byte is invalid")
    unused_bits = 8 * em_len - em_bits
    if unused_bits and masked_db[0] & (0xFF << (8 - unused_bits)):
        raise SignatureVerificationError("PSS high bits are invalid")
    db_mask = _mgf1(h_value, len(masked_db))
    database = bytearray(a ^ b for a, b in zip(masked_db, db_mask))
    if unused_bits:
        database[0] &= 0xFF >> unused_bits

    salt_len = 32
    padding_len = em_len - 32 - salt_len - 2
    if padding_len < 0 or database[:padding_len] != b"\x00" * padding_len:
        raise SignatureVerificationError("PSS padding is invalid")
    if database[padding_len] != 0x01:
        raise SignatureVerificationError("PSS separator is invalid")
    salt = bytes(database[-salt_len:])
    message_hash = hashlib.sha256(message).digest()
    expected_h = hashlib.sha256(b"\x00" * 8 + message_hash + salt).digest()
    if not hmac.compare_digest(h_value, expected_h):
        raise SignatureVerificationError("RSA-PSS signature is invalid")
