from __future__ import annotations

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


class SignatureError(ValueError):
    """Raised when a release signing key or signature is invalid."""


def _load_private_key(private_key_pem: bytes) -> rsa.RSAPrivateKey:
    try:
        key = serialization.load_pem_private_key(private_key_pem, password=None)
    except (TypeError, ValueError) as exc:
        raise SignatureError("private key must be a valid unencrypted PEM key") from exc
    if not isinstance(key, rsa.RSAPrivateKey) or key.key_size < 3072:
        raise SignatureError("private key must be RSA-3072 or stronger")
    return key


def _load_public_key(public_key_pem: bytes) -> rsa.RSAPublicKey:
    try:
        key = serialization.load_pem_public_key(public_key_pem)
    except (TypeError, ValueError) as exc:
        raise SignatureError("public key must be a valid PEM key") from exc
    if not isinstance(key, rsa.RSAPublicKey) or key.key_size < 3072:
        raise SignatureError("public key must be RSA-3072 or stronger")
    return key


def sign_manifest(raw: bytes, private_key_pem: bytes) -> bytes:
    if not isinstance(raw, bytes) or not raw:
        raise SignatureError("manifest payload must be non-empty bytes")
    key = _load_private_key(private_key_pem)
    return key.sign(
        raw,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=32,
        ),
        hashes.SHA256(),
    )


def verify_manifest_signature(raw: bytes, signature: bytes, public_key_pem: bytes) -> None:
    if not isinstance(raw, bytes) or not raw:
        raise SignatureError("manifest payload must be non-empty bytes")
    if not isinstance(signature, bytes) or not signature:
        raise SignatureError("signature must be non-empty bytes")
    key = _load_public_key(public_key_pem)
    try:
        key.verify(
            signature,
            raw,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=32,
            ),
            hashes.SHA256(),
        )
    except InvalidSignature as exc:
        raise SignatureError("manifest signature is invalid") from exc
