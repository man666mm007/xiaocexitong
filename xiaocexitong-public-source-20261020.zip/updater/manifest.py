from __future__ import annotations

import json
import re
from dataclasses import dataclass
from urllib.parse import urlsplit


class ManifestError(ValueError):
    """Raised when an update manifest violates the signed release contract."""


_VERSION_RE = re.compile(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\Z")
_REPOSITORY_RE = re.compile(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+\Z")
_KEY_ID_RE = re.compile(r"[A-Za-z0-9_.-]{1,64}\Z")
_SHA256_RE = re.compile(r"[0-9a-fA-F]{64}\Z")
_EXPECTED_FIELDS = frozenset(
    {
        "version",
        "compatible_min",
        "compatible_max",
        "notes",
        "tag",
        "repository",
        "package_url",
        "package_size",
        "package_sha256",
        "requirements_sha256",
        "required_schema_version",
        "key_id",
    }
)
MAX_MANIFEST_BYTES = 1024 * 1024


def parse_version(value: str) -> tuple[int, int, int]:
    if not isinstance(value, str):
        raise ManifestError("version must be a string")
    match = _VERSION_RE.fullmatch(value)
    if match is None:
        raise ManifestError("version must use MAJOR.MINOR.PATCH without leading zeroes")
    return tuple(int(part) for part in match.groups())  # type: ignore[return-value]


def _reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ManifestError(f"duplicate manifest field: {key}")
        result[key] = value
    return result


def _validate_repository(repository: str) -> None:
    if not isinstance(repository, str) or not _REPOSITORY_RE.fullmatch(repository):
        raise ManifestError("repository must use owner/name format")
    if any(part in {".", ".."} for part in repository.split("/")):
        raise ManifestError("repository path is invalid")


def _required_string(data: dict[str, object], field: str, max_length: int) -> str:
    value = data[field]
    if not isinstance(value, str) or not value or len(value) > max_length:
        raise ManifestError(f"{field} must be a non-empty string of at most {max_length} characters")
    return value


def _required_positive_int(data: dict[str, object], field: str) -> int:
    value = data[field]
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ManifestError(f"{field} must be a positive integer")
    return value


def _validate_package_url(url: str, repository: str, tag: str, version: str) -> None:
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ManifestError("package_url is invalid") from exc

    expected_prefix = f"/{repository}/releases/download/{tag}/"
    expected_asset = f"quiz-program-v{version}.zip"
    if (
        parsed.scheme != "https"
        or parsed.hostname != "github.com"
        or parsed.username is not None
        or parsed.password is not None
        or port is not None
        or parsed.query
        or parsed.fragment
        or not parsed.path.startswith(expected_prefix)
        or parsed.path[len(expected_prefix) :] != expected_asset
    ):
        raise ManifestError("package_url must be the fixed GitHub Release asset for this repository and tag")


@dataclass(frozen=True, slots=True)
class UpdateManifest:
    version: str
    compatible_min: str
    compatible_max: str
    notes: str
    tag: str
    repository: str
    package_url: str
    package_size: int
    package_sha256: str
    requirements_sha256: str
    required_schema_version: int
    key_id: str

    @classmethod
    def from_bytes(cls, raw: bytes, repository: str, tag: str) -> "UpdateManifest":
        if not isinstance(raw, bytes) or not raw or len(raw) > MAX_MANIFEST_BYTES:
            raise ManifestError("manifest must be non-empty bytes within the size limit")
        _validate_repository(repository)
        if not isinstance(tag, str) or not tag:
            raise ManifestError("expected release tag is required")

        try:
            decoded = raw.decode("utf-8", errors="strict")
            data = json.loads(decoded, object_pairs_hook=_reject_duplicate_keys)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ManifestError("manifest must be valid UTF-8 JSON") from exc
        if not isinstance(data, dict):
            raise ManifestError("manifest root must be a JSON object")

        actual_fields = frozenset(data)
        missing = _EXPECTED_FIELDS - actual_fields
        unknown = actual_fields - _EXPECTED_FIELDS
        if missing:
            raise ManifestError("manifest is missing required fields")
        if unknown:
            raise ManifestError("manifest contains unknown fields")

        version = _required_string(data, "version", 64)
        compatible_min = _required_string(data, "compatible_min", 64)
        compatible_max = _required_string(data, "compatible_max", 64)
        parse_version(version)
        minimum_tuple = parse_version(compatible_min)
        maximum_tuple = parse_version(compatible_max)
        if minimum_tuple > maximum_tuple:
            raise ManifestError("compatible version range is inverted")

        manifest_tag = _required_string(data, "tag", 128)
        if manifest_tag != tag or manifest_tag != f"v{version}":
            raise ManifestError("release tag does not match the manifest version")

        manifest_repository = _required_string(data, "repository", 256)
        _validate_repository(manifest_repository)
        if manifest_repository != repository:
            raise ManifestError("manifest repository does not match the configured repository")

        package_url = _required_string(data, "package_url", 2048)
        _validate_package_url(package_url, repository, manifest_tag, version)
        package_size = _required_positive_int(data, "package_size")
        required_schema_version = _required_positive_int(data, "required_schema_version")
        package_sha256 = _required_string(data, "package_sha256", 64)
        requirements_sha256 = _required_string(data, "requirements_sha256", 64)
        if not _SHA256_RE.fullmatch(package_sha256):
            raise ManifestError("package_sha256 must be a 64-character hexadecimal SHA-256 digest")
        if not _SHA256_RE.fullmatch(requirements_sha256):
            raise ManifestError("requirements_sha256 must be a 64-character hexadecimal SHA-256 digest")

        notes = data["notes"]
        if not isinstance(notes, str) or len(notes) > 10000:
            raise ManifestError("notes must be a string of at most 10000 characters")
        key_id = _required_string(data, "key_id", 64)
        if not _KEY_ID_RE.fullmatch(key_id):
            raise ManifestError("key_id contains invalid characters")

        return cls(
            version=version,
            compatible_min=compatible_min,
            compatible_max=compatible_max,
            notes=notes,
            tag=manifest_tag,
            repository=manifest_repository,
            package_url=package_url,
            package_size=package_size,
            package_sha256=package_sha256.lower(),
            requirements_sha256=requirements_sha256.lower(),
            required_schema_version=required_schema_version,
            key_id=key_id,
        )
