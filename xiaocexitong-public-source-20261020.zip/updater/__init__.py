"""Standalone update packaging and Windows update-agent components."""

__all__ = ["__version__"]
__version__ = "1.0.0"
