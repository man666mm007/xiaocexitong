"""Fixed-source GitHub Release reader and bounded program-package downloader."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from urllib.parse import urlsplit

from .manifest import MAX_MANIFEST_BYTES, ManifestError, UpdateManifest, parse_version
from .rsa_verify import SignatureVerificationError, verify_rsa_pss_sha256


class ReleaseClientError(RuntimeError):
    pass


class DownloadError(ReleaseClientError):
    pass


class ReleaseTransport(Protocol):
    def open(self, url: str, timeout: float): ...


@dataclass(frozen=True)
class UpdateCandidate:
    manifest: UpdateManifest


class _AllowedRedirectHandler(urllib.request.HTTPRedirectHandler):
    _hosts = {"github.com", "release-assets.githubusercontent.com"}

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parsed = urlsplit(newurl)
        try:
            port = parsed.port
        except ValueError:
            port = -1
        if (
            parsed.scheme != "https"
            or parsed.hostname not in self._hosts
            or parsed.username is not None
            or parsed.password is not None
            or port is not None
        ):
            raise urllib.error.URLError("release redirect host is not allowed")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class UrllibReleaseTransport:
    def __init__(self):
        self._opener = urllib.request.build_opener(_AllowedRedirectHandler())

    def open(self, url: str, timeout: float):
        try:
            return self._opener.open(url, timeout=timeout)
        except urllib.error.HTTPError as response:
            return response


def _allowed_final_url(url: str) -> bool:
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError:
        return False
    return (
        parsed.scheme == "https"
        and parsed.hostname in {"github.com", "release-assets.githubusercontent.com"}
        and parsed.username is None
        and parsed.password is None
        and port is None
    )


def _status(response) -> int:
    return int(getattr(response, "status", getattr(response, "code", 0)) or 0)


def _header(response, name: str) -> str | None:
    headers = getattr(response, "headers", {})
    if hasattr(headers, "get"):
        value = headers.get(name)
    else:
        value = None
    return str(value) if value is not None else None


class ReleaseClient:
    def __init__(
        self,
        repository: str,
        key_id: str,
        public_key_pem: bytes,
        transport: ReleaseTransport | None = None,
        timeout_seconds: float = 30,
        retries: int = 3,
        sleep=time.sleep,
    ):
        if not repository or repository.count("/") != 1:
            raise ValueError("repository must use GitHub owner/name format")
        if retries != 3:
            raise ValueError("release transfers use exactly three bounded attempts")
        self.repository = repository
        self.key_id = key_id
        self.public_key_pem = public_key_pem
        self.transport = transport or UrllibReleaseTransport()
        self.timeout_seconds = timeout_seconds
        self.retries = retries
        self._sleep = sleep

    @property
    def manifest_url(self) -> str:
        return f"https://github.com/{self.repository}/releases/latest/download/update-manifest.json"

    def _read_asset(self, url: str, byte_limit: int, allow_404: bool = False) -> bytes | None:
        last_error: Exception | None = None
        for attempt in range(self.retries):
            response = None
            try:
                response = self.transport.open(url, self.timeout_seconds)
                status = _status(response)
                if status == 404 and allow_404:
                    return None
                if status == 404:
                    raise ReleaseClientError("Release asset is incomplete")
                if status in {408, 425, 429} or 500 <= status <= 599:
                    raise OSError(f"temporary HTTP status {status}")
                if status != 200:
                    raise ReleaseClientError(f"Release server returned HTTP {status}")
                final_url = getattr(response, "url", None)
                if final_url is None and hasattr(response, "geturl"):
                    final_url = response.geturl()
                if not isinstance(final_url, str) or not _allowed_final_url(final_url):
                    raise ReleaseClientError("Release download redirected to an untrusted host")
                declared_length = _header(response, "Content-Length")
                if declared_length is not None:
                    try:
                        length = int(declared_length)
                    except ValueError as exc:
                        raise ReleaseClientError("Release asset length header is invalid") from exc
                    if length < 0 or length > byte_limit:
                        raise ReleaseClientError("Release asset exceeds its size limit")
                output = bytearray()
                while True:
                    block = response.read(64 * 1024)
                    if not block:
                        break
                    output.extend(block)
                    if len(output) > byte_limit:
                        raise ReleaseClientError("Release asset exceeds its size limit")
                if declared_length is not None and len(output) != int(declared_length):
                    raise OSError("Release asset was truncated")
                return bytes(output)
            except ReleaseClientError:
                raise
            except (OSError, TimeoutError, urllib.error.URLError) as exc:
                last_error = exc
                if attempt + 1 < self.retries:
                    self._sleep(min(0.25 * (2**attempt), 1.0))
            finally:
                if response is not None:
                    try:
                        response.close()
                    except Exception:
                        pass
        raise ReleaseClientError("Release download failed after three attempts") from last_error

    def latest(self, current_version: str) -> UpdateCandidate | None:
        try:
            parse_version(current_version)
        except ManifestError as exc:
            raise ReleaseClientError("installed version is invalid") from exc
        raw_manifest = self._read_asset(self.manifest_url, MAX_MANIFEST_BYTES, allow_404=True)
        if raw_manifest is None:
            return None
        signature_url = self.manifest_url + ".sig"
        raw_signature = self._read_asset(signature_url, 8192)
        assert raw_signature is not None
        try:
            signature = base64.b64decode(raw_signature.strip(), validate=True)
            verify_rsa_pss_sha256(raw_manifest, signature, self.public_key_pem)
            data = json.loads(raw_manifest.decode("utf-8"))
            tag = data["tag"]
            manifest = UpdateManifest.from_bytes(raw_manifest, self.repository, tag)
        except (ValueError, KeyError, TypeError, UnicodeError, json.JSONDecodeError, ManifestError, SignatureVerificationError) as exc:
            raise ReleaseClientError("Release manifest signature or contract is invalid") from exc
        if manifest.key_id != self.key_id:
            raise ReleaseClientError("Release manifest uses an unconfigured signing key")
        installed = parse_version(current_version)
        candidate_version = parse_version(manifest.version)
        if candidate_version <= installed:
            return None
        if not parse_version(manifest.compatible_min) <= installed <= parse_version(manifest.compatible_max):
            raise ReleaseClientError("Release is not compatible with the installed version")
        return UpdateCandidate(manifest=manifest)

    def download(self, candidate: UpdateCandidate, destination: Path) -> Path:
        manifest = candidate.manifest
        target = Path(destination)
        target.parent.mkdir(parents=True, exist_ok=True)
        last_error: Exception | None = None
        for attempt in range(self.retries):
            response = None
            temp_path: Path | None = None
            try:
                response = self.transport.open(manifest.package_url, self.timeout_seconds)
                status = _status(response)
                if status in {408, 425, 429} or 500 <= status <= 599:
                    raise OSError(f"temporary HTTP status {status}")
                if status != 200:
                    raise DownloadError(f"Package server returned HTTP {status}")
                final_url = getattr(response, "url", None)
                if final_url is None and hasattr(response, "geturl"):
                    final_url = response.geturl()
                if not isinstance(final_url, str) or not _allowed_final_url(final_url):
                    raise DownloadError("Package download redirected to an untrusted host")
                declared_length = _header(response, "Content-Length")
                if declared_length is not None and declared_length != str(manifest.package_size):
                    raise OSError("Package length does not match the signed manifest")
                digest = hashlib.sha256()
                received = 0
                with tempfile.NamedTemporaryFile(
                    mode="wb", prefix=f".{target.name}.", suffix=".part", dir=target.parent, delete=False
                ) as handle:
                    temp_path = Path(handle.name)
                    while True:
                        block = response.read(64 * 1024)
                        if not block:
                            break
                        received += len(block)
                        if received > manifest.package_size:
                            raise DownloadError("Package exceeds its signed size")
                        digest.update(block)
                        handle.write(block)
                    handle.flush()
                    os.fsync(handle.fileno())
                if received != manifest.package_size:
                    raise OSError("Package download was truncated")
                if digest.hexdigest() != manifest.package_sha256:
                    raise DownloadError("Package SHA-256 does not match the signed manifest")
                os.replace(temp_path, target)
                temp_path = None
                return target
            except DownloadError:
                raise
            except (OSError, TimeoutError, urllib.error.URLError) as exc:
                last_error = exc
                if attempt + 1 < self.retries:
                    self._sleep(min(0.25 * (2**attempt), 1.0))
            finally:
                if response is not None:
                    try:
                        response.close()
                    except Exception:
                        pass
                if temp_path is not None:
                    try:
                        temp_path.unlink(missing_ok=True)
                    except OSError:
                        pass
        raise DownloadError("Package download failed after three attempts") from last_error
