"""Strict ZIP preflight and extraction for signed program-only update packages."""

from __future__ import annotations

import hashlib
import shutil
import stat
import zipfile
from pathlib import Path, PurePosixPath


class ArchiveValidationError(ValueError):
    pass


class DependencyChangeError(ArchiveValidationError):
    pass


MAX_ARCHIVE_FILES = 10_000
MAX_UNPACKED_BYTES = 512 * 1024 * 1024
MAX_FILE_BYTES = 220 * 1024 * 1024
_ROOT_FILES = {
    "scripts/start_server.py",
    "run.py",
    "wsgi.py",
    "requirements.txt",
    "VERSION",
}
_RESERVED_NAMES = {"con", "prn", "aux", "nul"} | {
    f"{prefix}{number}" for prefix in ("com", "lpt") for number in range(1, 10)
}


def _program_path(name: str) -> PurePosixPath:
    if not isinstance(name, str) or not name or "\\" in name or "\x00" in name or ":" in name:
        raise ArchiveValidationError("ZIP contains an invalid path")
    path = PurePosixPath(name)
    if path.is_absolute() or path.as_posix() != name or any(part in {"", ".", ".."} for part in path.parts):
        raise ArchiveValidationError("ZIP contains an unsafe path")
    for part in path.parts:
        if part.endswith((".", " ")) or part.split(".", 1)[0].casefold() in _RESERVED_NAMES:
            raise ArchiveValidationError("ZIP contains a Windows-reserved path")
    allowed = name.startswith("app/") and len(path.parts) > 1 or name in _ROOT_FILES
    if not allowed:
        raise ArchiveValidationError("ZIP contains a path outside the program allowlist")
    return path


def _preflight(archive: zipfile.ZipFile, requirements_sha256: str) -> list[zipfile.ZipInfo]:
    infos = archive.infolist()
    if not infos or len(infos) > MAX_ARCHIVE_FILES:
        raise ArchiveValidationError("ZIP has an invalid number of files")
    names: set[str] = set()
    total = 0
    requirements_digest = None
    for info in infos:
        if info.is_dir():
            raise ArchiveValidationError("ZIP directory entries are not supported")
        path = _program_path(info.filename)
        folded = path.as_posix().casefold()
        if folded in names:
            raise ArchiveValidationError("ZIP contains duplicate paths")
        names.add(folded)
        mode = (info.external_attr >> 16) & 0xFFFF
        file_type = stat.S_IFMT(mode)
        if file_type not in (0, stat.S_IFREG):
            raise ArchiveValidationError("ZIP contains a link or special file")
        if info.flag_bits & 0x1:
            raise ArchiveValidationError("encrypted ZIP members are not supported")
        if info.file_size < 0 or info.file_size > MAX_FILE_BYTES:
            raise ArchiveValidationError("ZIP member exceeds the file size limit")
        total += info.file_size
        if total > MAX_UNPACKED_BYTES:
            raise ArchiveValidationError("ZIP exceeds the unpacked size limit")
        if info.file_size and info.compress_size == 0:
            raise ArchiveValidationError("ZIP has an invalid compressed size")

    required_roots = {"run.py", "wsgi.py", "requirements.txt", "version", "scripts/start_server.py"}
    if not required_roots.issubset(names):
        raise ArchiveValidationError("ZIP is missing required program files")

    try:
        with archive.open("requirements.txt", "r") as source:
            digest = hashlib.sha256()
            count = 0
            while True:
                block = source.read(64 * 1024)
                if not block:
                    break
                count += len(block)
                digest.update(block)
            requirements_digest = digest.hexdigest()
    except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
        raise ArchiveValidationError("ZIP requirements file is corrupt") from exc
    if requirements_digest != requirements_sha256.lower():
        raise DependencyChangeError("the update changes the installed Python requirements")

    # Read every member to the end before creating any files; zipfile checks CRCs at EOF.
    try:
        for info in infos:
            with archive.open(info, "r") as source:
                count = 0
                while True:
                    block = source.read(64 * 1024)
                    if not block:
                        break
                    count += len(block)
                    if count > info.file_size:
                        raise ArchiveValidationError("ZIP member exceeds its declared size")
                if count != info.file_size:
                    raise ArchiveValidationError("ZIP member size is inconsistent")
    except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
        raise ArchiveValidationError("ZIP contents failed integrity validation") from exc
    return infos


def verify_and_extract(
    candidate,
    archive_path: Path,
    staging: Path,
    current_requirements_sha256: str,
) -> Path:
    """Validate the complete ZIP and extract only allowlisted regular program files."""
    manifest = candidate.manifest
    if manifest.requirements_sha256.lower() != current_requirements_sha256.lower():
        raise DependencyChangeError("the release requirements hash differs from the installed version")
    staging = Path(staging)
    if staging.exists() or staging.is_symlink():
        raise ArchiveValidationError("staging must be a new, nonexistent directory")
    try:
        with zipfile.ZipFile(archive_path, "r") as archive:
            infos = _preflight(archive, manifest.requirements_sha256)
            staging.mkdir(parents=True, exist_ok=False)
            root = staging.resolve(strict=True)
            for info in infos:
                relative = _program_path(info.filename)
                destination = root.joinpath(*relative.parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                parent = destination.parent.resolve(strict=True)
                try:
                    parent.relative_to(root)
                except ValueError as exc:
                    raise ArchiveValidationError("ZIP path escaped the staging directory") from exc
                if any(part.is_symlink() for part in (destination.parent, *destination.parents) if part != root):
                    raise ArchiveValidationError("staging contains an unexpected link")
                with archive.open(info, "r") as source, destination.open("xb") as output:
                    shutil.copyfileobj(source, output, length=64 * 1024)
            return staging
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        if isinstance(exc, ArchiveValidationError):
            raise
        raise ArchiveValidationError("failed to validate or extract the program ZIP") from exc
    except BaseException:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        raise
