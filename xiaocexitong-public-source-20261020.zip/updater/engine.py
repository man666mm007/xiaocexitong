"""Transactional updater state machine, version pointer, backup and rollback."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
import threading
import time
import urllib.error
import urllib.request
from contextlib import contextmanager
from dataclasses import asdict, replace
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from .archive import DependencyChangeError, verify_and_extract
from .backup import BackupError, copy_data_backup, restore_data_backup
from .manifest import ManifestError, parse_version
from .release_client import DownloadError, ReleaseClientError
from .state import UpdateState, read_state, write_state


class UpdateEngineError(RuntimeError):
    pass


class UpdateInProgress(UpdateEngineError):
    pass


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _tree_size(root: Path) -> int:
    total = 0
    for current, _directories, filenames in os.walk(root):
        for filename in filenames:
            try:
                total += (Path(current) / filename).stat().st_size
            except OSError as exc:
                raise UpdateEngineError("configured data directory cannot be measured") from exc
    return total


def _atomic_json(path: Path, value: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", prefix=f".{path.name}.", suffix=".tmp", dir=path.parent, delete=False
        ) as handle:
            temp_path = Path(handle.name)
            json.dump(value, handle, sort_keys=True, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    except BaseException:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
        raise


def read_active_version(state_root: Path) -> dict[str, object]:
    path = Path(state_root) / "active_version.json"
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise UpdateEngineError("active version pointer is missing or invalid") from exc
    if (
        not isinstance(value, dict)
        or set(value) != {"version", "required_schema_version"}
        or not isinstance(value.get("version"), str)
        or isinstance(value.get("required_schema_version"), bool)
        or not isinstance(value.get("required_schema_version"), int)
        or value["required_schema_version"] <= 0
    ):
        raise UpdateEngineError("active version pointer is invalid")
    try:
        parse_version(value["version"])
    except ManifestError as exc:
        raise UpdateEngineError("active version pointer is invalid") from exc
    return value


def write_active_version(state_root: Path, pointer: dict[str, object]) -> None:
    version = pointer.get("version")
    schema = pointer.get("required_schema_version")
    if not isinstance(version, str) or isinstance(schema, bool) or not isinstance(schema, int) or schema <= 0:
        raise UpdateEngineError("new active version pointer is invalid")
    try:
        parse_version(version)
    except ManifestError as exc:
        raise UpdateEngineError("new active version pointer is invalid") from exc
    _atomic_json(Path(state_root) / "active_version.json", {"version": version, "required_schema_version": schema})


@contextmanager
def _exclusive_file_lock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = Path(path).open("a+b")
    locked = False
    try:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt

            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                locked = True
            except OSError as exc:
                raise UpdateInProgress("another update is already running") from exc
        else:
            import fcntl

            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
            except OSError as exc:
                raise UpdateInProgress("another update is already running") from exc
        yield
    finally:
        if locked:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
        handle.close()


class UpdateEngine:
    def __init__(
        self,
        config,
        process_manager,
        release_client,
        *,
        health_probe=None,
        disk_usage=shutil.disk_usage,
        health_timeout_seconds: int = 60,
        health_poll_interval: float = 1.0,
        sleep=time.sleep,
    ):
        self.config = config
        self.process_manager = process_manager
        self.release_client = release_client
        self.health_probe = health_probe or self._http_health_probe
        self.disk_usage = disk_usage
        self.health_timeout_seconds = health_timeout_seconds
        self.health_poll_interval = health_poll_interval
        self._sleep = sleep
        self.state_path = Path(config.work_root) / "state.json"
        self.pointer_path = Path(config.work_root) / "active_version.json"
        self._install_lock = threading.Lock()
        Path(config.work_root).mkdir(parents=True, exist_ok=True)

    def status(self) -> UpdateState:
        state = read_state(self.state_path)
        try:
            pointer = read_active_version(self.config.work_root)
            return replace(state, current_version=str(pointer["version"]))
        except UpdateEngineError:
            return state

    def _save(self, state: UpdateState) -> UpdateState:
        write_state(self.state_path, state)
        return state

    def _set_state(self, phase: str, **updates) -> UpdateState:
        state = read_state(self.state_path)
        new_state = replace(state, phase=phase, **updates)
        return self._save(new_state)

    def _client(self):
        if callable(self.release_client) and not hasattr(self.release_client, "latest"):
            return self.release_client()
        return self.release_client

    def check(self) -> UpdateState:
        try:
            pointer = read_active_version(self.config.work_root)
            current = str(pointer["version"])
            self._set_state("checking", current_version=current, message="")
            candidate = self._client().latest(current)
            if candidate is None:
                return self._set_state(
                    "checked",
                    current_version=current,
                    available_version="",
                    update_notes="",
                    last_checked_at=_utc_now(),
                    message="当前已是最新版",
                )
            return self._set_state(
                "checked",
                current_version=current,
                available_version=candidate.manifest.version,
                update_notes=candidate.manifest.notes,
                last_checked_at=_utc_now(),
                message="发现可用更新",
            )
        except Exception as exc:
            return self._set_state("failed", last_checked_at=_utc_now(), message=str(exc))

    def install(self) -> UpdateState:
        if not self._install_lock.acquire(blocking=False):
            return self.status()
        try:
            with _exclusive_file_lock(Path(self.config.work_root) / "install.lock"):
                return self._install_locked()
        except UpdateInProgress:
            return self.status()
        finally:
            self._install_lock.release()

    def _install_locked(self) -> UpdateState:
        pointer = read_active_version(self.config.work_root)
        old_version = str(pointer["version"])
        old_version_dir = self._version_dir(old_version)
        operation_id = uuid4().hex
        package_path = Path(self.config.work_root) / f"update-{operation_id}.zip"
        staging = Path(self.config.work_root) / f"staging-{operation_id}"
        backup = None
        stopped = False
        pointer_switched = False
        target_version_dir = None
        candidate = None
        started_at = _utc_now()
        self._set_state(
            "downloading",
            current_version=old_version,
            available_version="",
            update_notes="",
            operation_started_at=started_at,
            message="正在下载更新包",
        )
        try:
            candidate = self._client().latest(old_version)
            if candidate is None:
                return self._set_state(
                    "checked",
                    current_version=old_version,
                    available_version="",
                    update_notes="",
                    last_checked_at=_utc_now(),
                    message="当前已是最新版",
                )
            manifest = candidate.manifest
            if parse_version(manifest.version) <= parse_version(old_version):
                raise UpdateEngineError("release version is not newer than the installed version")
            target_version_dir = self._version_dir(manifest.version)
            if target_version_dir.exists():
                raise UpdateEngineError("target version directory already exists")

            self._set_state(
                "downloading",
                current_version=old_version,
                available_version=manifest.version,
                update_notes=manifest.notes,
                operation_started_at=started_at,
                message="正在下载更新包",
            )
            client = self._client()
            client.download(candidate, package_path)
            if package_path.stat().st_size != manifest.package_size or _sha256_file(package_path) != manifest.package_sha256:
                raise UpdateEngineError("downloaded package failed size or SHA-256 validation")

            self._set_state("verifying", available_version=manifest.version, message="正在验证更新包")
            current_requirements = _sha256_file(old_version_dir / "requirements.txt")
            verify_and_extract(candidate, package_path, staging, current_requirements)
            self._check_disk_space(staging, manifest.package_size)

            self._set_state("installing", message="更新包已验证，正在备份并切换程序")
            self.process_manager.stop()
            stopped = True
            backup = copy_data_backup(self.config.data_root, self.config.backup_root)
            try:
                os.replace(staging, target_version_dir)
                pointer_switched = True
                write_active_version(
                    self.config.work_root,
                    {"version": manifest.version, "required_schema_version": manifest.required_schema_version},
                )
            except BaseException:
                if target_version_dir.exists() and staging.exists():
                    shutil.rmtree(staging, ignore_errors=True)
                raise

            self._set_state("starting", message="正在启动新版并检查数据库")
            self.process_manager.start(target_version_dir)
            self._wait_for_health(manifest.version, manifest.required_schema_version)
            self._mark_backup(backup, "succeeded", old_version, manifest.version, "")
            self._prune_successful_backups()
            try:
                package_path.unlink(missing_ok=True)
            except OSError:
                pass
            return self._set_state(
                "succeeded",
                current_version=manifest.version,
                available_version="",
                update_notes=manifest.notes,
                last_success_version=manifest.version,
                last_success_at=_utc_now(),
                message="更新成功",
            )
        except Exception as exc:
            reason = str(exc)
            if stopped:
                recovered = self._rollback(
                    pointer,
                    old_version_dir,
                    backup,
                    pointer_switched,
                    reason,
                )
                return recovered
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)
            try:
                package_path.unlink(missing_ok=True)
            except OSError:
                pass
            return self._set_state(
                "failed",
                current_version=old_version,
                available_version=(candidate.manifest.version if candidate is not None else ""),
                message=reason,
            )

    def _version_dir(self, version: str) -> Path:
        parse_version(version)
        root = Path(self.config.versions_root).resolve(strict=False)
        target = (root / version).resolve(strict=False)
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise UpdateEngineError("version directory is outside the configured version root") from exc
        return target

    def _check_disk_space(self, staging: Path, package_size: int) -> None:
        unpacked = sum(path.stat().st_size for path in staging.rglob("*") if path.is_file())
        required_program = max(package_size * 2 + 16 * 1024 * 1024, unpacked + package_size)
        required_data = _tree_size(self.config.data_root) + 1 * 1024 * 1024
        program_free = self.disk_usage(self.config.assistant_root).free
        data_free = self.disk_usage(self.config.data_root).free
        if program_free < required_program or data_free < required_data:
            raise UpdateEngineError("磁盘剩余空间不足，更新未开始")

    def _http_health_probe(self, url: str, token: str, timeout: float):
        request = urllib.request.Request(url, headers={"X-Quiz-Updater-Token": token})
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                if response.status != 200:
                    raise UpdateEngineError("health endpoint returned an error")
                data = json.loads(response.read(16 * 1024).decode("utf-8"))
                if not isinstance(data, dict):
                    raise UpdateEngineError("health endpoint returned invalid data")
                return data
        except (OSError, urllib.error.URLError, UnicodeError, json.JSONDecodeError) as exc:
            raise UpdateEngineError("新版网站暂未就绪") from exc

    def _wait_for_health(self, expected_version: str, required_schema_version: int) -> None:
        deadline = time.monotonic() + self.health_timeout_seconds
        last_error = None
        while time.monotonic() < deadline:
            token = getattr(self.process_manager, "health_token", "")
            try:
                data = self.health_probe(self.config.health_url, token, 2)
                if (
                    data.get("version") == expected_version
                    and data.get("database_ok") is True
                    and isinstance(data.get("schema_version"), int)
                    and data["schema_version"] >= required_schema_version
                ):
                    return
                last_error = "网站版本或数据库健康状态不符合预期"
            except Exception as exc:
                last_error = str(exc)
            self._sleep(self.health_poll_interval)
        raise UpdateEngineError(last_error or "网站健康检查超时")

    def _rollback(self, old_pointer, old_version_dir, backup, pointer_switched, reason) -> UpdateState:
        self._set_state("rolling_back", message="新版未通过检查，正在恢复旧版本")
        try:
            try:
                self.process_manager.stop()
            except Exception:
                if getattr(self.process_manager, "pid", None) is not None:
                    raise
            if pointer_switched:
                write_active_version(self.config.work_root, old_pointer)
            if backup is not None:
                restore_data_backup(backup, self.config.data_root, Path(self.config.work_root) / "quarantine")
            if getattr(self.process_manager, "pid", None) is None:
                self.process_manager.start(old_version_dir)
            self._wait_for_health(str(old_pointer["version"]), int(old_pointer["required_schema_version"]))
            if backup is not None:
                self._mark_backup(backup, "failed", str(old_pointer["version"]), "", reason)
            return self._set_state(
                "recovered",
                current_version=str(old_pointer["version"]),
                available_version="",
                message=f"更新失败，已恢复旧版本：{reason}",
            )
        except Exception as recovery_exc:
            if backup is not None:
                self._mark_backup(backup, "recovery_failed", str(old_pointer["version"]), "", str(recovery_exc))
            return self._set_state(
                "recovery_failed",
                current_version=str(old_pointer["version"]),
                available_version="",
                message=f"更新失败且自动恢复未完成：{recovery_exc}",
            )

    def _mark_backup(self, backup: Path, status: str, previous: str, installed: str, message: str) -> None:
        _atomic_json(
            Path(backup) / "result.json",
            {
                "status": status,
                "previous_version": previous,
                "installed_version": installed,
                "recorded_at": _utc_now(),
                "message": message[:500],
            },
        )

    def _prune_successful_backups(self) -> None:
        root = Path(self.config.backup_root)
        completed = []
        if not root.exists():
            return
        for backup in root.glob("backup-*"):
            try:
                result = json.loads((backup / "result.json").read_text(encoding="utf-8"))
                if isinstance(result, dict) and result.get("status") == "succeeded":
                    completed.append((backup.stat().st_mtime, backup))
            except (OSError, UnicodeError, json.JSONDecodeError):
                continue
        completed.sort(reverse=True)
        for _mtime, old in completed[self.config.backup_retention :]:
            shutil.rmtree(old, ignore_errors=True)
