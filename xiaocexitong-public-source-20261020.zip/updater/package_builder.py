from __future__ import annotations

import hashlib
import os
import stat
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath


class PackageBuildError(ValueError):
    """Raised when a program package cannot be built safely."""


REQUIRED_ROOT_FILES = (
    "scripts/start_server.py",
    "run.py",
    "wsgi.py",
    "requirements.txt",
    "VERSION",
)
MAX_PACKAGE_FILES = 10000


@dataclass(frozen=True, slots=True)
class PackageDigest:
    size: int
    sha256: str
    requirements_sha256: str


def _is_reparse_point(path: Path) -> bool:
    try:
        file_stat = path.lstat()
    except OSError as exc:
        raise PackageBuildError(f"cannot inspect package source path: {path}") from exc
    attributes = getattr(file_stat, "st_file_attributes", 0)
    reparse_attribute = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return path.is_symlink() or bool(attributes & reparse_attribute)


def _validate_archive_names(names: list[str]) -> None:
    seen: set[str] = set()
    for name in names:
        if not isinstance(name, str) or not name or "\\" in name or "\x00" in name:
            raise PackageBuildError("archive path is invalid")
        path = PurePosixPath(name)
        if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
            raise PackageBuildError("archive path must be relative and cannot traverse directories")
        if ":" in name:
            raise PackageBuildError("archive path cannot contain a drive or alternate-stream separator")
        folded = name.casefold()
        if folded in seen:
            raise PackageBuildError("archive contains case-insensitive duplicate paths")
        seen.add(folded)


def _collect_files(project_root: Path) -> list[tuple[str, Path]]:
    root = project_root.resolve(strict=True)
    if not root.is_dir():
        raise PackageBuildError("project_root must be a directory")

    entries: list[tuple[str, Path]] = []
    app_root = root / "app"
    if _is_reparse_point(app_root) or not app_root.is_dir():
        raise PackageBuildError("required app directory is missing or unsafe")

    for current, directories, filenames in os.walk(app_root, topdown=True, followlinks=False):
        current_path = Path(current)
        for directory in list(directories):
            directory_path = current_path / directory
            if _is_reparse_point(directory_path):
                raise PackageBuildError(f"app contains a link or reparse point: {directory_path}")
        directories[:] = [
            directory
            for directory in directories
            if directory not in {"__pycache__", ".pytest_cache"}
        ]
        for filename in filenames:
            path = current_path / filename
            if _is_reparse_point(path):
                raise PackageBuildError(f"app contains a link or reparse point: {path}")
            if filename.endswith((".pyc", ".pyo")) or "__pycache__" in path.parts:
                continue
            if not path.is_file():
                raise PackageBuildError(f"app contains a non-regular file: {path}")
            entries.append((path.relative_to(root).as_posix(), path))

    if not entries:
        raise PackageBuildError("app directory contains no program files")

    for relative in REQUIRED_ROOT_FILES:
        path = root / Path(relative)
        parent = path.parent
        while parent != root:
            if _is_reparse_point(parent):
                raise PackageBuildError(f"program path contains a link or reparse point: {parent}")
            parent = parent.parent
        if _is_reparse_point(path) or not path.is_file():
            raise PackageBuildError(f"required program file is missing or unsafe: {relative}")
        entries.append((relative.replace("\\", "/"), path))

    if len(entries) > MAX_PACKAGE_FILES:
        raise PackageBuildError("program package contains too many files")
    _validate_archive_names([name for name, _ in entries])
    return sorted(entries, key=lambda item: item[0].casefold())


def build_program_zip(project_root: Path, output_path: Path) -> PackageDigest:
    """Build a deterministic ZIP from the fixed program-only allowlist."""
    project_root = Path(project_root)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    entries = _collect_files(project_root)
    requirements_path = project_root.resolve(strict=True) / "requirements.txt"
    requirements_bytes = requirements_path.read_bytes()

    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            prefix=f".{output_path.name}.",
            suffix=".tmp",
            dir=output_path.parent,
            delete=False,
        ) as temporary:
            temp_path = Path(temporary.name)

        with zipfile.ZipFile(
            temp_path,
            mode="w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
            strict_timestamps=True,
        ) as archive:
            for archive_name, source_path in entries:
                if _is_reparse_point(source_path) or not source_path.is_file():
                    raise PackageBuildError(f"program source changed or became unsafe: {source_path}")
                info = zipfile.ZipInfo(archive_name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, source_path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

        os.replace(temp_path, output_path)
        temp_path = None
    except (OSError, zipfile.BadZipFile) as exc:
        raise PackageBuildError("failed to create the program ZIP") from exc
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass

    package_bytes = output_path.read_bytes()
    return PackageDigest(
        size=len(package_bytes),
        sha256=hashlib.sha256(package_bytes).hexdigest(),
        requirements_sha256=hashlib.sha256(requirements_bytes).hexdigest(),
    )
