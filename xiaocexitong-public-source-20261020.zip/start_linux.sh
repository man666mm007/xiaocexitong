#!/usr/bin/env sh
set -eu

if [ -z "${QUIZ_SECRET_KEY:-}" ]; then
    if [ -s secret_key.txt ]; then
        QUIZ_SECRET_KEY=$(cat secret_key.txt)
    else
        if [ ! -x .venv/bin/python ]; then
            echo "Create the virtual environment before starting the application." >&2
            exit 1
        fi
        QUIZ_SECRET_KEY=$(.venv/bin/python -c 'import secrets; print(secrets.token_hex(32))')
        (umask 077; printf '%s\n' "$QUIZ_SECRET_KEY" > secret_key.txt)
    fi
fi

export QUIZ_SECRET_KEY
exec .venv/bin/waitress-serve --listen=127.0.0.1:5000 wsgi:app
