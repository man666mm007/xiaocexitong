[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PythonPath,
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot),
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if (-not [System.IO.Path]::IsPathRooted($PythonPath)) { throw "PythonPath 必须是绝对路径。" }
if (-not [System.IO.Path]::IsPathRooted($ProjectRoot)) { throw "ProjectRoot 必须是绝对路径。" }
$ProjectRoot = [System.IO.Path]::GetFullPath($ProjectRoot)
$PythonPath = [System.IO.Path]::GetFullPath($PythonPath)
if (-not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) { throw "指定的 Python 不存在。" }
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "scripts\build_update_agent.py") -PathType Leaf)) {
    throw "更新助手构建脚本不存在。"
}
if (-not $OutputPath) { $OutputPath = Join-Path $ProjectRoot "dist\quiz-updater.pyz" }
if (-not [System.IO.Path]::IsPathRooted($OutputPath)) { throw "OutputPath 必须是绝对路径。" }
$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)

& $PythonPath -I -S (Join-Path $ProjectRoot "scripts\build_update_agent.py") --project-root $ProjectRoot --output $OutputPath
if ($LASTEXITCODE -ne 0) { throw "更新助手 zipapp 构建失败。" }
& $PythonPath -I -S $OutputPath --help | Out-Null
if ($LASTEXITCODE -ne 0) { throw "更新助手启动审计失败。" }

@{
    status = "built"
    artifact = $OutputPath
    sha256 = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
    runtime = $PythonPath
    runtime_mode = "python-zipapp-standard-library-only"
} | ConvertTo-Json -Compress
