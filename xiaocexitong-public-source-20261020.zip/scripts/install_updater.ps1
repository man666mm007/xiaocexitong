[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProjectRoot,
    [Parameter(Mandatory = $true)][string]$DataRoot,
    [Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$PublicKey,
    [Parameter(Mandatory = $true)][string]$HelperPackage,
    [Parameter(Mandatory = $true)][string]$PythonPath,
    [Parameter(Mandatory = $true)][string]$BackupRoot,
    [string]$KeyId = "release-2026",
    [int]$Port = 5000,
    [string]$UrlPrefix = "/quiz",
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-FullPath([string]$PathValue, [string]$Name, [bool]$MustExist) {
    if (-not [System.IO.Path]::IsPathRooted($PathValue)) { throw "$Name 必须使用绝对路径。" }
    $full = [System.IO.Path]::GetFullPath($PathValue)
    if ($MustExist -and -not (Test-Path -LiteralPath $full)) { throw "$Name 不存在。" }
    $trimmed = $full.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    $root = [System.IO.Path]::GetPathRoot($full)
    if ($trimmed.Equals($root.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar), [System.StringComparison]::OrdinalIgnoreCase)) {
        return $root
    }
    return $trimmed
}

function Test-PathOverlap([string]$Left, [string]$Right) {
    $a = [System.IO.Path]::GetFullPath($Left).TrimEnd('\', '/')
    $b = [System.IO.Path]::GetFullPath($Right).TrimEnd('\', '/')
    return ($a.Equals($b, [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '/', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '/', [System.StringComparison]::OrdinalIgnoreCase))
}

function Invoke-Icacls([string[]]$Arguments) {
    & "$env:SystemRoot\System32\icacls.exe" @Arguments | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Windows 目录权限设置失败。" }
}

$ProjectRoot = Get-FullPath $ProjectRoot "ProjectRoot" $true
$DataRoot = Get-FullPath $DataRoot "DataRoot" $true
$PublicKey = Get-FullPath $PublicKey "PublicKey" $true
$HelperPackage = Get-FullPath $HelperPackage "HelperPackage" $true
$PythonPath = Get-FullPath $PythonPath "PythonPath" $true
$BackupRoot = Get-FullPath $BackupRoot "BackupRoot" $false
$programData = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
$assistantRoot = Join-Path $programData "ProbabilityQuizUpdater"
$versionsRoot = Join-Path $assistantRoot "versions"
$workRoot = Join-Path $assistantRoot "work"
$installedKey = Join-Path $assistantRoot "release-public.pem"
$installedHelper = Join-Path $assistantRoot "quiz-updater.pyz"
$configPath = Join-Path $assistantRoot "config.json"
$tokenPath = Join-Path $assistantRoot "agent.token"

if ($Repository -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { throw "Repository 必须形如 owner/name。" }
if ($KeyId -notmatch '^[A-Za-z0-9_.-]{1,64}$') { throw "KeyId 格式无效。" }
if ($Port -ne 5000) { throw "当前启动脚本仅支持端口 5000。" }
if ($UrlPrefix -ne "/quiz") { throw "当前启动脚本仅支持 /quiz 前缀。" }
if ($ProjectRoot.Equals($DataRoot, [System.StringComparison]::OrdinalIgnoreCase) -or
    $ProjectRoot.StartsWith($DataRoot.TrimEnd('\', '/') + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
    $ProjectRoot.StartsWith($DataRoot.TrimEnd('\', '/') + '/', [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "数据目录不能等于项目目录，也不能包含项目目录。"
}
if (Test-Path -LiteralPath $assistantRoot) { throw "更新助手目录已存在；拒绝覆盖已有安装，请先由管理员核验或清理。" }
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "VERSION") -PathType Leaf)) { throw "项目 VERSION 文件缺失。" }
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "secret_key.txt") -PathType Leaf)) { throw "项目 secret_key.txt 缺失。" }
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "scripts\install_program_version.py") -PathType Leaf)) { throw "程序版本复制脚本缺失。" }
if (-not (Test-PathOverlap $PythonPath $ProjectRoot)) { throw "PythonPath 必须位于项目虚拟环境目录中。" }
foreach ($protectedPath in @($ProjectRoot, $DataRoot, $assistantRoot)) {
    if (Test-PathOverlap $BackupRoot $protectedPath) { throw "BackupRoot 必须与项目、数据和助手目录隔离。" }
}

$version = (Get-Content -LiteralPath (Join-Path $ProjectRoot "VERSION") -Raw -Encoding ASCII).Trim()
if ($version -ne "1.0.0") { throw "首次纳管只支持当前基线版本 1.0.0。" }
$plan = [ordered]@{
    status = if ($WhatIf) { "what-if" } else { "validated" }
    repository = $Repository
    program_version = $version
    listener = "127.0.0.1:$Port/quiz/"
    actions = @(
        "在独立 BackupRoot 创建程序 ZIP 和完整数据副本",
        "在 ProgramData 安装更新助手、公钥、随机令牌和受保护配置",
        "将当前程序白名单复制到 versions/1.0.0 并写入 active_version.json",
        "设置最小 NTFS ACL 并注册 Network Service 开机任务",
        "启动网站并验证本机数据库健康端点"
    )
    paths = [ordered]@{
        project_root = $ProjectRoot
        data_root = $DataRoot
        backup_root = $BackupRoot
        assistant_root = $assistantRoot
        public_key = $PublicKey
        helper_package = $HelperPackage
        python = $PythonPath
    }
}
if ($WhatIf) {
    $plan | ConvertTo-Json -Depth 6 -Compress
    exit 0
}

$githubHeaders = @{ "Accept" = "application/vnd.github+json"; "User-Agent" = "ProbabilityQuizUpdater" }
try {
    $repositoryInfo = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$Repository" -Headers $githubHeaders -TimeoutSec 15
} catch {
    throw "固定 GitHub 仓库不可访问或尚未建立；未安装更新助手。"
}
if ($repositoryInfo.full_name -ne $Repository -or $repositoryInfo.private -ne $false) {
    throw "固定更新仓库必须是准确匹配的公开 GitHub 仓库。"
}

$listener = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() |
    Where-Object { $_.Port -eq $Port }
if ($listener) { throw "请先停止网站；当前端口 $Port 仍在监听。" }

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "请以管理员身份运行首次安装。" }

Add-Type -AssemblyName System.IO.Compression.FileSystem
$backupStamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $BackupRoot "probability-quiz-$backupStamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
$programBackup = Join-Path $backupDir "program.zip"
$dataBackup = Join-Path $backupDir "data"
[System.IO.Compression.ZipFile]::CreateFromDirectory($ProjectRoot, $programBackup, [System.IO.Compression.CompressionLevel]::Optimal, $false)
if (-not (Test-Path -LiteralPath $programBackup -PathType Leaf)) { throw "程序备份未生成。" }
$programArchive = [System.IO.Compression.ZipFile]::OpenRead($programBackup)
try { if ($programArchive.Entries.Count -lt 6) { throw "程序备份不完整。" } } finally { $programArchive.Dispose() }

Copy-Item -LiteralPath $DataRoot -Destination $dataBackup -Recurse -Force
$sourceFiles = @(Get-ChildItem -LiteralPath $DataRoot -File -Recurse -Force)
$backupFiles = @(Get-ChildItem -LiteralPath $dataBackup -File -Recurse -Force)
if ($sourceFiles.Count -ne $backupFiles.Count) { throw "数据备份文件数校验失败。" }
foreach ($sourceFile in $sourceFiles) {
    $relative = $sourceFile.FullName.Substring($DataRoot.Length).TrimStart('\', '/')
    $backupFile = Join-Path $dataBackup $relative
    if (-not (Test-Path -LiteralPath $backupFile -PathType Leaf)) { throw "数据备份缺少文件。" }
    if ((Get-FileHash -LiteralPath $sourceFile.FullName -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $backupFile -Algorithm SHA256).Hash) {
        throw "数据备份哈希校验失败。"
    }
}
$databasePath = Join-Path $DataRoot "quiz.sqlite3"
if (-not (Test-Path -LiteralPath $databasePath -PathType Leaf)) { throw "DataRoot 中没有 quiz.sqlite3，请确认实际使用的数据目录。" }
foreach ($directoryName in @("uploads", "pending")) {
    if (-not (Test-Path -LiteralPath (Join-Path $DataRoot $directoryName) -PathType Container)) {
        throw "DataRoot 中缺少 $directoryName 目录，请确认实际使用的数据目录。"
    }
}
$backupDatabasePath = Join-Path $dataBackup "quiz.sqlite3"
foreach ($databaseCheckPath in @($databasePath, $backupDatabasePath)) {
    $checkScript = 'import sqlite3,sys; c=sqlite3.connect("file:"+sys.argv[1].replace("\\","/")+"?mode=ro",uri=True); r=c.execute("PRAGMA quick_check").fetchone(); c.close(); raise SystemExit(0 if r and r[0]=="ok" else 1)'
    & $PythonPath -I -c $checkScript $databaseCheckPath
    if ($LASTEXITCODE -ne 0) { throw "SQLite 数据库备份前检查失败。" }
}

& $PythonPath -I -c 'import sys;sys.path.insert(0,sys.argv[1]);from updater.rsa_verify import _parse_public_key;_parse_public_key(open(sys.argv[2],"rb").read())' $ProjectRoot $PublicKey
if ($LASTEXITCODE -ne 0) { throw "签名公钥必须是 RSA-3072 或更强的 PEM。" }
& $PythonPath -I -S $HelperPackage --help | Out-Null
if ($LASTEXITCODE -ne 0) { throw "更新助手启动检查失败。" }

New-Item -ItemType Directory -Path $assistantRoot, $versionsRoot, $workRoot, (Join-Path $assistantRoot "backups") -Force | Out-Null
$ns = "*S-1-5-20"
$admin = "*S-1-5-32-544"
$system = "*S-1-5-18"
Invoke-Icacls @($assistantRoot, "/inheritance:r")
Invoke-Icacls @($assistantRoot, "/grant:r", "$system`:(OI)(CI)(F)", "$admin`:(OI)(CI)(F)", "$ns`:(OI)(CI)(RX)")
foreach ($writable in @($versionsRoot, $workRoot, (Join-Path $assistantRoot "backups"))) {
    Invoke-Icacls @($writable, "/inheritance:r")
    Invoke-Icacls @($writable, "/grant:r", "$system`:(OI)(CI)(F)", "$admin`:(OI)(CI)(F)", "$ns`:(OI)(CI)(M)")
}
Invoke-Icacls @($ProjectRoot, "/grant", "$ns`:(OI)(CI)(RX)", "/T", "/C")
Invoke-Icacls @($DataRoot, "/grant", "$ns`:(OI)(CI)(M)", "/T", "/C")

Copy-Item -LiteralPath $HelperPackage -Destination $installedHelper -Force
Copy-Item -LiteralPath $PublicKey -Destination $installedKey -Force
$tokenBytes = New-Object byte[] 32
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($tokenBytes)
$token = [Convert]::ToBase64String($tokenBytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')
[System.IO.File]::WriteAllText($tokenPath, $token, [System.Text.Encoding]::ASCII)
$envValues = [ordered]@{
    QUIZ_URL_PREFIX = "/quiz"
    QUIZ_SESSION_DAYS = "7"
}
foreach ($key in @("QUIZ_HTTPS", "PUBLIC_BASE_URL", "COURSEWARE_URL")) {
    $value = [Environment]::GetEnvironmentVariable($key)
    if ($null -ne $value) { $envValues[$key] = [string]$value }
}
$agentPortListener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
$agentPortListener.Start()
$agentPort = ([System.Net.IPEndPoint]$agentPortListener.LocalEndpoint).Port
$agentPortListener.Stop()
$config = [ordered]@{
    program_root = $ProjectRoot
    data_root = $DataRoot
    versions_root = $versionsRoot
    work_root = $workRoot
    python_executable = $PythonPath
    repository = $Repository
    public_key_path = $installedKey
    key_id = $KeyId
    secret_key_path = (Join-Path $ProjectRoot "secret_key.txt")
    website_environment = $envValues
    site_url = "http://127.0.0.1:5000/quiz/"
    health_url = "http://127.0.0.1:5000/quiz/__updater_health"
    agent_port = $agentPort
    agent_token_path = $tokenPath
    backup_retention = 5
}
$configTemp = Join-Path $assistantRoot "config.json.tmp"
[System.IO.File]::WriteAllText($configTemp, ($config | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
Move-Item -LiteralPath $configTemp -Destination $configPath -Force

$schemaOutput = & $PythonPath -I -c 'import sys;sys.path.insert(0,sys.argv[1]);from app.db import MIGRATION_VERSION;print(MIGRATION_VERSION)' $ProjectRoot
if ($LASTEXITCODE -ne 0 -or $schemaOutput -notmatch '^\d+$') { throw "当前数据库迁移版本读取失败。" }
$initialVersion = Join-Path $versionsRoot "1.0.0"
& $PythonPath -I -S (Join-Path $ProjectRoot "scripts\install_program_version.py") --project-root $ProjectRoot --destination $initialVersion
if ($LASTEXITCODE -ne 0) { throw "当前程序白名单复制失败。" }
[ordered]@{ version = "1.0.0"; required_schema_version = [int]$schemaOutput } |
    ForEach-Object { [System.IO.File]::WriteAllText((Join-Path $workRoot "active_version.json"), ($_ | ConvertTo-Json -Compress), (New-Object System.Text.UTF8Encoding($false))) }

Invoke-Icacls @($installedHelper, "/inheritance:r")
Invoke-Icacls @($installedHelper, "/grant:r", "$system`:(F)", "$admin`:(F)", "$ns`:(RX)")
foreach ($protectedFile in @($installedKey, $configPath, $tokenPath)) {
    Invoke-Icacls @($protectedFile, "/inheritance:r")
    Invoke-Icacls @($protectedFile, "/grant:r", "$system`:(F)", "$admin`:(F)", "$ns`:(R)")
}
$taskName = "ProbabilityQuizUpdater"
$arguments = "-I -S `"$installedHelper`" --agent --config `"$configPath`""
$action = New-ScheduledTaskAction -Execute $PythonPath -Argument $arguments -WorkingDirectory $assistantRoot
$trigger = New-ScheduledTaskTrigger -AtStartup
$servicePrincipal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\NETWORK SERVICE" -LogonType ServiceAccount -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $servicePrincipal -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName $taskName

$deadline = (Get-Date).AddSeconds(60)
$ready = $false
while ((Get-Date) -lt $deadline) {
    try {
        $response = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:5000/quiz/__updater_health" -Headers @{ "X-Quiz-Updater-Token" = $token } -TimeoutSec 2
        $health = $response.Content | ConvertFrom-Json
        if ($health.version -eq "1.0.0" -and $health.database_ok -eq $true -and [int]$health.schema_version -ge [int]$schemaOutput) { $ready = $true; break }
    } catch { Start-Sleep -Seconds 1 }
    Start-Sleep -Milliseconds 500
}
if (-not $ready) { throw "更新助手已安装，但本机网站健康检查未通过；请保留备份并联系管理员。" }
@{ status = "installed"; version = "1.0.0"; repository = $Repository; backup = $backupDir; task = $taskName } |
    ConvertTo-Json -Compress
