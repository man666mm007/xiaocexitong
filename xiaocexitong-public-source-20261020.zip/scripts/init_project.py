import argparse
import getpass
import sys
from pathlib import Path

from werkzeug.security import generate_password_hash

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from app import create_app  # noqa: E402
from app.db import get_db, init_db  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="初始化小测查询系统")
    parser.add_argument("--teacher-id", required=True, help="教师登录工号")
    parser.add_argument("--teacher-name", required=True, help="教师姓名")
    arguments = parser.parse_args()
    password = getpass.getpass("设置教师密码（至少 10 个字符；输入时不会显示字符）：")
    confirm = getpass.getpass("再次输入教师密码（输入时不会显示字符）：")
    if password != confirm:
        raise SystemExit("两次密码不一致。")
    if len(password) < 10 or len(password) > 128:
        raise SystemExit("教师密码需要为 10—128 个字符。")

    app = create_app()
    with app.app_context():
        init_db()
        database = get_db()
        if database.execute("SELECT id FROM users WHERE username=?", (arguments.teacher_id,)).fetchone():
            raise SystemExit("该教师工号已经存在。")
        database.execute(
            "INSERT INTO users(username,name,password_hash,role,must_change_password) VALUES(?,?,?,?,0)",
            (arguments.teacher_id, arguments.teacher_name, generate_password_hash(password), "teacher"),
        )
        database.commit()
    print("初始化完成。请妥善保管教师账号密码，并配置 QUIZ_SECRET_KEY。")


if __name__ == "__main__":
    main()

