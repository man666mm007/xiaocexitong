"""Build a deterministic standard-library-only updater zipapp."""

from __future__ import annotations

import argparse
import os
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path


AGENT_MODULES = (
    "__init__.py",
    "__main__.py",
    "agent_server.py",
    "archive.py",
    "backup.py",
    "config.py",
    "engine.py",
    "manifest.py",
    "process_manager.py",
    "release_client.py",
    "rsa_verify.py",
    "state.py",
)
ENTRYPOINT = "from updater.__main__ import main\nraise SystemExit(main())\n"
FIXED_TIME = (1980, 1, 1, 0, 0, 0)


def build_agent_zipapp(project_root: Path, output_path: Path) -> Path:
    project_root = Path(project_root).resolve(strict=True)
    updater_root = project_root / "updater"
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_root = Path(tempfile.mkdtemp(prefix=".quiz-agent-build-", dir=output_path.parent))
    temp_archive = temp_root / output_path.name
    source = temp_root / "source"
    package = source / "updater"
    package.mkdir(parents=True)
    try:
        for name in AGENT_MODULES:
            source_file = updater_root / name
            if not source_file.is_file():
                raise FileNotFoundError(f"required updater module is missing: {name}")
            shutil.copyfile(source_file, package / name)
        (source / "__main__.py").write_text(ENTRYPOINT, encoding="utf-8", newline="\n")

        members = sorted((path for path in source.rglob("*") if path.is_file()), key=lambda path: path.relative_to(source).as_posix())
        with zipfile.ZipFile(temp_archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in members:
                name = path.relative_to(source).as_posix()
                info = zipfile.ZipInfo(name, date_time=FIXED_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 0
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        os.replace(temp_archive, output_path)
        return output_path
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="build the standalone updater zipapp")
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    build_agent_zipapp(args.project_root, args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
