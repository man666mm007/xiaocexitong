from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from updater.release_builder import ReleaseBuildError, build_release


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build a locally signed program update release; does not upload or publish it."
    )
    parser.add_argument("--repository", required=True, help="fixed GitHub owner/name")
    parser.add_argument("--tag", required=True, help="release tag, for example v1.0.1")
    parser.add_argument("--notes-file", required=True, type=Path)
    parser.add_argument("--min-version", required=True)
    parser.add_argument("--max-version", required=True)
    parser.add_argument("--schema-version", required=True, type=int)
    parser.add_argument("--key-id", required=True)
    parser.add_argument("--private-key", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    try:
        notes = args.notes_file.read_text(encoding="utf-8")
        result = build_release(
            project_root=PROJECT_ROOT,
            repository=args.repository,
            tag=args.tag,
            notes=notes,
            min_version=args.min_version,
            max_version=args.max_version,
            required_schema_version=args.schema_version,
            key_id=args.key_id,
            private_key_path=args.private_key,
            output_dir=args.output_dir,
        )
    except (OSError, ReleaseBuildError) as exc:
        parser.exit(2, f"error: {exc}\n")

    print(
        json.dumps(
            {
                "package": str(result.package_path),
                "manifest": str(result.manifest_path),
                "signature": str(result.signature_path),
                "package_sha256": result.package_digest.sha256,
                "package_size": result.package_digest.size,
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
