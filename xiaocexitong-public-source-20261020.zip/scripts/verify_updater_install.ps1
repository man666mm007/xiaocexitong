[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$assistantRoot = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)) "ProbabilityQuizUpdater"
$configPath = Join-Path $assistantRoot "config.json"
$tokenPath = Join-Path $assistantRoot "agent.token"
$helperPath = Join-Path $assistantRoot "quiz-updater.pyz"
$taskName = "ProbabilityQuizUpdater"

foreach ($path in @($configPath, $tokenPath, $helperPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "更新助手缺少必要文件。" }
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$token = [System.IO.File]::ReadAllText($tokenPath, [System.Text.Encoding]::UTF8).Trim()
if ([string]::IsNullOrWhiteSpace($token)) { throw "更新助手令牌文件为空。" }

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
$taskInfo = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop
$headers = @{ "Authorization" = "Bearer $token" }
$agentStatus = Invoke-RestMethod -Method Get -Uri "http://127.0.0.1:$($config.agent_port)/v1/status" -Headers $headers -TimeoutSec 5
$siteStatus = Invoke-WebRequest -UseBasicParsing -Uri $config.site_url -TimeoutSec 5

$result = [ordered]@{
    status = "verified"
    task_state = [string]$task.State
    last_task_result = [int]$taskInfo.LastTaskResult
    site_http_status = [int]$siteStatus.StatusCode
    repository = [string]$config.repository
    current_version = [string]$agentStatus.current_version
    updater_phase = [string]$agentStatus.phase
    config_path = $configPath
}
$result | ConvertTo-Json -Depth 4 -Compress
