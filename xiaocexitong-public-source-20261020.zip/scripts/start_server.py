"""Start the local Waitress server and open the browser after it is ready."""

from __future__ import annotations

import errno
import os
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from waitress import create_server

from wsgi import app


URL = "http://127.0.0.1:5000/quiz/"
READY_TIMEOUT_SECONDS = 45


def _open_browser() -> None:
    try:
        opened = webbrowser.open(URL, new=2)
    except webbrowser.Error as exc:
        print(f"自动打开浏览器失败：{exc}", flush=True)
        opened = False
    if not opened:
        print(f"请手动访问：{URL}", flush=True)


def _open_browser_when_ready(stop_event: threading.Event) -> None:
    deadline = time.monotonic() + READY_TIMEOUT_SECONDS
    while not stop_event.is_set() and time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(URL, timeout=1) as response:
                if response.status < 500:
                    print(f"\n服务已就绪，正在打开浏览器：{URL}", flush=True)
                    _open_browser()
                    return
        except urllib.error.HTTPError as exc:
            if exc.code < 500:
                print(f"\n服务已就绪，正在打开浏览器：{URL}", flush=True)
                _open_browser()
                return
        except (OSError, urllib.error.URLError):
            pass
        stop_event.wait(0.5)

    if not stop_event.is_set():
        print(
            f"\n服务器已运行，但暂时无法确认网页响应。请手动访问：{URL}",
            flush=True,
        )


def main() -> int:
    try:
        server = create_server(app, listen=["0.0.0.0:5000"], threads=16)
    except OSError as exc:
        if getattr(exc, "winerror", None) == 10048 or exc.errno == errno.EADDRINUSE:
            print("[错误] 无法启动服务器，5000 端口已被占用。", flush=True)
            print("请关闭正在运行的本系统窗口后重试。", flush=True)
        elif isinstance(exc, PermissionError) or getattr(exc, "winerror", None) == 10013:
            print("[错误] 系统拒绝了服务的监听或本机唤醒连接。", flush=True)
            print("请检查运行权限、防火墙或安全软件限制。", flush=True)
        else:
            print("[错误] 无法启动服务器。", flush=True)
        print(f"详细信息：{exc}", flush=True)
        return 1

    print("服务器已绑定端口 5000，正在等待服务就绪……", flush=True)
    stop_event = threading.Event()
    if os.environ.get("QUIZ_MANAGED_SERVICE") != "1":
        browser_thread = threading.Thread(
            target=_open_browser_when_ready,
            args=(stop_event,),
            name="open-browser-when-ready",
            daemon=True,
        )
        browser_thread.start()

    try:
        server.run()
    finally:
        stop_event.set()
        server.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
