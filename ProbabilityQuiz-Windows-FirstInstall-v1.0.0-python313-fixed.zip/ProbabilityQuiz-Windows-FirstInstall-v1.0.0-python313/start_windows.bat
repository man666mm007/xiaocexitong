@echo off
chcp 936 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Probability Quiz System

if not defined QUIZ_INSTANCE_DIR set "QUIZ_INSTANCE_DIR=instance"
if /i "%QUIZ_INSTANCE_DIR%"=="instance_demo" goto :startup_direct
if not exist "%~dp0bootstrap-package.marker" goto :startup_direct
if not exist "%~dp0scripts\bootstrap_windows.ps1" goto :bootstrap_missing
if exist "%~dp0updater-state\install-complete.json" goto :managed_start

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\bootstrap_windows.ps1" -ProjectRoot "%~dp0."
if errorlevel 1 goto :bootstrap_failed
exit /b 0

:managed_start
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\bootstrap_windows.ps1" -ProjectRoot "%~dp0." -OpenSite
if errorlevel 1 goto :bootstrap_failed
exit /b 0

:bootstrap_missing
echo [ERROR] The first-install package is incomplete.
echo Re-extract the complete ZIP into a folder you can write to, then retry.
pause
exit /b 1

:bootstrap_failed
echo [ERROR] First install or startup failed.
echo Keep this folder and inspect the logs in:
echo "%~dp0logs"
pause
exit /b 1

:startup_direct
echo ==================================================
echo    Probability Quiz System
echo ==================================================
if /i "%QUIZ_INSTANCE_DIR%"=="instance_demo" echo Demo mode is active. Demo data is separate.
echo.
if not exist "%~dp0cache\pip" mkdir "%~dp0cache\pip" >nul 2>&1
if not exist "%~dp0cache\tmp" mkdir "%~dp0cache\tmp" >nul 2>&1
set "PIP_CACHE_DIR=%~dp0cache\pip"
set "TEMP=%~dp0cache\tmp"
set "TMP=%~dp0cache\tmp"

set "PYCMD="
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=.venv\Scripts\python.exe"
)
if not defined PYCMD if exist "python-runtime\python.exe" (
  "python-runtime\python.exe" -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=python-runtime\python.exe"
)
if not defined PYCMD (
  py -3.13 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.13"
)
if not defined PYCMD (
  py -3.12 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.12"
)
if not defined PYCMD (
  py -3.11 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=py -3.11"
)
if not defined PYCMD (
  python -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYCMD=python"
)
if not defined PYCMD (
  echo [ERROR] Python was not found.
  echo Run the first-install package from its complete folder, or install Python 3.11 or later.
  pause
  exit /b 1
)

%PYCMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if errorlevel 1 goto :failed

if not exist ".venv\Scripts\python.exe" (
  %PYCMD% -m venv .venv
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --cache-dir "%PIP_CACHE_DIR%" -r requirements.txt
if errorlevel 1 goto :failed

if not exist "secret_key.txt" (
  ".venv\Scripts\python.exe" -c "import secrets; open('secret_key.txt','w',encoding='utf-8').write(secrets.token_hex(32))"
  if errorlevel 1 goto :failed
)
set /p QUIZ_SECRET_KEY=<secret_key.txt
if not defined QUIZ_SECRET_KEY goto :failed
set "QUIZ_URL_PREFIX=/quiz"
set "QUIZ_SESSION_DAYS=7"

if not exist "%QUIZ_INSTANCE_DIR%\quiz.sqlite3" (
  set /p TEACHER_ID=Enter the teacher ID:
  set /p TEACHER_NAME=Enter the teacher name:
  ".venv\Scripts\python.exe" scripts\init_project.py --teacher-id "!TEACHER_ID!" --teacher-name "!TEACHER_NAME!"
  if errorlevel 1 goto :failed
)

echo Opening http://127.0.0.1:5000/quiz/
echo Keep this window open while the server is running. Press Ctrl+C to stop.
".venv\Scripts\python.exe" scripts\start_server.py
if errorlevel 1 goto :failed
pause
exit /b 0

:failed
echo [ERROR] Startup failed. Logs and downloads are kept in this folder.
echo "%~dp0logs"
pause
exit /b 1