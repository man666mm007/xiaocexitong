﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$PythonPath,
    [Parameter(Mandatory = $true)][string]$HelperPath,
    [Parameter(Mandatory = $true)][string]$ConfigPath,
    [Parameter(Mandatory = $true)][string]$AssistantRoot,
    [Parameter(Mandatory = $true)][string]$LogRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$python = [System.IO.Path]::GetFullPath($PythonPath)
$helper = [System.IO.Path]::GetFullPath($HelperPath)
$config = [System.IO.Path]::GetFullPath($ConfigPath)
$assistant = [System.IO.Path]::GetFullPath($AssistantRoot)
$logs = [System.IO.Path]::GetFullPath($LogRoot)
$tempRoot = Join-Path $assistant "work\temp"
$pipRoot = Join-Path $assistant "work\pip"
foreach ($path in @($tempRoot, $pipRoot, $logs)) {
    New-Item -ItemType Directory -Path $path -Force | Out-Null
}
$env:TEMP = $tempRoot
$env:TMP = $tempRoot
$env:PIP_CACHE_DIR = $pipRoot
$logPath = Join-Path $logs "updater-agent.log"
Set-Location -LiteralPath $assistant

while ($true) {
    Add-Content -LiteralPath $logPath -Encoding UTF8 -Value ("[{0}] Starting the project-local update agent." -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    try {
        $previousErrorActionPreference = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        & $python -I -S $helper --agent --config $config >> $logPath 2>&1
        $exitCode = $LASTEXITCODE
    } catch {
        Add-Content -LiteralPath $logPath -Encoding UTF8 -Value ("[{0}] Launcher error: {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $_.Exception.Message)
        $exitCode = 1
    } finally {
        $ErrorActionPreference = $previousErrorActionPreference
    }
    Add-Content -LiteralPath $logPath -Encoding UTF8 -Value ("[{0}] Agent exited with code {1}; retrying in 15 seconds." -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $exitCode)
    Start-Sleep -Seconds 15
}
