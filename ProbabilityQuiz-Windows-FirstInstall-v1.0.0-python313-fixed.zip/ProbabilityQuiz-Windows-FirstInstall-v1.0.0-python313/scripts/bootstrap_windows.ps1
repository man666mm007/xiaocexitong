﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProjectRoot,
    [switch]$WhatIf,
    [switch]$OpenSite
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
Import-Module Microsoft.PowerShell.Utility -ErrorAction Stop

$script:PackageId = "windows-first-install-v1"
$script:BaseVersion = "1.0.0"
$script:Repository = "man666mm007/xiaocexitong"
$script:Mirror = "https://pypi.tuna.tsinghua.edu.cn/simple"
$script:PythonRuntimeVersion = "3.13.15"
$script:PythonRuntimeUrl = "https://www.python.org/ftp/python/3.13.15/python-3.13.15-amd64.exe"
$script:PythonRuntimeSha256 = "edec09c4853aeae9ac36efb8c9f95b6b8e2fee65eee56d9767a8b7c69c574403"
$script:PythonRuntimeSigner = "Python Software Foundation"
$script:PackageRoot = [System.IO.Path]::GetFullPath($ProjectRoot).TrimEnd('\', '/')
$script:InstallRoot = Join-Path $script:PackageRoot "program"
$script:DataRoot = Join-Path $script:PackageRoot "data"
$script:BackupRoot = Join-Path $script:PackageRoot "backups"
$script:AssistantRoot = Join-Path $script:PackageRoot "updater-state"
$script:PythonRoot = Join-Path $script:PackageRoot "python-runtime"
$script:DownloadRoot = Join-Path $script:PackageRoot "downloads"
$script:LogRoot = Join-Path $script:PackageRoot "logs"
$script:CacheRoot = Join-Path $script:PackageRoot "cache"
$script:TemporaryRoot = Join-Path $script:CacheRoot "tmp"
$script:PipCacheRoot = Join-Path $script:CacheRoot "pip"
$script:LogPath = ""

function Get-FullPath([string]$Value) {
    return [System.IO.Path]::GetFullPath($Value).TrimEnd('\', '/')
}

function Test-PathOverlap([string]$Left, [string]$Right) {
    $a = Get-FullPath $Left
    $b = Get-FullPath $Right
    return ($a.Equals($b, [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '/', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '/', [System.StringComparison]::OrdinalIgnoreCase))
}

function Invoke-Icacls([string[]]$Arguments) {
    & "$env:SystemRoot\System32\icacls.exe" @Arguments | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Windows 文件权限设置失败。" }
}

function Get-PortConflicts([int]$Port) {
    $listeners = @()
    try {
        $listeners = @([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() |
            Where-Object { $_.Port -eq $Port })
    } catch {
        return @([ordered]@{ pid = 0; executable = "无法查询监听进程" })
    }
    $pids = @()
    foreach ($listener in $listeners) {
        try {
            $connections = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop |
                Where-Object { $_.LocalAddress -eq $listener.Address.ToString() -or $_.LocalAddress -eq "0.0.0.0" -or $_.LocalAddress -eq "::" })
            foreach ($connection in $connections) { $pids += [int]$connection.OwningProcess }
        } catch {
            try {
                $connections = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop)
                foreach ($connection in $connections) { $pids += [int]$connection.OwningProcess }
            } catch { }
        }
    }
    $result = @()
    foreach ($processId in @($pids | Sort-Object -Unique)) {
        $executable = "无法读取可执行文件路径"
        try {
            $process = Get-Process -Id $processId -ErrorAction Stop
            if ($process.Path) { $executable = [string]$process.Path }
        } catch { }
        $result += [ordered]@{ pid = [int]$processId; executable = $executable }
    }
    if ($listeners.Count -gt 0 -and $result.Count -eq 0) {
        $result += [ordered]@{ pid = 0; executable = "端口已监听，但无法读取进程信息" }
    }
    return $result
}

function Get-PythonRuntime {
    $candidates = @((Join-Path $script:PythonRoot "python.exe"))

    foreach ($registryPath in @(
        "HKLM:\SOFTWARE\Python\PythonCore\3.13\InstallPath",
        "HKLM:\SOFTWARE\WOW6432Node\Python\PythonCore\3.13\InstallPath",
        "HKCU:\SOFTWARE\Python\PythonCore\3.13\InstallPath"
    )) {
        try {
            $registryKey = Get-Item -LiteralPath $registryPath -ErrorAction Stop
            $installDirectory = [string]$registryKey.GetValue("")
            if ($installDirectory) { $candidates += (Join-Path $installDirectory "python.exe") }
        } catch { }
    }

    foreach ($directory in @(
        (Join-Path $env:ProgramFiles "Python313"),
        (Join-Path $env:ProgramFiles "Python 3.13"),
        (Join-Path $env:LOCALAPPDATA "Programs\Python\Python313")
    )) {
        if ($directory) { $candidates += (Join-Path $directory "python.exe") }
    }

    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher -and $launcher.Source) {
        try {
            $launcherLines = @(& $launcher.Source -3.13 -c "import sys; print(sys.executable)" 2>$null)
            if ($LASTEXITCODE -eq 0 -and $launcherLines.Count -gt 0) {
                $candidates += [string]($launcherLines | Select-Object -Last 1).Trim()
            }
        } catch { }
    }

    foreach ($commandName in @("python.exe", "python3.13.exe")) {
        $pathPython = Get-Command $commandName -ErrorAction SilentlyContinue
        if ($pathPython -and $pathPython.Source) { $candidates += [string]$pathPython.Source }
    }

    $probeCode = "import struct,sys;print('|'.join((sys.executable,sys.base_prefix,'.'.join(map(str,sys.version_info[:3])),str(struct.calcsize('P')*8),sys.implementation.name)))"
    foreach ($candidate in @($candidates | Select-Object -Unique)) {
        try {
            if ([string]$candidate -match '(?i)\\Microsoft\\WindowsApps\\') { continue }
            if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
            $python = Get-FullPath ([string]$candidate)
            $probeLines = @(& $python -I -c $probeCode 2>$null)
            $probeExitCode = $LASTEXITCODE
            if ($probeExitCode -ne 0 -or $probeLines.Count -eq 0) { continue }
            $probeFields = @(($probeLines | Select-Object -Last 1).Trim() -split '\|')
            if ($probeFields.Count -ne 5) { continue }
            $version = @($probeFields[2].Split('.') | ForEach-Object { [int]$_ })
            if ($version.Count -lt 3 -or $version[0] -ne 3 -or $version[1] -ne 13 -or $version[2] -lt 15) { continue }
            if ([int]$probeFields[3] -ne 64 -or [string]$probeFields[4] -ne "cpython") { continue }
            return [ordered]@{
                executable = (Get-FullPath ([string]$probeFields[0]))
                base_prefix = (Get-FullPath ([string]$probeFields[1]))
                version = ($version -join ".")
            }
        } catch { continue }
    }
    return $null
}

function Install-PythonRuntime($Package) {
    $lockPath = [string]$Package.members["bootstrap-assets/python-runtime.json"]
    $runtimeSpec = Get-Content -LiteralPath $lockPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$runtimeSpec.version -ne $script:PythonRuntimeVersion -or
        [string]$runtimeSpec.url -ne $script:PythonRuntimeUrl -or
        [string]$runtimeSpec.sha256 -ne $script:PythonRuntimeSha256 -or
        [string]$runtimeSpec.signer_subject -ne $script:PythonRuntimeSigner -or
        [string]$runtimeSpec.install_scope -ne "project_local") {
        throw "Python 运行时锁文件与启动器内置的安全策略不一致。"
    }

    if (-not [Environment]::Is64BitOperatingSystem) { throw "此首装包需要 64 位 Windows，无法安装 Python x64。" }
    $installerPath = Join-Path $script:DownloadRoot "python-$script:PythonRuntimeVersion-amd64.exe"
    $installLog = Join-Path $script:LogRoot ("python-install-{0}-{1}.log" -f $script:PythonRuntimeVersion, (Get-Date -Format "yyyyMMdd-HHmmss"))
    Write-Host "正在从 Python.org 下载 Python $script:PythonRuntimeVersion x64（约 30 MB）……"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try {
        Invoke-WebRequest -Uri $script:PythonRuntimeUrl -OutFile $installerPath -UseBasicParsing
        $actualHash = (Get-FileHash -LiteralPath $installerPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $script:PythonRuntimeSha256) { throw "Python 安装器 SHA-256 校验失败。" }
        $signature = Get-AuthenticodeSignature -LiteralPath $installerPath
        if ($signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid -or
            -not $signature.SignerCertificate -or
            $signature.SignerCertificate.Subject -notlike "*$script:PythonRuntimeSigner*") {
            throw "Python 安装器数字签名无效或发布者不匹配。"
        }

        Write-Host "已验证 Python.org 安装器。正在安装到所有用户可用的位置……"
        $argumentLine = "/passive InstallAllUsers=0 TargetDir=$(Quote-ProcessArgument $script:PythonRoot) PrependPath=0 Include_launcher=0 Include_pip=1 Include_test=0 Include_doc=0 Include_tcltk=0 Shortcuts=0 /log $(Quote-ProcessArgument $installLog)"
        $process = Start-Process -FilePath $installerPath -ArgumentList $argumentLine -Wait -PassThru
        if ($process.ExitCode -ne 0) { throw "Python 安装器退出码为 $($process.ExitCode)。请查看安装日志：$installLog" }
        $runtime = Get-PythonRuntime
        if (-not $runtime) { throw "Python 安装器已退出，但没有检测到可用的 64 位 Python 3.13.15 或更新补丁版。日志：$installLog" }
        Write-Host "Python $($runtime.version) 已就绪。"
        return $runtime
    } catch {
        throw "Python download or installation failed: $($_.Exception.Message). Installer log: $installLog"
    }
}
function Test-PackageMember([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name) -or $Name.Contains('\') -or $Name.StartsWith('/')) { return $false }
    $parts = $Name.Split('/')
    if ($parts -contains ".." -or $parts -contains "." -or $parts -contains "__pycache__") { return $false }
    $rootFiles = @("VERSION", "requirements.txt", "run.py", "wsgi.py", "start_windows.bat", "README.md", "USER_GUIDE.md", "bootstrap-package.marker")
    $scriptFiles = @("bootstrap_windows.ps1", "init_project.py", "install_program_version.py", "install_updater.ps1", "run_updater_agent.ps1", "start_server.py", "verify_updater_install.ps1")
    if ($rootFiles -contains $Name) { return $true }
    if ($Name -eq "docs/TEACHER_FIRST_INSTALL_WINDOWS.md") { return $true }
    if ($Name -in @("bootstrap-assets/release-public.pem", "bootstrap-assets/quiz-updater.pyz", "bootstrap-assets/python-runtime.json")) { return $true }
    if ($Name -like "scripts/*") { return $scriptFiles -contains $Name.Substring(8) }
    if ($parts[0] -in @("app", "updater") -and $parts.Count -ge 2) {
        $extension = [System.IO.Path]::GetExtension($Name).ToLowerInvariant()
        return $extension -in @(".py", ".html", ".css", ".js", ".svg", ".sql")
    }
    return $false
}

function Get-ValidatedPackage([string]$Root) {
    if (-not (Test-Path -LiteralPath (Join-Path $Root "bootstrap-package.marker") -PathType Leaf)) { throw "首装包标记缺失。请完整解压官方首装 ZIP。" }
    $marker = (Get-Content -LiteralPath (Join-Path $Root "bootstrap-package.marker") -Raw -Encoding ASCII).Trim()
    if ($marker -ne $script:PackageId) { throw "首装包标记无效。" }
    $version = (Get-Content -LiteralPath (Join-Path $Root "VERSION") -Raw -Encoding ASCII).Trim()
    if ($version -ne $script:BaseVersion) { throw "首装包版本必须是 $script:BaseVersion。" }
    $manifestPath = Join-Path $Root "bootstrap-package.json"
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw "首装包校验清单缺失。" }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.package_id -ne $script:PackageId -or $manifest.base_version -ne $script:BaseVersion) { throw "首装包校验清单与应用版本不匹配。" }

    $required = @(
        "VERSION", "requirements.txt", "start_windows.bat", "app/__init__.py", "updater/__init__.py",
        "scripts/bootstrap_windows.ps1", "scripts/init_project.py", "scripts/install_program_version.py",
        "scripts/install_updater.ps1", "scripts/run_updater_agent.ps1", "scripts/start_server.py", "scripts/verify_updater_install.ps1",
        "bootstrap-assets/release-public.pem", "bootstrap-assets/quiz-updater.pyz", "bootstrap-assets/python-runtime.json", "bootstrap-package.marker",
        "docs/TEACHER_FIRST_INSTALL_WINDOWS.md"
    )
    $members = @{}
    foreach ($property in $manifest.files.PSObject.Properties) {
        $name = [string]$property.Name
        if (-not (Test-PackageMember $name)) { throw "首装包包含未经批准的文件路径：$name" }
        $expected = [string]$property.Value
        if ($expected -notmatch '^[0-9a-fA-F]{64}$') { throw "首装包校验清单中的摘要无效：$name" }
        $filePath = Join-Path $Root ($name.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) { throw "首装包文件缺失：$name" }
        $actual = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash
        if ($actual -ne $expected) { throw "首装包文件校验失败：$name" }
        $members[$name] = $filePath
    }
    foreach ($name in $required) {
        if (-not $members.ContainsKey($name)) { throw "首装包缺少必需文件：$name" }
    }
    return [ordered]@{ root = $Root; marker = $marker; version = $version; manifest = $manifest; members = $members }
}

function Get-GitHubRepositoryStatus {
    try {
        $headers = @{ Accept = "application/vnd.github+json"; "User-Agent" = "ProbabilityQuizFirstInstall" }
        $response = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$script:Repository" -Headers $headers -TimeoutSec 15
        return [ordered]@{ reachable = ($response.full_name -ceq $script:Repository -and $response.private -eq $false); full_name = [string]$response.full_name }
    } catch {
        return [ordered]@{ reachable = $false; full_name = "" }
    }
}

function New-PreflightPlan($Package, $Python, $PortConflicts, $RepositoryStatus) {
    $blockers = @()
    if (Test-Path -LiteralPath (Join-Path $script:AssistantRoot "install-complete.json")) { $blockers += "This project folder is already installed. Use start_windows.bat to open it." }
    if ($PortConflicts.Count -gt 0) { $blockers += "5000 端口已被占用；请先按旧服务原有方式停止它。" }
    if (-not $RepositoryStatus.reachable) { $blockers += "GitHub 更新仓库当前不可访问或仓库名称不匹配。" }
    if ((Test-PathOverlap $script:InstallRoot $script:DataRoot) -or
        (Test-PathOverlap $script:InstallRoot $script:BackupRoot) -or (Test-PathOverlap $script:DataRoot $script:BackupRoot) -or
        (Test-PathOverlap $script:AssistantRoot $script:BackupRoot) -or
        (Test-PathOverlap $script:AssistantRoot $script:InstallRoot) -or (Test-PathOverlap $script:AssistantRoot $script:DataRoot)) {
        $blockers += "程序、数据、助手和首装备份路径必须互不重叠。"
    }
    return [ordered]@{
        status = if ($blockers.Count -eq 0) { "ready" } else { "blocked" }
        package_id = $script:PackageId
        base_version = $Package.version
        repository = $script:Repository
        repository_reachable = [bool]$RepositoryStatus.reachable
        python = if ($Python) { $Python.executable } else { "" }
        python_version = if ($Python) { $Python.version } else { "" }
        python_install_required = ($null -eq $Python)
        python_install_version = $script:PythonRuntimeVersion
        dependency_mirror = $script:Mirror
        listener = "0.0.0.0:5000/quiz/"
        port_conflicts = @($PortConflicts)
        paths = [ordered]@{
            package_source = $Package.root
            program_root = $script:InstallRoot
            data_root = $script:DataRoot
            backup_root = $script:BackupRoot
            assistant_root = $script:AssistantRoot
            python_root = $script:PythonRoot
            download_root = $script:DownloadRoot
            log_root = $script:LogRoot
        }
        blockers = @($blockers)
    }
}

function Quote-ProcessArgument([string]$Value) {
    return '"' + $Value + '"'
}

function Get-UpdaterTaskName([string]$Root) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes((Get-FullPath $Root).ToLowerInvariant())
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $digest = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace("-", "").Substring(0, 12)
    } finally {
        $sha.Dispose()
    }
    return "ProbabilityQuizUpdater-$digest"
}

function Initialize-LocalDirectories {
    foreach ($path in @($script:BackupRoot, $script:DownloadRoot, $script:LogRoot, $script:TemporaryRoot, $script:PipCacheRoot)) {
        New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
    $env:TEMP = $script:TemporaryRoot
    $env:TMP = $script:TemporaryRoot
    $env:PIP_CACHE_DIR = $script:PipCacheRoot
}

function ConvertTo-AsciiJson($Value) {
    $json = $Value | ConvertTo-Json -Depth 8 -Compress
    $builder = New-Object System.Text.StringBuilder
    foreach ($character in $json.ToCharArray()) {
        if ([int]$character -gt 127) {
            [void]$builder.Append(("\u{0:x4}" -f [int]$character))
        } else {
            [void]$builder.Append($character)
        }
    }
    return $builder.ToString()
}

function Set-ApplicationSecretAcl([string]$Path) {
    $system = "*S-1-5-18"
    $admin = "*S-1-5-32-544"
    $currentUser = "*" + [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    Invoke-Icacls @($Path, "/inheritance:r")
    Invoke-Icacls @($Path, "/grant:r", "$system`:(F)", "$admin`:(F)", "$currentUser`:(F)")
}

function Copy-PackageIntoProgramRoot($Package) {
    New-Item -ItemType Directory -Path $script:InstallRoot -Force | Out-Null
    foreach ($name in @($Package.members.Keys | Sort-Object)) {
        $source = $Package.members[$name]
        $destination = Join-Path $script:InstallRoot ($name.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        $destinationFullPath = [System.IO.Path]::GetFullPath($destination)
        if (-not $destinationFullPath.StartsWith((Get-FullPath $script:InstallRoot) + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase) -and
            -not $destinationFullPath.Equals((Get-FullPath $script:InstallRoot), [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "程序文件路径越出安装目录：$name"
        }
        $destinationDirectory = Split-Path -Parent $destinationFullPath
        New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destinationFullPath -Force
    }
    Copy-Item -LiteralPath (Join-Path $Package.root "bootstrap-package.json") -Destination (Join-Path $script:InstallRoot "bootstrap-package.json") -Force
}

function Get-ValidatedUrl([string]$Prompt, [bool]$Optional) {
    $value = (Read-Host $Prompt).Trim()
    if ($Optional -and -not $value) { return "" }
    if (-not $value) { throw "此项不能为空。" }
    $uri = $null
    if (-not [Uri]::TryCreate($value, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -notin @("http", "https")) {
        throw "请输入完整的 http:// 或 https:// 地址。"
    }
    return $value.TrimEnd('/')
}

function Invoke-InstalledOpenSite([string]$PackageRoot) {
    $package = Get-ValidatedPackage $PackageRoot
    $bindingPath = Join-Path $script:AssistantRoot "install_root.txt"
    $helperPath = Join-Path $script:AssistantRoot "quiz-updater.pyz"
    if (-not (Test-Path -LiteralPath $bindingPath -PathType Leaf) -or -not (Test-Path -LiteralPath $helperPath -PathType Leaf)) {
        throw "更新助手安装记录缺失；请管理员检查首装状态。"
    }
    $binding = Get-Content -LiteralPath $bindingPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($binding.package_id -ne $script:PackageId -or [string]::IsNullOrWhiteSpace([string]$binding.install_root)) {
        throw "此首装包与当前更新助手安装不匹配。"
    }
    $installedRoot = Get-FullPath ([string]$binding.install_root)
    $python = Join-Path $installedRoot ".venv\Scripts\python.exe"
    if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw "已安装的 Python 环境缺失，请联系管理员。" }
    $taskName = Get-UpdaterTaskName $script:AssistantRoot
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if (-not $task) { throw "The project-local updater task is missing. Inspect the logs under the project folder." }
    if ([string]$task.State -ne "Running") { Start-ScheduledTask -TaskName $taskName }
    & $python -I -S $helperPath --open-site
    if ($LASTEXITCODE -ne 0) { throw "网站尚未就绪。请稍后重试；若仍失败，请联系管理员。" }
}

try {
    $packageRoot = Get-FullPath $ProjectRoot
    if (-not (Test-Path -LiteralPath $packageRoot -PathType Container)) { throw "首装包目录不存在：$packageRoot" }
    if ($OpenSite) {
        Invoke-InstalledOpenSite $packageRoot
        exit 0
    }

    $package = Get-ValidatedPackage $packageRoot
    if (-not $WhatIf) {
        $existingTaskName = Get-UpdaterTaskName $script:AssistantRoot
        try {
            $existingTask = Get-ScheduledTask -TaskName $existingTaskName -ErrorAction SilentlyContinue
        } catch {
            throw "Windows Task Scheduler is unavailable for the current user. Start the Task Scheduler service and retry."
        }
        if ($existingTask -and [string]$existingTask.State -eq "Running") {
            Stop-ScheduledTask -TaskName $existingTaskName -ErrorAction Stop
            for ($attempt = 0; $attempt -lt 20; $attempt++) {
                if (@(Get-PortConflicts 5000).Count -eq 0) { break }
                Start-Sleep -Milliseconds 250
            }
        }
    }    $runtime = Get-PythonRuntime
    $portConflicts = @(Get-PortConflicts 5000)
    $repositoryStatus = Get-GitHubRepositoryStatus
    $plan = New-PreflightPlan $package $runtime $portConflicts $repositoryStatus
    if ($WhatIf) {
        ConvertTo-AsciiJson $plan
        if ($plan.blockers.Count -gt 0) { exit 1 }
        exit 0
    }
    if ($plan.blockers.Count -gt 0) {
        foreach ($blocker in $plan.blockers) { Write-Host "[停止] $blocker" -ForegroundColor Red }
        foreach ($conflict in $plan.port_conflicts) {
            Write-Host ("PID={0}; 程序={1}" -f $conflict.pid, $conflict.executable) -ForegroundColor Yellow
        }
        throw "首装前检查未通过；没有停止或修改未知进程。"
    }

    Initialize-LocalDirectories

    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    New-Item -ItemType Directory -Path $script:BackupRoot -Force | Out-Null
    $logPath = Join-Path $script:LogRoot "bootstrap-$timestamp.log"
    $script:LogPath = $logPath
    Start-Transcript -LiteralPath $logPath -Force | Out-Null
    Write-Host "Installing into: $script:InstallRoot"
    Write-Host "Data folder: $script:DataRoot"
    Write-Host "Logs and downloads: $script:LogRoot; $script:DownloadRoot"

    if (-not $runtime) {
        if (Test-Path -LiteralPath $script:PythonRoot) {
            $pythonRootFull = Get-FullPath $script:PythonRoot
            $packageRootFull = Get-FullPath $script:PackageRoot
            if (-not $pythonRootFull.StartsWith($packageRootFull + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "The Python runtime repair path is outside the project folder."
            }
            Remove-Item -LiteralPath $pythonRootFull -Recurse -Force
        }
        $runtime = Install-PythonRuntime $package
    }

    $httpsAnswer = (Read-Host "旧网站是否使用 HTTPS？输入 y 或 n").Trim().ToLowerInvariant()
    if ($httpsAnswer -notin @("y", "yes", "n", "no")) { throw "请输入 y 或 n。" }
    $env:QUIZ_HTTPS = if ($httpsAnswer -in @("y", "yes")) { "1" } else { "0" }
    $env:PUBLIC_BASE_URL = Get-ValidatedUrl "外部访问基础地址（没有则留空）" $true
    $env:COURSEWARE_URL = Get-ValidatedUrl "课程资源地址（没有则留空）" $true
    $initializeDatabase = -not (Test-Path -LiteralPath (Join-Path $script:DataRoot "quiz.sqlite3"))
    $teacherId = ""
    $teacherName = ""
    if ($initializeDatabase) {
        $teacherId = (Read-Host "Teacher ID (1 to 64 characters)").Trim()
        $teacherName = (Read-Host "Teacher name (1 to 100 characters)").Trim()
        if ($teacherId.Length -lt 1 -or $teacherId.Length -gt 64) { throw "Teacher ID must contain 1 to 64 characters." }
        if ($teacherName.Length -lt 1 -or $teacherName.Length -gt 100) { throw "Teacher name must contain 1 to 100 characters." }
    }

    Copy-PackageIntoProgramRoot $package
    $programAcl = Join-Path $script:InstallRoot ".venv"
    $programPython = Join-Path $programAcl "Scripts\python.exe"
    New-Item -ItemType Directory -Path $script:DataRoot -Force | Out-Null
    foreach ($directory in @("uploads", "pending")) { New-Item -ItemType Directory -Path (Join-Path $script:DataRoot $directory) -Force | Out-Null }

    $installerPython = $runtime.executable
    if (Test-Path -LiteralPath $programPython -PathType Leaf) {
        & $programPython -I -c "import sys, pip" >$null 2>&1
        if ($LASTEXITCODE -ne 0) {
            $venvFull = Get-FullPath $programAcl
            $programRootFull = Get-FullPath $script:InstallRoot
            if (-not $venvFull.StartsWith($programRootFull + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "The application environment repair path is outside the project folder."
            }
            Remove-Item -LiteralPath $venvFull -Recurse -Force
        }
    }
    if (-not (Test-Path -LiteralPath $programPython -PathType Leaf)) {
        & $installerPython -I -m venv $programAcl
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $programPython -PathType Leaf)) { throw "Python 虚拟环境创建失败。" }
    }
    & $programPython -I -m pip install --disable-pip-version-check --no-input --retries 3 --cache-dir $script:PipCacheRoot --index-url $script:Mirror -r (Join-Path $script:InstallRoot "requirements.txt")
    if ($LASTEXITCODE -ne 0) { throw "依赖安装失败；请检查网络或清华 PyPI 镜像后重试。日志：$logPath" }
    & $programPython -I -m pip check
    if ($LASTEXITCODE -ne 0) { throw "Python 依赖一致性检查失败。" }

    $secretPath = Join-Path $script:InstallRoot "secret_key.txt"
    if (Test-Path -LiteralPath $secretPath) {
        $secret = [System.IO.File]::ReadAllText($secretPath, [System.Text.Encoding]::ASCII).Trim()
        if ($secret.Length -lt 64) { throw "The project-local secret key is invalid." }
    } else {
        $secretBytes = New-Object byte[] 32
        $random = [Security.Cryptography.RandomNumberGenerator]::Create()
        try { $random.GetBytes($secretBytes) } finally { $random.Dispose() }
        $secret = [BitConverter]::ToString($secretBytes).Replace("-", "").ToLowerInvariant()
        [System.IO.File]::WriteAllText($secretPath, $secret, [System.Text.Encoding]::ASCII)
    }
    Set-ApplicationSecretAcl $secretPath

    $env:QUIZ_INSTANCE_DIR = $script:DataRoot
    $env:QUIZ_SECRET_KEY = $secret
    $env:QUIZ_URL_PREFIX = "/quiz"
    $env:QUIZ_SESSION_DAYS = "7"
    if ($initializeDatabase) {
        & $programPython (Join-Path $script:InstallRoot "scripts\init_project.py") --teacher-id $teacherId --teacher-name $teacherName
        if ($LASTEXITCODE -ne 0) { throw "Teacher account and database initialization failed." }
    } else {
        Write-Host "Existing project data found. Keeping the existing database and teacher accounts."
    }

    $publicKey = Join-Path $script:InstallRoot "bootstrap-assets\release-public.pem"
    $helper = Join-Path $script:InstallRoot "bootstrap-assets\quiz-updater.pyz"
    $installer = Join-Path $script:InstallRoot "scripts\install_updater.ps1"
    $verify = Join-Path $script:InstallRoot "scripts\verify_updater_install.ps1"
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer,
        "-ProjectRoot", $script:InstallRoot,
        "-DataRoot", $script:DataRoot,
        "-Repository", $script:Repository,
        "-PublicKey", $publicKey,
        "-HelperPackage", $helper,
        "-PythonPath", $programPython,
        "-BackupRoot", $script:BackupRoot,
        "-AssistantRoot", $script:AssistantRoot,
        "-LogRoot", $script:LogRoot,
        "-Port", "5000",
        "-UrlPrefix", "/quiz",
        "-WhatIf"
    )
    $whatIfJson = & powershell.exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "更新助手安装预检失败；没有安装计划任务。" }
    $installerPlan = ($whatIfJson -join "`n") | ConvertFrom-Json
    if ($installerPlan.paths.project_root -ne $script:InstallRoot -or $installerPlan.paths.data_root -ne $script:DataRoot -or $installerPlan.paths.backup_root -ne $script:BackupRoot -or $installerPlan.paths.assistant_root -ne $script:AssistantRoot -or $installerPlan.paths.log_root -ne $script:LogRoot) {
        throw "更新助手安装预检返回的目录与首装计划不一致。"
    }
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer,
        "-ProjectRoot", $script:InstallRoot,
        "-DataRoot", $script:DataRoot,
        "-Repository", $script:Repository,
        "-PublicKey", $publicKey,
        "-HelperPackage", $helper,
        "-PythonPath", $programPython,
        "-BackupRoot", $script:BackupRoot,
        "-AssistantRoot", $script:AssistantRoot,
        "-LogRoot", $script:LogRoot,
        "-Port", "5000",
        "-UrlPrefix", "/quiz"
    )
    $installJson = & powershell.exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "更新助手安装失败。保留安装目录、数据目录和备份以供管理员恢复。" }
    $installResult = ($installJson -join "`n") | ConvertFrom-Json
    if ($installResult.status -ne "installed" -or $installResult.version -ne $script:BaseVersion) { throw "更新助手返回的安装状态或版本不匹配。" }

    $verifyJson = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $verify -AssistantRoot $script:AssistantRoot
    if ($LASTEXITCODE -ne 0) { throw "更新助手已安装，但只读健康检查失败。请保留备份和日志。" }
    $verification = ($verifyJson -join "`n") | ConvertFrom-Json
    if ($verification.status -ne "verified" -or $verification.current_version -ne $script:BaseVersion -or [int]$verification.site_http_status -ge 500) {
        throw "网站健康检查没有确认首装成功。请保留备份和日志。"
    }

    $completionPath = Join-Path $script:AssistantRoot "install-complete.json"
    $completion = [ordered]@{ package_id = $script:PackageId; version = $script:BaseVersion; install_root = $script:InstallRoot; data_root = $script:DataRoot; installed_at = (Get-Date).ToString("o") }
    [System.IO.File]::WriteAllText($completionPath, ($completion | ConvertTo-Json -Compress), (New-Object System.Text.UTF8Encoding($false)))

    Write-Host "Installation succeeded. Version: $($verification.current_version)"
    Write-Host "Website: http://127.0.0.1:5000/quiz/"
    Write-Host "Backup: $($installResult.backup)"
    Write-Host "Installer log: $logPath"
    & $programPython -I -S (Join-Path $script:AssistantRoot "quiz-updater.pyz") --open-site
    if ($LASTEXITCODE -ne 0) { throw "首装完成，但网页未能打开；请手动访问 http://127.0.0.1:5000/quiz/。" }
} catch {
    Write-Host "[首装失败] $($_.Exception.Message)" -ForegroundColor Red
    if ($script:LogPath) { Write-Host "Installer log: $script:LogPath" }
    if ($script:BackupRoot -and (Test-Path -LiteralPath $script:BackupRoot)) {
        Write-Host "如已开始写入，请管理员先保留以下目录中的文件：$script:BackupRoot" -ForegroundColor Yellow
    }
    exit 1
} finally {
    if ($WhatIf -eq $false -and -not $OpenSite) {
        try { Stop-Transcript | Out-Null } catch { }
    }
}
