﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProjectRoot,
    [Parameter(Mandatory = $true)][string]$DataRoot,
    [Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$PublicKey,
    [Parameter(Mandatory = $true)][string]$HelperPackage,
    [Parameter(Mandatory = $true)][string]$PythonPath,
    [Parameter(Mandatory = $true)][string]$BackupRoot,
    [Parameter(Mandatory = $true)][string]$AssistantRoot,
    [Parameter(Mandatory = $true)][string]$LogRoot,
    [string]$KeyId = "release-2026",
    [int]$Port = 5000,
    [string]$UrlPrefix = "/quiz",
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-FullPath([string]$PathValue, [string]$Name, [bool]$MustExist) {
    if (-not [System.IO.Path]::IsPathRooted($PathValue)) { throw "$Name must be an absolute path." }
    $full = [System.IO.Path]::GetFullPath($PathValue)
    if ($MustExist -and -not (Test-Path -LiteralPath $full)) { throw "$Name does not exist." }
    $trimmed = $full.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    $root = [System.IO.Path]::GetPathRoot($full)
    if ($trimmed.Equals($root.TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar), [System.StringComparison]::OrdinalIgnoreCase)) {
        return $root
    }
    return $trimmed
}

function Test-PathOverlap([string]$Left, [string]$Right) {
    $a = [System.IO.Path]::GetFullPath($Left).TrimEnd('\', '/')
    $b = [System.IO.Path]::GetFullPath($Right).TrimEnd('\', '/')
    return ($a.Equals($b, [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '/', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '/', [System.StringComparison]::OrdinalIgnoreCase))
}

function Test-IsChildPath([string]$PathValue, [string]$ParentValue) {
    $child = [System.IO.Path]::GetFullPath($PathValue).TrimEnd('\', '/')
    $parent = [System.IO.Path]::GetFullPath($ParentValue).TrimEnd('\', '/')
    return $child.StartsWith($parent + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-UpdaterTaskName([string]$Root) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes([System.IO.Path]::GetFullPath($Root).ToLowerInvariant())
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $digest = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace("-", "").Substring(0, 12)
    } finally {
        $sha.Dispose()
    }
    return "ProbabilityQuizUpdater-$digest"
}

function Quote-ProcessArgument([string]$Value) {
    return '"' + $Value + '"'
}

function Invoke-Icacls([string[]]$Arguments) {
    & "$env:SystemRoot\System32\icacls.exe" @Arguments | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not protect the updater token file with Windows ACLs." }
}

$ProjectRoot = Get-FullPath $ProjectRoot "ProjectRoot" $true
$DataRoot = Get-FullPath $DataRoot "DataRoot" $true
$PublicKey = Get-FullPath $PublicKey "PublicKey" $true
$HelperPackage = Get-FullPath $HelperPackage "HelperPackage" $true
$PythonPath = Get-FullPath $PythonPath "PythonPath" $true
$BackupRoot = Get-FullPath $BackupRoot "BackupRoot" $false
$AssistantRoot = Get-FullPath $AssistantRoot "AssistantRoot" $false
$LogRoot = Get-FullPath $LogRoot "LogRoot" $false
$packageRoot = Split-Path -Parent $ProjectRoot
$assistantRoot = $AssistantRoot
$versionsRoot = Join-Path $assistantRoot "versions"
$workRoot = Join-Path $assistantRoot "work"
$installedKey = Join-Path $assistantRoot "release-public.pem"
$installedHelper = Join-Path $assistantRoot "quiz-updater.pyz"
$installationBindingPath = Join-Path $assistantRoot "install_root.txt"
$configPath = Join-Path $assistantRoot "config.json"
$tokenPath = Join-Path $assistantRoot "agent.token"
$taskName = Get-UpdaterTaskName $assistantRoot
$agentLauncher = Join-Path $ProjectRoot "scripts\run_updater_agent.ps1"

if (-not (Test-IsChildPath $ProjectRoot $packageRoot)) { throw "ProjectRoot must be inside the package folder." }
foreach ($localRoot in @($DataRoot, $BackupRoot, $AssistantRoot, $LogRoot)) {
    if (-not (Test-IsChildPath $localRoot $packageRoot)) { throw "Data, backup, updater, and log folders must stay inside the package folder." }
}
$separateRoots = @($ProjectRoot, $DataRoot, $BackupRoot, $AssistantRoot, $LogRoot)
for ($i = 0; $i -lt $separateRoots.Count; $i++) {
    for ($j = $i + 1; $j -lt $separateRoots.Count; $j++) {
        if (Test-PathOverlap $separateRoots[$i] $separateRoots[$j]) { throw "Project-local folders must not overlap." }
    }
}
if (-not (Test-IsChildPath $PublicKey $ProjectRoot) -or -not (Test-IsChildPath $HelperPackage $ProjectRoot) -or
    -not (Test-IsChildPath $PythonPath $ProjectRoot)) {
    throw "The public key, updater helper, and Python runtime must stay inside the program folder."
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "VERSION") -PathType Leaf)) { throw "VERSION is missing." }
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "secret_key.txt") -PathType Leaf)) { throw "secret_key.txt is missing." }
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "scripts\install_program_version.py") -PathType Leaf)) { throw "The version installer is missing." }
if (-not (Test-Path -LiteralPath $agentLauncher -PathType Leaf)) { throw "The project-local updater launcher is missing." }
if ($Repository -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { throw "Repository must use owner/name format." }
if ($KeyId -notmatch '^[A-Za-z0-9_.-]{1,64}$') { throw "KeyId is invalid." }
if ($Port -ne 5000) { throw "This package supports port 5000 only." }
if ($UrlPrefix -ne "/quiz") { throw "This package supports the /quiz URL prefix only." }

$version = (Get-Content -LiteralPath (Join-Path $ProjectRoot "VERSION") -Raw -Encoding ASCII).Trim()
if ($version -ne "1.0.0") { throw "First install supports program version 1.0.0 only." }
$plan = [ordered]@{
    status = if ($WhatIf) { "what-if" } else { "validated" }
    repository = $Repository
    program_version = $version
    listener = "127.0.0.1:$Port/quiz/"
    actions = @(
        "Keep the program, data, backups, updater state, downloads, cache, and logs in this package folder.",
        "Create a verified local backup of the program and data before starting the updater.",
        "Prepare version 1.0.0 and its active-version pointer.",
        "Run the update agent as the current Windows user at sign-in.",
        "Verify the local site, update agent, and database."
    )
    paths = [ordered]@{
        project_root = $ProjectRoot
        data_root = $DataRoot
        backup_root = $BackupRoot
        assistant_root = $assistantRoot
        log_root = $LogRoot
        public_key = $PublicKey
        helper_package = $HelperPackage
        python = $PythonPath
    }
}
if ($WhatIf) {
    $plan | ConvertTo-Json -Depth 6 -Compress
    exit 0
}

$githubHeaders = @{ "Accept" = "application/vnd.github+json"; "User-Agent" = "ProbabilityQuizUpdater" }
try {
    $repositoryInfo = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$Repository" -Headers $githubHeaders -TimeoutSec 15
} catch {
    throw "The configured public GitHub release repository is unreachable. The updater was not installed."
}
if ($repositoryInfo.full_name -ne $Repository -or $repositoryInfo.private -ne $false) {
    throw "The configured update repository is not the expected public GitHub repository."
}

$listener = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() |
    Where-Object { $_.Port -eq $Port }
if ($listener) { throw "Stop the existing site before install; port $Port is already listening." }

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
if ($null -eq $identity.User) { throw "Could not identify the current Windows user." }

Add-Type -AssemblyName System.IO.Compression.FileSystem
$backupStamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $BackupRoot "probability-quiz-$backupStamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
$programBackup = Join-Path $backupDir "program.zip"
$dataBackup = Join-Path $backupDir "data"
[System.IO.Compression.ZipFile]::CreateFromDirectory($ProjectRoot, $programBackup, [System.IO.Compression.CompressionLevel]::Optimal, $false)
if (-not (Test-Path -LiteralPath $programBackup -PathType Leaf)) { throw "The program backup was not created." }
$programArchive = [System.IO.Compression.ZipFile]::OpenRead($programBackup)
try { if ($programArchive.Entries.Count -lt 6) { throw "The program backup is incomplete." } } finally { $programArchive.Dispose() }

Copy-Item -LiteralPath $DataRoot -Destination $dataBackup -Recurse -Force
$sourceFiles = @(Get-ChildItem -LiteralPath $DataRoot -File -Recurse -Force)
$backupFiles = @(Get-ChildItem -LiteralPath $dataBackup -File -Recurse -Force)
if ($sourceFiles.Count -ne $backupFiles.Count) { throw "The data backup file count does not match." }
foreach ($sourceFile in $sourceFiles) {
    $relative = $sourceFile.FullName.Substring($DataRoot.Length).TrimStart('\', '/')
    $backupFile = Join-Path $dataBackup $relative
    if (-not (Test-Path -LiteralPath $backupFile -PathType Leaf)) { throw "A data backup file is missing." }
    if ((Get-FileHash -LiteralPath $sourceFile.FullName -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $backupFile -Algorithm SHA256).Hash) {
        throw "A data backup hash check failed."
    }
}
$databasePath = Join-Path $DataRoot "quiz.sqlite3"
if (-not (Test-Path -LiteralPath $databasePath -PathType Leaf)) { throw "DataRoot has no quiz.sqlite3 database." }
foreach ($directoryName in @("uploads", "pending")) {
    if (-not (Test-Path -LiteralPath (Join-Path $DataRoot $directoryName) -PathType Container)) {
        throw "DataRoot is missing the $directoryName folder."
    }
}
$backupDatabasePath = Join-Path $dataBackup "quiz.sqlite3"
foreach ($databaseCheckPath in @($databasePath, $backupDatabasePath)) {
    $checkScript = "import sqlite3,sys; c=sqlite3.connect('file:'+sys.argv[1].replace('\\','/')+'?mode=ro',uri=True); r=c.execute('PRAGMA quick_check').fetchone(); c.close(); raise SystemExit(0 if r and r[0]=='ok' else 1)"
    & $PythonPath -I -c $checkScript $databaseCheckPath
    if ($LASTEXITCODE -ne 0) { throw "SQLite integrity check failed." }
}

$publicKeyCheckScript = "import sys;sys.path.insert(0,sys.argv[1]);from updater.rsa_verify import _parse_public_key;_parse_public_key(open(sys.argv[2],'rb').read())"
& $PythonPath -I -c $publicKeyCheckScript $ProjectRoot $PublicKey
if ($LASTEXITCODE -ne 0) { throw "The release public key is not a valid RSA-3072 PEM key." }
& $PythonPath -I -S $HelperPackage --help | Out-Null
if ($LASTEXITCODE -ne 0) { throw "The bundled update helper did not start." }

New-Item -ItemType Directory -Path $assistantRoot, $versionsRoot, $workRoot, (Join-Path $assistantRoot "backups"), $LogRoot -Force | Out-Null
$packageMarkerPath = Join-Path $ProjectRoot "bootstrap-package.marker"
$packageId = "manual-install"
if (Test-Path -LiteralPath $packageMarkerPath -PathType Leaf) {
    $candidatePackageId = (Get-Content -LiteralPath $packageMarkerPath -Raw -Encoding ASCII).Trim()
    if ($candidatePackageId -eq "windows-first-install-v1") { $packageId = $candidatePackageId }
}
$installationBinding = [ordered]@{
    install_root = $ProjectRoot
    package_id = $packageId
}
[System.IO.File]::WriteAllText($installationBindingPath, ($installationBinding | ConvertTo-Json -Compress), (New-Object System.Text.UTF8Encoding($false)))

Copy-Item -LiteralPath $HelperPackage -Destination $installedHelper -Force
Copy-Item -LiteralPath $PublicKey -Destination $installedKey -Force
$tokenBytes = New-Object byte[] 32
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($tokenBytes) } finally { $rng.Dispose() }
$token = [Convert]::ToBase64String($tokenBytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')
[System.IO.File]::WriteAllText($tokenPath, $token, [System.Text.Encoding]::ASCII)
$systemAce = "*S-1-5-18:(F)"
$adminAce = "*S-1-5-32-544:(F)"
$userAce = "*$($identity.User.Value):(F)"
Invoke-Icacls @($tokenPath, "/inheritance:r")
Invoke-Icacls @($tokenPath, "/grant:r", $systemAce, $adminAce, $userAce)

$envValues = [ordered]@{
    QUIZ_URL_PREFIX = "/quiz"
    QUIZ_SESSION_DAYS = "7"
}
foreach ($key in @("QUIZ_HTTPS", "PUBLIC_BASE_URL", "COURSEWARE_URL")) {
    $value = [Environment]::GetEnvironmentVariable($key)
    if ($null -ne $value) { $envValues[$key] = [string]$value }
}
$agentPortListener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 0)
$agentPortListener.Start()
$agentPort = ([System.Net.IPEndPoint]$agentPortListener.LocalEndpoint).Port
$agentPortListener.Stop()
$config = [ordered]@{
    program_root = $ProjectRoot
    data_root = $DataRoot
    versions_root = $versionsRoot
    work_root = $workRoot
    python_executable = $PythonPath
    repository = $Repository
    public_key_path = $installedKey
    key_id = $KeyId
    secret_key_path = (Join-Path $ProjectRoot "secret_key.txt")
    website_environment = $envValues
    site_url = "http://127.0.0.1:5000/quiz/"
    health_url = "http://127.0.0.1:5000/quiz/__updater_health"
    agent_port = $agentPort
    agent_token_path = $tokenPath
    backup_retention = 5
}
$configTemp = Join-Path $assistantRoot "config.json.tmp"
[System.IO.File]::WriteAllText($configTemp, ($config | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
Move-Item -LiteralPath $configTemp -Destination $configPath -Force

$schemaOutput = & $PythonPath -I -c 'import sys;sys.path.insert(0,sys.argv[1]);from app.db import MIGRATION_VERSION;print(MIGRATION_VERSION)' $ProjectRoot
if ($LASTEXITCODE -ne 0 -or $schemaOutput -notmatch '^\d+$') { throw "Could not read the database migration version." }
$initialVersion = Join-Path $versionsRoot "1.0.0"
if (Test-Path -LiteralPath $initialVersion) {
    if (-not (Test-Path -LiteralPath (Join-Path $initialVersion "app\__init__.py") -PathType Leaf)) {
        throw "An incomplete version 1.0.0 folder exists under updater-state. Preserve it for inspection before retrying."
    }
} else {
    & $PythonPath -I -S (Join-Path $ProjectRoot "scripts\install_program_version.py") --project-root $ProjectRoot --destination $initialVersion
    if ($LASTEXITCODE -ne 0) { throw "Could not prepare the initial program version." }
}
[ordered]@{ version = "1.0.0"; required_schema_version = [int]$schemaOutput } |
    ForEach-Object { [System.IO.File]::WriteAllText((Join-Path $workRoot "active_version.json"), ($_ | ConvertTo-Json -Compress), (New-Object System.Text.UTF8Encoding($false))) }

$launcherArgs = @(
    "-NoProfile",
    "-ExecutionPolicy", "Bypass",
    "-File", (Quote-ProcessArgument $agentLauncher),
    "-PythonPath", (Quote-ProcessArgument $PythonPath),
    "-HelperPath", (Quote-ProcessArgument $installedHelper),
    "-ConfigPath", (Quote-ProcessArgument $configPath),
    "-AssistantRoot", (Quote-ProcessArgument $assistantRoot),
    "-LogRoot", (Quote-ProcessArgument $LogRoot)
) -join " "
$powerShellExe = Join-Path $PSHOME "powershell.exe"
$action = New-ScheduledTaskAction -Execute $powerShellExe -Argument $launcherArgs -WorkingDirectory $assistantRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $identity.Name
$principal = New-ScheduledTaskPrincipal -UserId $identity.User.Value -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Start-ScheduledTask -TaskName $taskName

$deadline = (Get-Date).AddSeconds(60)
$ready = $false
while ((Get-Date) -lt $deadline) {
    try {
        $status = Invoke-RestMethod -Method Get -Uri "http://127.0.0.1:$agentPort/v1/status" -Headers @{ Authorization = "Bearer $token" } -TimeoutSec 2
        if ($status.current_version -eq "1.0.0") { $ready = $true; break }
    } catch { Start-Sleep -Seconds 1 }
    Start-Sleep -Milliseconds 500
}
if (-not $ready) { throw "The updater was installed, but its local site did not pass health checks. Keep the project folder and inspect its logs." }
@{
    status = "installed"
    version = "1.0.0"
    repository = $Repository
    backup = $backupDir
    task = $taskName
    log_root = $LogRoot
} | ConvertTo-Json -Compress
