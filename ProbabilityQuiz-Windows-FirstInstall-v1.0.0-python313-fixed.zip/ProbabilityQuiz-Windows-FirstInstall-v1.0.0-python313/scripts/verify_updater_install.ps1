﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$AssistantRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-UpdaterTaskName([string]$Root) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes([System.IO.Path]::GetFullPath($Root).ToLowerInvariant())
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $digest = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace("-", "").Substring(0, 12)
    } finally {
        $sha.Dispose()
    }
    return "ProbabilityQuizUpdater-$digest"
}

$assistantRoot = [System.IO.Path]::GetFullPath($AssistantRoot)
$packageRoot = Split-Path -Parent $assistantRoot
$logRoot = Join-Path $packageRoot "logs"
$configPath = Join-Path $assistantRoot "config.json"
$tokenPath = Join-Path $assistantRoot "agent.token"
$helperPath = Join-Path $assistantRoot "quiz-updater.pyz"
$bindingPath = Join-Path $assistantRoot "install_root.txt"
$taskName = Get-UpdaterTaskName $assistantRoot

foreach ($path in @($configPath, $tokenPath, $helperPath, $bindingPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "An updater installation file is missing." }
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$binding = Get-Content -LiteralPath $bindingPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ([System.IO.Path]::GetFullPath([string]$binding.install_root) -ne [System.IO.Path]::GetFullPath([string]$config.program_root)) {
    throw "The install-root binding does not match the updater configuration."
}
if ((Split-Path -Parent ([System.IO.Path]::GetFullPath([string]$config.program_root))) -ne $packageRoot) {
    throw "The configured program is not in this package folder."
}
$token = [System.IO.File]::ReadAllText($tokenPath, [System.Text.Encoding]::UTF8).Trim()
if ([string]::IsNullOrWhiteSpace($token)) { throw "The updater token file is empty." }

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
$currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$taskUser = [string]$task.Principal.UserId
$currentUserName = ([string]$currentIdentity.Name -split "\\")[-1]
$sameAccount = $taskUser.Equals([string]$currentIdentity.User.Value, [StringComparison]::OrdinalIgnoreCase) -or
    $taskUser.Equals([string]$currentIdentity.Name, [StringComparison]::OrdinalIgnoreCase) -or
    $taskUser.Equals($currentUserName, [StringComparison]::OrdinalIgnoreCase)
if (-not $sameAccount) {
    throw "The updater task is not configured for the current Windows user."
}
$taskInfo = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop
$headers = @{ "Authorization" = "Bearer $token" }
$agentStatus = Invoke-RestMethod -Method Get -Uri "http://127.0.0.1:$($config.agent_port)/v1/status" -Headers $headers -TimeoutSec 5
$siteStatus = Invoke-WebRequest -UseBasicParsing -Uri $config.site_url -TimeoutSec 5

$result = [ordered]@{
    status = "verified"
    program_root = [string]$config.program_root
    data_root = [string]$config.data_root
    log_root = $logRoot
    installation_binding = "verified"
    task_name = $taskName
    task_state = [string]$task.State
    last_task_result = [int]$taskInfo.LastTaskResult
    site_http_status = [int]$siteStatus.StatusCode
    repository = [string]$config.repository
    current_version = [string]$agentStatus.current_version
    updater_phase = [string]$agentStatus.phase
    config_path = $configPath
}
$result | ConvertTo-Json -Depth 4 -Compress
