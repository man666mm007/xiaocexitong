"""Copy only the release allowlist into a new managed version slot."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from updater.package_builder import PackageBuildError, _collect_files


def copy_current_program(project_root: Path, destination: Path) -> None:
    root = Path(project_root).resolve(strict=True)
    target = Path(destination).resolve(strict=False)
    if target.exists():
        raise ValueError("target version directory already exists")
    entries = _collect_files(root)
    target.mkdir(parents=True, exist_ok=False)
    try:
        for name, source in entries:
            output = target.joinpath(*Path(name).parts)
            output.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, output)
    except BaseException:
        shutil.rmtree(target, ignore_errors=True)
        raise


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="copy current program files into a managed version slot")
    parser.add_argument("--project-root", required=True, type=Path)
    parser.add_argument("--destination", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        copy_current_program(args.project_root, args.destination)
    except (OSError, ValueError, PackageBuildError) as exc:
        print(f"程序文件复制失败：{exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
