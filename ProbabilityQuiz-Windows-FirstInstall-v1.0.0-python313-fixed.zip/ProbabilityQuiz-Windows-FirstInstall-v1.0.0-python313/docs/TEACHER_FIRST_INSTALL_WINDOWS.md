﻿# Windows 首次安装指南

这个安装包用于一台 Windows 电脑上的全新安装。首次启动会创建本地数据库和教师账号；已有的学生、成绩和上传资料不会随安装包提供。

## 安装前

1. 使用 64 位 Windows，并确认电脑可以访问 Python.org、GitHub 和清华 PyPI 镜像。
2. 将完整 ZIP 解压到一个你有写入权限的本地文件夹，例如 C:\QuizBootstrap。安装后不要移动或改名这个文件夹。
3. 关闭占用本系统 5000 端口的旧服务。安装程序不会自动终止未知进程。

不需要预先安装 Python，也不需要管理员权限。若缺少 Python 3.13，安装程序会把经校验的官方 Python 3.13.15 x64 安装到包目录的 python-runtime 子文件夹，并把应用虚拟环境创建在 program\.venv。

## 安装

1. 双击 start_windows.bat。
2. 如果这是第一次启动，等待安装程序下载依赖、创建目录和数据库。PowerShell 窗口会显示进度。
3. 安装程序会询问外部网站地址（如果需要）以及教师账号名称和登录 ID。请使用真实环境配置，并为账号设置自己的密码。
4. 完成后，浏览器会打开 http://127.0.0.1:5000/quiz/。以后再次双击同一个 start_windows.bat 即可打开网站。

## 文件位置

安装程序将工作文件留在解压目录中：

- program：应用程序和虚拟环境。
- python-runtime：经校验的项目本地 Python 运行时。
- data：数据库、上传文件和待处理文件。
- backups：安装过程创建的程序和数据备份。
- updater-state：更新助手、版本和运行状态。
- downloads、cache：安装下载、临时文件和 pip 缓存。
- logs：安装日志和 updater-agent.log。

请保持完整目录结构。backups 与原电脑位于同一位置，不能替代异地备份；建议定期将 data 和 backups 复制到学校批准的安全存储位置。

## 更新与问题排查

教师可在网站的“系统更新”页面检查并安装已签名的版本。更新助手以当前 Windows 用户身份运行；登录 Windows 后会自动启动。

若安装或启动失败，不要先删除目录。保留整个解压目录，并查看 logs 中最新的 bootstrap-*.log、python-install-*.log 或 updater-agent.log。确认 5000 端口没有被旧服务占用后，再运行 start_windows.bat 重试。安装包会保留已有的本地数据库和 Python 下载，以便继续安装。