"""Data-directory backup and restoration helpers for updater transactions."""

from __future__ import annotations

import os
import shutil
import stat
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4


class BackupError(RuntimeError):
    pass


def _contains_link(root: Path) -> bool:
    for current, directories, filenames in os.walk(root, topdown=True, followlinks=False):
        for name in [*directories, *filenames]:
            path = Path(current) / name
            try:
                details = path.lstat()
            except OSError as exc:
                raise BackupError("data directory cannot be fully inspected") from exc
            attributes = getattr(details, "st_file_attributes", 0)
            if path.is_symlink() or attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
                return True
    return False


def _backup_directory_name() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"backup-{stamp}-{uuid4().hex[:10]}"


def copy_data_backup(source: Path, backup_root: Path) -> Path:
    """Copy the complete configured data directory into a unique backup folder."""
    source = Path(source).resolve(strict=True)
    backup_root = Path(backup_root).resolve(strict=False)
    if not source.is_dir() or source.is_symlink():
        raise BackupError("configured data root must be an existing ordinary directory")
    try:
        backup_root.relative_to(source)
    except ValueError:
        pass
    else:
        raise BackupError("backup root must be outside the data directory")
    if _contains_link(source):
        raise BackupError("data directory contains a link or reparse point")
    backup_root.mkdir(parents=True, exist_ok=True)
    backup_dir = backup_root / _backup_directory_name()
    data_backup = backup_dir / "data"
    backup_dir.mkdir(parents=False, exist_ok=False)
    try:
        shutil.copytree(source, data_backup, copy_function=shutil.copy2)
        if not data_backup.is_dir() or set(item.name for item in source.iterdir()) != set(item.name for item in data_backup.iterdir()):
            raise BackupError("data backup verification failed")
        return backup_dir
    except BaseException as exc:
        shutil.rmtree(backup_dir, ignore_errors=True)
        if isinstance(exc, BackupError):
            raise
        raise BackupError("failed to back up the configured data directory") from exc


def restore_data_backup(backup_dir: Path, data_root: Path, quarantine_root: Path) -> Path | None:
    """Restore a saved data copy, preserving the current failed data as a quarantine."""
    backup_dir = Path(backup_dir).resolve(strict=True)
    source = backup_dir / "data"
    data_root = Path(data_root).resolve(strict=False)
    quarantine_root = Path(quarantine_root).resolve(strict=False)
    if not source.is_dir() or source.is_symlink() or _contains_link(source):
        raise BackupError("saved data backup is missing or unsafe")
    if data_root == source or data_root == backup_dir:
        raise BackupError("restore target cannot point into the backup")
    data_root.parent.mkdir(parents=True, exist_ok=True)
    quarantine_root.mkdir(parents=True, exist_ok=True)
    restored = data_root.parent / f".{data_root.name}.restore-{uuid4().hex}"
    quarantined = None
    try:
        shutil.copytree(source, restored, copy_function=shutil.copy2)
        if data_root.exists():
            quarantined = quarantine_root / f"failed-data-{uuid4().hex}"
            shutil.move(str(data_root), str(quarantined))
        os.replace(restored, data_root)
        return quarantined
    except BaseException as exc:
        shutil.rmtree(restored, ignore_errors=True)
        if quarantined is not None and quarantined.exists() and not data_root.exists():
            try:
                shutil.move(str(quarantined), str(data_root))
            except OSError:
                pass
        if isinstance(exc, BackupError):
            raise
        raise BackupError("failed to restore the saved data directory") from exc
