# 小测查询系统

一个基于 Flask、SQLite 和 Jinja 的课堂小测与签到应用，提供教学班管理、成绩导入与统计、预约签到、记录更正、回收站和教师端系统更新入口。

## 一键更新

更新功能由教师端页面、独立本机更新助手和签名 Release 协议组成。更新助手只监听回环地址；程序包采用白名单构建，更新清单经 RSA-PSS 签名校验，并在切换失败时恢复旧程序版本。Windows 首次安装包会安装依赖、初始化空数据库并注册更新助手，老师以后双击 `start_windows.bat` 即可打开网站。管理员准备流程见 [docs/UPDATE_ADMIN.md](docs/UPDATE_ADMIN.md)，老师步骤见 [docs/TEACHER_FIRST_INSTALL_WINDOWS.md](docs/TEACHER_FIRST_INSTALL_WINDOWS.md)，Release 发布流程见 docs/UPDATE_RELEASE.md。

首次安装 ZIP 是按 Release 公钥和 `dist/quiz-updater.pyz` 生成的独立交付包，不等于网页更新 ZIP。它不包含发布私钥、应用密钥、数据库或上传文件；管理员应按首装手册生成 ZIP 并分发给老师。网页更新仍由老师在登录后手动触发。

## 本地运行

需要 Python 3.11 或 3.12。创建虚拟环境并安装 requirements.txt 中的依赖，然后配置本地密钥：

    py -3.12 -m venv .venv
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    $env:QUIZ_SECRET_KEY = (& python -c "import secrets; print(secrets.token_hex(32))")

初始化第一个教师账号。程序会交互式询问密码，不提供默认账号或默认密码：

    .venv\Scripts\python.exe scripts\init_project.py --teacher-id "teacher-login-id" --teacher-name "Teacher Name"

然后启动本地服务：

    .venv\Scripts\python.exe scripts\start_server.py

Linux 或 macOS 用户可使用相应平台的 Python、虚拟环境和环境变量写法。Windows 启动脚本会在本地生成并忽略 secret_key.txt；不要将该文件加入版本控制。

## 测试

    .venv\Scripts\python.exe -m unittest discover -s tests -v

## 发布范围

公开源码不包含数据库、上传内容、备份、签名私钥、服务器配置、演示数据库、演示样表或固定演示登录凭据。Git 忽略规则覆盖这些本地数据和构建产物。不要把本地交付目录中的实例数据或演示文件加入公开仓库。
