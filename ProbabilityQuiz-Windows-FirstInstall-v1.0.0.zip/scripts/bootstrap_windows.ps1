﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProjectRoot,
    [string]$BasePythonPath,
    [switch]$WhatIf,
    [switch]$OpenSite
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$script:PackageId = "windows-first-install-v1"
$script:BaseVersion = "1.0.0"
$script:Repository = "man666mm007/xiaocexitong"
$script:Mirror = "https://pypi.tuna.tsinghua.edu.cn/simple"
$script:ProgramData = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
$script:InstallRoot = Join-Path $script:ProgramData "ProbabilityQuizProgram"
$script:DataRoot = Join-Path $script:ProgramData "ProbabilityQuizData"
$script:BackupRoot = Join-Path $script:ProgramData "ProbabilityQuizFirstInstallBackups"
$script:AssistantRoot = Join-Path $script:ProgramData "ProbabilityQuizUpdater"

function Get-FullPath([string]$Value) {
    return [System.IO.Path]::GetFullPath($Value).TrimEnd('\', '/')
}

function Test-PathOverlap([string]$Left, [string]$Right) {
    $a = Get-FullPath $Left
    $b = Get-FullPath $Right
    return ($a.Equals($b, [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '\', [System.StringComparison]::OrdinalIgnoreCase) -or
        $a.StartsWith($b + '/', [System.StringComparison]::OrdinalIgnoreCase) -or
        $b.StartsWith($a + '/', [System.StringComparison]::OrdinalIgnoreCase))
}

function Invoke-Icacls([string[]]$Arguments) {
    & "$env:SystemRoot\System32\icacls.exe" @Arguments | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Windows 文件权限设置失败。" }
}

function Set-PrivateDirectoryAcl([string]$Path, [bool]$AllowNetworkServiceWrite = $false) {
    $system = "*S-1-5-18"
    $admin = "*S-1-5-32-544"
    $networkService = "*S-1-5-20"
    Invoke-Icacls @($Path, "/inheritance:r", "/T", "/C")
    if ($AllowNetworkServiceWrite) {
        Invoke-Icacls @($Path, "/grant:r", "$system`:(OI)(CI)(F)", "$admin`:(OI)(CI)(F)", "$networkService`:(OI)(CI)(M)", "/T", "/C")
    } else {
        Invoke-Icacls @($Path, "/grant:r", "$system`:(OI)(CI)(F)", "$admin`:(OI)(CI)(F)", "/T", "/C")
    }
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-PortConflicts([int]$Port) {
    $listeners = @()
    try {
        $listeners = @([System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() |
            Where-Object { $_.Port -eq $Port })
    } catch {
        return @([ordered]@{ pid = 0; executable = "无法查询监听进程" })
    }
    $pids = @()
    foreach ($listener in $listeners) {
        try {
            $connections = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop |
                Where-Object { $_.LocalAddress -eq $listener.Address.ToString() -or $_.LocalAddress -eq "0.0.0.0" -or $_.LocalAddress -eq "::" })
            foreach ($connection in $connections) { $pids += [int]$connection.OwningProcess }
        } catch {
            try {
                $connections = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop)
                foreach ($connection in $connections) { $pids += [int]$connection.OwningProcess }
            } catch { }
        }
    }
    $result = @()
    foreach ($processId in @($pids | Sort-Object -Unique)) {
        $executable = "无法读取可执行文件路径"
        try {
            $process = Get-Process -Id $processId -ErrorAction Stop
            if ($process.Path) { $executable = [string]$process.Path }
        } catch { }
        $result += [ordered]@{ pid = [int]$processId; executable = $executable }
    }
    if ($listeners.Count -gt 0 -and $result.Count -eq 0) {
        $result += [ordered]@{ pid = 0; executable = "端口已监听，但无法读取进程信息" }
    }
    return $result
}

function Get-PythonRuntime([string]$PreferredPath) {
    if ($PreferredPath) {
        $candidate = Get-FullPath $PreferredPath
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw "Python 3.12 路径不可访问：$candidate" }
        $python = $candidate
    } else {
        $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
        if (-not $launcher) { throw "未检测到 Python Launcher。请先安装 Python 3.12，并在安装器中启用 Python Launcher。" }
        $runtimeJson = & $launcher.Source -3.12 -I -c 'import json,sys;print(json.dumps({"executable":sys.executable,"base_prefix":sys.base_prefix,"version":list(sys.version_info[:3])}))'
        if ($LASTEXITCODE -ne 0 -or -not $runtimeJson) { throw "未检测到可运行的 Python 3.12。" }
        $runtime = $runtimeJson | ConvertFrom-Json
        if ([int]$runtime.version[0] -ne 3 -or [int]$runtime.version[1] -ne 12) { throw "首装仅接受 Python 3.12。" }
        $python = Get-FullPath ([string]$runtime.executable)
    }
    $probeJson = & $python -I -c 'import json,sys;print(json.dumps({"executable":sys.executable,"base_prefix":sys.base_prefix,"version":list(sys.version_info[:3])}))'
    if ($LASTEXITCODE -ne 0 -or -not $probeJson) { throw "Python 3.12 运行检查失败。" }
    $probe = $probeJson | ConvertFrom-Json
    if ([int]$probe.version[0] -ne 3 -or [int]$probe.version[1] -ne 12) { throw "首装仅接受 Python 3.12。" }
    return [ordered]@{ executable = (Get-FullPath ([string]$probe.executable)); base_prefix = (Get-FullPath ([string]$probe.base_prefix)) }
}

function Test-PackageMember([string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Name) -or $Name.Contains('\') -or $Name.StartsWith('/')) { return $false }
    $parts = $Name.Split('/')
    if ($parts -contains ".." -or $parts -contains "." -or $parts -contains "__pycache__") { return $false }
    $rootFiles = @("VERSION", "requirements.txt", "run.py", "wsgi.py", "start_windows.bat", "README.md", "USER_GUIDE.md", "bootstrap-package.marker")
    $scriptFiles = @("bootstrap_windows.ps1", "init_project.py", "install_program_version.py", "install_updater.ps1", "start_server.py", "verify_updater_install.ps1")
    if ($rootFiles -contains $Name) { return $true }
    if ($Name -eq "docs/TEACHER_FIRST_INSTALL_WINDOWS.md") { return $true }
    if ($Name -eq "bootstrap-assets/release-public.pem" -or $Name -eq "bootstrap-assets/quiz-updater.pyz") { return $true }
    if ($Name -like "scripts/*") { return $scriptFiles -contains $Name.Substring(8) }
    if ($parts[0] -in @("app", "updater") -and $parts.Count -ge 2) {
        $extension = [System.IO.Path]::GetExtension($Name).ToLowerInvariant()
        return $extension -in @(".py", ".html", ".css", ".js", ".svg", ".sql")
    }
    return $false
}

function Get-ValidatedPackage([string]$Root) {
    if (-not (Test-Path -LiteralPath (Join-Path $Root "bootstrap-package.marker") -PathType Leaf)) { throw "首装包标记缺失。请完整解压官方首装 ZIP。" }
    $marker = (Get-Content -LiteralPath (Join-Path $Root "bootstrap-package.marker") -Raw -Encoding ASCII).Trim()
    if ($marker -ne $script:PackageId) { throw "首装包标记无效。" }
    $version = (Get-Content -LiteralPath (Join-Path $Root "VERSION") -Raw -Encoding ASCII).Trim()
    if ($version -ne $script:BaseVersion) { throw "首装包版本必须是 $script:BaseVersion。" }
    $manifestPath = Join-Path $Root "bootstrap-package.json"
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw "首装包校验清单缺失。" }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.package_id -ne $script:PackageId -or $manifest.base_version -ne $script:BaseVersion) { throw "首装包校验清单与应用版本不匹配。" }

    $required = @(
        "VERSION", "requirements.txt", "start_windows.bat", "app/__init__.py", "updater/__init__.py",
        "scripts/bootstrap_windows.ps1", "scripts/init_project.py", "scripts/install_program_version.py",
        "scripts/install_updater.ps1", "scripts/start_server.py", "scripts/verify_updater_install.ps1",
        "bootstrap-assets/release-public.pem", "bootstrap-assets/quiz-updater.pyz", "bootstrap-package.marker",
        "docs/TEACHER_FIRST_INSTALL_WINDOWS.md"
    )
    $members = @{}
    foreach ($property in $manifest.files.PSObject.Properties) {
        $name = [string]$property.Name
        if (-not (Test-PackageMember $name)) { throw "首装包包含未经批准的文件路径：$name" }
        $expected = [string]$property.Value
        if ($expected -notmatch '^[0-9a-fA-F]{64}$') { throw "首装包校验清单中的摘要无效：$name" }
        $filePath = Join-Path $Root ($name.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) { throw "首装包文件缺失：$name" }
        $actual = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash
        if ($actual -ne $expected) { throw "首装包文件校验失败：$name" }
        $members[$name] = $filePath
    }
    foreach ($name in $required) {
        if (-not $members.ContainsKey($name)) { throw "首装包缺少必需文件：$name" }
    }
    return [ordered]@{ root = $Root; marker = $marker; version = $version; manifest = $manifest; members = $members }
}

function Get-GitHubRepositoryStatus {
    try {
        $headers = @{ Accept = "application/vnd.github+json"; "User-Agent" = "ProbabilityQuizFirstInstall" }
        $response = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$script:Repository" -Headers $headers -TimeoutSec 15
        return [ordered]@{ reachable = ($response.full_name -ceq $script:Repository -and $response.private -eq $false); full_name = [string]$response.full_name }
    } catch {
        return [ordered]@{ reachable = $false; full_name = "" }
    }
}

function New-PreflightPlan($Package, $Python, $PortConflicts, $RepositoryStatus) {
    $blockers = @()
    foreach ($pathInfo in @(
        @{ path = $script:InstallRoot; label = "程序安装目录" },
        @{ path = $script:DataRoot; label = "数据目录" }
    )) {
        if (Test-Path -LiteralPath $pathInfo.path) { $blockers += "$($pathInfo.label)已存在：$($pathInfo.path)" }
    }
    if (Test-Path -LiteralPath $script:AssistantRoot) { $blockers += "更新助手目录已存在：$($script:AssistantRoot)" }
    if ($PortConflicts.Count -gt 0) { $blockers += "5000 端口已被占用；请先按旧服务原有方式停止它。" }
    if (-not $RepositoryStatus.reachable) { $blockers += "GitHub 更新仓库当前不可访问或仓库名称不匹配。" }
    if ((Test-PathOverlap $Package.root $script:InstallRoot) -or (Test-PathOverlap $script:InstallRoot $script:DataRoot) -or
        (Test-PathOverlap $script:InstallRoot $script:BackupRoot) -or (Test-PathOverlap $script:DataRoot $script:BackupRoot) -or
        (Test-PathOverlap $script:AssistantRoot $script:BackupRoot)) {
        $blockers += "程序、数据、助手和首装备份路径必须互不重叠。"
    }
    return [ordered]@{
        status = if ($blockers.Count -eq 0) { "ready" } else { "blocked" }
        package_id = $script:PackageId
        base_version = $Package.version
        repository = $script:Repository
        repository_reachable = [bool]$RepositoryStatus.reachable
        python = $Python.executable
        python_base = $Python.base_prefix
        dependency_mirror = $script:Mirror
        listener = "0.0.0.0:5000/quiz/"
        port_conflicts = @($PortConflicts)
        paths = [ordered]@{
            package_source = $Package.root
            program_root = $script:InstallRoot
            data_root = $script:DataRoot
            backup_root = $script:BackupRoot
            assistant_root = $script:AssistantRoot
        }
        blockers = @($blockers)
    }
}

function Quote-ProcessArgument([string]$Value) {
    return '"' + $Value + '"'
}

function ConvertTo-AsciiJson($Value) {
    $json = $Value | ConvertTo-Json -Depth 8 -Compress
    $builder = New-Object System.Text.StringBuilder
    foreach ($character in $json.ToCharArray()) {
        if ([int]$character -gt 127) {
            [void]$builder.Append(("\u{0:x4}" -f [int]$character))
        } else {
            [void]$builder.Append($character)
        }
    }
    return $builder.ToString()
}

function Set-ApplicationSecretAcl([string]$Path) {
    $system = "*S-1-5-18"
    $admin = "*S-1-5-32-544"
    $networkService = "*S-1-5-20"
    Invoke-Icacls @($Path, "/inheritance:r")
    Invoke-Icacls @($Path, "/grant:r", "$system`:(F)", "$admin`:(F)", "$networkService`:(R)")
}

function Set-ApplicationRootAcl([string]$Path) {
    $system = "*S-1-5-18"
    $admin = "*S-1-5-32-544"
    $networkService = "*S-1-5-20"
    $users = "*S-1-5-32-545"
    Invoke-Icacls @($Path, "/inheritance:r")
    Invoke-Icacls @($Path, "/grant:r", "$system`:(OI)(CI)(F)", "$admin`:(OI)(CI)(F)", "$networkService`:(OI)(CI)(RX)", "$users`:(X)")
}

function Copy-PackageIntoProgramRoot($Package) {
    New-Item -ItemType Directory -Path $script:InstallRoot -Force | Out-Null
    Set-ApplicationRootAcl $script:InstallRoot
    foreach ($name in @($Package.members.Keys | Sort-Object)) {
        $source = $Package.members[$name]
        $destination = Join-Path $script:InstallRoot ($name.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        $destinationFullPath = [System.IO.Path]::GetFullPath($destination)
        if (-not $destinationFullPath.StartsWith((Get-FullPath $script:InstallRoot) + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase) -and
            -not $destinationFullPath.Equals((Get-FullPath $script:InstallRoot), [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "程序文件路径越出安装目录：$name"
        }
        $destinationDirectory = Split-Path -Parent $destinationFullPath
        New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $destinationFullPath -Force
    }
    Copy-Item -LiteralPath (Join-Path $Package.root "bootstrap-package.json") -Destination (Join-Path $script:InstallRoot "bootstrap-package.json") -Force
    Set-ApplicationRootAcl $script:InstallRoot
}

function Grant-PythonRuntimeAccess([string]$BasePrefix) {
    if (-not (Test-Path -LiteralPath $BasePrefix -PathType Container)) { throw "Python 运行库目录不可访问：$BasePrefix" }
    Invoke-Icacls @($BasePrefix, "/grant", "*S-1-5-20`:(OI)(CI)(RX)", "*S-1-5-32-545`:(OI)(CI)(RX)", "/T", "/C")
}

function Get-ValidatedUrl([string]$Prompt, [bool]$Optional) {
    $value = (Read-Host $Prompt).Trim()
    if ($Optional -and -not $value) { return "" }
    if (-not $value) { throw "此项不能为空。" }
    $uri = $null
    if (-not [Uri]::TryCreate($value, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -notin @("http", "https")) {
        throw "请输入完整的 http:// 或 https:// 地址。"
    }
    return $value.TrimEnd('/')
}

function Invoke-InstalledOpenSite([string]$PackageRoot) {
    $package = Get-ValidatedPackage $PackageRoot
    $bindingPath = Join-Path $script:AssistantRoot "install_root.txt"
    $helperPath = Join-Path $script:AssistantRoot "quiz-updater.pyz"
    if (-not (Test-Path -LiteralPath $bindingPath -PathType Leaf) -or -not (Test-Path -LiteralPath $helperPath -PathType Leaf)) {
        throw "更新助手安装记录缺失；请管理员检查首装状态。"
    }
    $binding = Get-Content -LiteralPath $bindingPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($binding.package_id -ne $script:PackageId -or [string]::IsNullOrWhiteSpace([string]$binding.install_root)) {
        throw "此首装包与当前更新助手安装不匹配。"
    }
    $installedRoot = Get-FullPath ([string]$binding.install_root)
    $python = Join-Path $installedRoot ".venv\Scripts\python.exe"
    if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw "已安装的 Python 环境缺失，请联系管理员。" }
    & $python -I -S $helperPath --open-site
    if ($LASTEXITCODE -ne 0) { throw "网站尚未就绪。请稍后重试；若仍失败，请联系管理员。" }
}

try {
    $packageRoot = Get-FullPath $ProjectRoot
    if (-not (Test-Path -LiteralPath $packageRoot -PathType Container)) { throw "首装包目录不存在：$packageRoot" }
    if ($OpenSite) {
        Invoke-InstalledOpenSite $packageRoot
        exit 0
    }

    $package = Get-ValidatedPackage $packageRoot
    $runtime = Get-PythonRuntime $BasePythonPath
    $portConflicts = @(Get-PortConflicts 5000)
    $repositoryStatus = Get-GitHubRepositoryStatus
    $plan = New-PreflightPlan $package $runtime $portConflicts $repositoryStatus
    if ($WhatIf) {
        ConvertTo-AsciiJson $plan
        if ($plan.blockers.Count -gt 0) { exit 1 }
        exit 0
    }
    if ($plan.blockers.Count -gt 0) {
        foreach ($blocker in $plan.blockers) { Write-Host "[停止] $blocker" -ForegroundColor Red }
        foreach ($conflict in $plan.port_conflicts) {
            Write-Host ("PID={0}; 程序={1}" -f $conflict.pid, $conflict.executable) -ForegroundColor Yellow
        }
        throw "首装前检查未通过；没有停止或修改未知进程。"
    }

    if (-not (Test-IsAdministrator)) {
        $powershellPath = (Get-Process -Id $PID).Path
        $argumentLine = "-NoProfile -ExecutionPolicy Bypass -File $(Quote-ProcessArgument $PSCommandPath) -ProjectRoot $(Quote-ProcessArgument $packageRoot) -BasePythonPath $(Quote-ProcessArgument $runtime.executable)"
        try {
            $elevated = Start-Process -FilePath $powershellPath -Verb RunAs -ArgumentList $argumentLine -Wait -PassThru
        } catch {
            throw "管理员授权被取消或无法启动。首装未写入文件。"
        }
        if ($elevated.ExitCode -ne 0) { throw "管理员首装步骤失败，退出码：$($elevated.ExitCode)" }
        exit 0
    }

    $runtime = Get-PythonRuntime $runtime.executable
    $portConflicts = @(Get-PortConflicts 5000)
    $repositoryStatus = Get-GitHubRepositoryStatus
    $plan = New-PreflightPlan $package $runtime $portConflicts $repositoryStatus
    if ($plan.blockers.Count -gt 0) {
        foreach ($blocker in $plan.blockers) { Write-Host "[停止] $blocker" -ForegroundColor Red }
        foreach ($conflict in $plan.port_conflicts) {
            Write-Host ("PID={0}; 程序={1}" -f $conflict.pid, $conflict.executable) -ForegroundColor Yellow
        }
        throw "管理员首装前检查未通过；没有停止或修改未知进程。"
    }

    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    New-Item -ItemType Directory -Path $script:BackupRoot -Force | Out-Null
    Set-PrivateDirectoryAcl $script:BackupRoot $false
    $logPath = Join-Path $script:BackupRoot "bootstrap-$timestamp.log"
    Start-Transcript -LiteralPath $logPath -Force | Out-Null
    Write-Host "正在将程序安装到：$script:InstallRoot"
    Write-Host "数据目录：$script:DataRoot"
    Write-Host "首次安装备份目录：$script:BackupRoot"

    $httpsAnswer = (Read-Host "旧网站是否使用 HTTPS？输入 y 或 n").Trim().ToLowerInvariant()
    if ($httpsAnswer -notin @("y", "yes", "n", "no")) { throw "请输入 y 或 n。" }
    $env:QUIZ_HTTPS = if ($httpsAnswer -in @("y", "yes")) { "1" } else { "0" }
    $env:PUBLIC_BASE_URL = Get-ValidatedUrl "外部访问基础地址（没有则留空）" $true
    $env:COURSEWARE_URL = Get-ValidatedUrl "课程资源地址（没有则留空）" $true
    $teacherId = (Read-Host "教师工号（1 到 64 个字符）").Trim()
    $teacherName = (Read-Host "教师姓名（1 到 100 个字符）").Trim()
    if ($teacherId.Length -lt 1 -or $teacherId.Length -gt 64) { throw "教师工号长度必须为 1 到 64 个字符。" }
    if ($teacherName.Length -lt 1 -or $teacherName.Length -gt 100) { throw "教师姓名长度必须为 1 到 100 个字符。" }

    Copy-PackageIntoProgramRoot $package
    $programAcl = Join-Path $script:InstallRoot ".venv"
    $programPython = Join-Path $programAcl "Scripts\python.exe"
    New-Item -ItemType Directory -Path $script:DataRoot -Force | Out-Null
    Set-PrivateDirectoryAcl $script:DataRoot $true
    foreach ($directory in @("uploads", "pending")) { New-Item -ItemType Directory -Path (Join-Path $script:DataRoot $directory) -Force | Out-Null }

    $installerPython = $runtime.executable
    if (-not (Test-Path -LiteralPath $programPython -PathType Leaf)) {
        & $installerPython -I -m venv $programAcl
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $programPython -PathType Leaf)) { throw "Python 虚拟环境创建失败。" }
    }
    Invoke-Icacls @($programAcl, "/grant", "*S-1-5-32-545`:(OI)(CI)(RX)", "/T", "/C")
    Grant-PythonRuntimeAccess $runtime.base_prefix
    & $programPython -I -m pip install --disable-pip-version-check --no-input --retries 3 --index-url $script:Mirror -r (Join-Path $script:InstallRoot "requirements.txt")
    if ($LASTEXITCODE -ne 0) { throw "依赖安装失败；请检查网络或清华 PyPI 镜像后重试。日志：$logPath" }
    & $programPython -I -m pip check
    if ($LASTEXITCODE -ne 0) { throw "Python 依赖一致性检查失败。" }

    $secretPath = Join-Path $script:InstallRoot "secret_key.txt"
    if (Test-Path -LiteralPath $secretPath) { throw "首装包不应包含 secret_key.txt，拒绝继续。" }
    $secretBytes = New-Object byte[] 32
    $random = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $random.GetBytes($secretBytes) } finally { $random.Dispose() }
    $secret = [BitConverter]::ToString($secretBytes).Replace("-", "").ToLowerInvariant()
    [System.IO.File]::WriteAllText($secretPath, $secret, [System.Text.Encoding]::ASCII)
    Set-ApplicationSecretAcl $secretPath

    $env:QUIZ_INSTANCE_DIR = $script:DataRoot
    $env:QUIZ_SECRET_KEY = $secret
    $env:QUIZ_URL_PREFIX = "/quiz"
    $env:QUIZ_SESSION_DAYS = "7"
    & $programPython (Join-Path $script:InstallRoot "scripts\init_project.py") --teacher-id $teacherId --teacher-name $teacherName
    if ($LASTEXITCODE -ne 0) { throw "教师账号或空数据库初始化失败。" }

    $publicKey = Join-Path $script:InstallRoot "bootstrap-assets\release-public.pem"
    $helper = Join-Path $script:InstallRoot "bootstrap-assets\quiz-updater.pyz"
    $installer = Join-Path $script:InstallRoot "scripts\install_updater.ps1"
    $verify = Join-Path $script:InstallRoot "scripts\verify_updater_install.ps1"
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer,
        "-ProjectRoot", $script:InstallRoot,
        "-DataRoot", $script:DataRoot,
        "-Repository", $script:Repository,
        "-PublicKey", $publicKey,
        "-HelperPackage", $helper,
        "-PythonPath", $programPython,
        "-BackupRoot", $script:BackupRoot,
        "-Port", "5000",
        "-UrlPrefix", "/quiz",
        "-WhatIf"
    )
    $whatIfJson = & powershell.exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "更新助手安装预检失败；没有安装计划任务。" }
    $installerPlan = ($whatIfJson -join "`n") | ConvertFrom-Json
    if ($installerPlan.paths.project_root -ne $script:InstallRoot -or $installerPlan.paths.data_root -ne $script:DataRoot -or $installerPlan.paths.backup_root -ne $script:BackupRoot) {
        throw "更新助手安装预检返回的目录与首装计划不一致。"
    }
    $arguments = @(
        "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $installer,
        "-ProjectRoot", $script:InstallRoot,
        "-DataRoot", $script:DataRoot,
        "-Repository", $script:Repository,
        "-PublicKey", $publicKey,
        "-HelperPackage", $helper,
        "-PythonPath", $programPython,
        "-BackupRoot", $script:BackupRoot,
        "-Port", "5000",
        "-UrlPrefix", "/quiz"
    )
    $installJson = & powershell.exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "更新助手安装失败。保留安装目录、数据目录和备份以供管理员恢复。" }
    $installResult = ($installJson -join "`n") | ConvertFrom-Json
    if ($installResult.status -ne "installed" -or $installResult.version -ne $script:BaseVersion) { throw "更新助手返回的安装状态或版本不匹配。" }

    $verifyJson = & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $verify
    if ($LASTEXITCODE -ne 0) { throw "更新助手已安装，但只读健康检查失败。请保留备份和日志。" }
    $verification = ($verifyJson -join "`n") | ConvertFrom-Json
    if ($verification.status -ne "verified" -or $verification.current_version -ne $script:BaseVersion -or [int]$verification.site_http_status -ge 500) {
        throw "网站健康检查没有确认首装成功。请保留备份和日志。"
    }

    Write-Host "首装完成。网站版本：$($verification.current_version)"
    Write-Host "网站地址：http://127.0.0.1:5000/quiz/"
    Write-Host "首装备份：$($installResult.backup)"
    Write-Host "管理员日志：$logPath"
    & $programPython -I -S (Join-Path $script:AssistantRoot "quiz-updater.pyz") --open-site
    if ($LASTEXITCODE -ne 0) { throw "首装完成，但网页未能打开；请手动访问 http://127.0.0.1:5000/quiz/。" }
} catch {
    Write-Host "[首装失败] $($_.Exception.Message)" -ForegroundColor Red
    if ($script:BackupRoot -and (Test-Path -LiteralPath $script:BackupRoot)) {
        Write-Host "如已开始写入，请管理员先保留以下目录中的文件：$script:BackupRoot" -ForegroundColor Yellow
    }
    exit 1
} finally {
    if ($WhatIf -eq $false -and -not $OpenSite) {
        try { Stop-Transcript | Out-Null } catch { }
    }
}
