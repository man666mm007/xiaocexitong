﻿[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$assistantRoot = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)) "ProbabilityQuizUpdater"
$configPath = Join-Path $assistantRoot "config.json"
$tokenPath = Join-Path $assistantRoot "agent.token"
$helperPath = Join-Path $assistantRoot "quiz-updater.pyz"
$bindingPath = Join-Path $assistantRoot "install_root.txt"
$taskName = "ProbabilityQuizUpdater"

foreach ($path in @($configPath, $tokenPath, $helperPath, $bindingPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "更新助手缺少必要文件。" }
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$binding = Get-Content -LiteralPath $bindingPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ([System.IO.Path]::GetFullPath([string]$binding.install_root) -ne [System.IO.Path]::GetFullPath([string]$config.program_root)) {
    throw "安装目录绑定与助手配置不一致。"
}
$token = [System.IO.File]::ReadAllText($tokenPath, [System.Text.Encoding]::UTF8).Trim()
if ([string]::IsNullOrWhiteSpace($token)) { throw "更新助手令牌文件为空。" }

$task = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
$taskInfo = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop
$headers = @{ "Authorization" = "Bearer $token" }
$agentStatus = Invoke-RestMethod -Method Get -Uri "http://127.0.0.1:$($config.agent_port)/v1/status" -Headers $headers -TimeoutSec 5
$siteStatus = Invoke-WebRequest -UseBasicParsing -Uri $config.site_url -TimeoutSec 5

$result = [ordered]@{
    status = "verified"
    program_root = [string]$config.program_root
    data_root = [string]$config.data_root
    installation_binding = "verified"
    task_state = [string]$task.State
    last_task_result = [int]$taskInfo.LastTaskResult
    site_http_status = [int]$siteStatus.StatusCode
    repository = [string]$config.repository
    current_version = [string]$agentStatus.current_version
    updater_phase = [string]$agentStatus.phase
    config_path = $configPath
}
$result | ConvertTo-Json -Depth 4 -Compress
